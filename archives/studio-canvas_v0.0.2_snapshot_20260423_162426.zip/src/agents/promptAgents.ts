import {
  PROMPT_CARD_HEADER_RULE,
  PROMPT_CARD_SECTION_HEADINGS,
  PROMPT_COPY_CHAR_LIMIT_RULE,
  PROMPT_DEPT_AGENT_SYSTEM,
  PROMPT_DEPT_OUTPUT_SHAPE,
  PROMPT_LOCAL_COMPRESSION_RULE,
  PROMPT_LEADER_SPEC,
  PROMPT_MOUNT_TOKEN_RULE,
} from '@/agents/promptDeptSpec';
import { tryParseStoryboardOutput } from '@/agents/storyboardAgents';
import { invokeLlmJsonObjectStream, invokeLlmLeaderReview } from '@/services/llmJsonClient';
import { resolveAndComposeMountedSkills } from '@/services/skillLoader';
import type {
  ApprovedAsset,
  PromptOutput,
  PromptShotDimensions,
  PromptShotPack,
  StoryboardOutput,
  StoryboardShot,
} from '@/types/studio';
import { promptAssetRefsFromApproved } from '@/utils/promptAssetRefs';
export {
  PROMPT_DEPT_AGENT_SYSTEM,
  PROMPT_DEPT_OUTPUT_SHAPE,
  PROMPT_LEADER_SPEC,
} from '@/agents/promptDeptSpec';

const DEFAULT_NEG =
  'low quality, blurry, watermark, subtitle, text overlay, logo, deformed hands, extra limbs, flicker, temporal inconsistency, oversaturated';
const MAX_PROMPT_CHARS = 2500;
const MAX_SEEDANCE_CARD_CHARS = 1800;
const SEEDANCE_PROMPT_SECTION_INDEX = 9;
const SEEDANCE_OPTIONAL_SECTION_INDICES = new Set<number>();
const MOUNT_TOKEN_RE = /\|@=([^|\n]+)\|/g;
const PROMPT_TIMING_SYSTEM_RULE = [
  '【时长规划】不要把 15 秒当作默认值，也不要为了凑满 15 秒而拉长镜头。',
  '- 每条镜头或连续镜头组都要先根据 description、content、action、movement、durationSec、note 判断真正需要的总时长。',
  '- 如果输入已给出 durationSec，优先服从它；如果没有，就由你按动作复杂度、镜头数量、对白长度、情绪停顿、景别切换量和信息密度自行估算。',
  '- 总时长必须不超过 15 秒，但完全可以是 3 秒、5 秒、8 秒、12 秒等更合理的值。',
  '- 如果镜头包含 mergedMembers，必须为每个子镜头分配明确秒数和时间区间，写出类似“镜头1 0-1.5秒；镜头2 1.5-2.3秒；镜头3 2.3-5秒”的结果。',
  '- 禁止平均分配时长，禁止无内容硬拖时长，禁止为了凑时长重复同一动作或同一情绪停顿。',
  '- seedanceCard 首行中的“X秒”必须是你判断后的真实总时长，不得固定写 15 秒。',
  '- 只有“摄影机动态参数”需要显式写出总时长和每段时长分配；其它模块不要重复写时间区间。',
].join('\\n');
const STRUCTURED_FIELD_NOISE_RE = /文字生成版|无素材|角色资产|场景资产|半空中袖|口一翻/;
const ACTION_FRAGMENT_TOKEN_RE =
  /^(?:探头|探身|回头|转身|抬手|收枪|落锁|关门|开口|低声|沉声|冷声|停在|停住|看见|看向|望向|闪身|逼近|后撤|甩袖|翻腕)$/;

function looksNoisyStructuredToken(token: string): boolean {
  const trimmed = token.trim();
  if (!trimmed) return true;
  if (STRUCTURED_FIELD_NOISE_RE.test(trimmed)) return true;
  if (ACTION_FRAGMENT_TOKEN_RE.test(trimmed)) return true;
  if (/^[\u4e00-\u9fa5]{2,6}(?:在|着|了)$/.test(trimmed) && !/屋内|屋外|门内|门外|屏风后/.test(trimmed)) {
    return true;
  }
  return false;
}

const PROMPT_DIMENSION_KEYS = [
  '场景',
  '角色',
  '动作',
  '情感',
  '镜头',
  '运镜',
  '灯光',
  '风格',
  '构图',
  '连贯性',
] as const;

function normalizePromptDimensions(value: unknown, idx: number): PromptShotDimensions {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`Prompt 模型返回：shotPrompts[${idx}] 缺少完整 dimensions 对象。`);
  }
  const raw = value as Record<string, unknown>;
  const out: PromptShotDimensions = {};
  for (const key of PROMPT_DIMENSION_KEYS) {
    out[key] = typeof raw[key] === 'string' ? String(raw[key]).trim() : '';
  }
  return out;
}

function assertSeedanceCard(shotId: string, seedanceCard: string): string {
  const card = seedanceCard.trim();
  if (!card) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 缺少 seedanceCard。`);
  }
  const firstLine = card
    .split(/\r?\n/)
    .map((line) => line.trim())
    .find(Boolean);
  if (!firstLine?.startsWith('【分镜')) {
    throw new Error(
      `Prompt 模型返回：镜头 ${shotId} 的 seedanceCard 首行不是结构化标题。${PROMPT_CARD_HEADER_RULE}`,
    );
  }
  const missing = PROMPT_CARD_SECTION_HEADINGS.filter((heading) => !card.includes(heading));
  if (missing.length) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 seedanceCard 缺少固定栏位：${missing.join('、')}。`);
  }
  if (!card.includes('9:16') || !card.includes('16:9')) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 seedanceCard 缺少 9:16 或 16:9 双版本构图。`);
  }
  const mountSection = card.match(/挂载[\s\S]*?(?:\n\s*\n|相机位置|相机朝向|角色朝向|构图提点)/)?.[0] ?? '';
  const mountTokens = Array.from(mountSection.matchAll(MOUNT_TOKEN_RE))
    .map((match) => String(match[1] ?? '').trim())
    .filter(Boolean);
  if (mountTokens.length < 2) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的挂载区不合格。${PROMPT_MOUNT_TOKEN_RULE}`);
  }
  if (mountTokens.some((token) => looksNoisyStructuredToken(token))) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的挂载区混入了动作残片、截断短语或占位符。`);
  }
  const mustShowSection = card.match(/【目标物Must-Show】[\s\S]*?(?:\n\s*\n|【参考分工】)/)?.[0] ?? '';
  const mustShowTokens = mustShowSection
    .replace('【目标物Must-Show】', '')
    .split(/[、/；\n]/)
    .map((item) => item.trim())
    .filter(Boolean);
  if (mustShowTokens.some((token) => looksNoisyStructuredToken(token))) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 Must-Show 含有噪声短语或动作残片。`);
  }
  return card;
}

function assertPromptBody(shotId: string, prompt: string): string {
  const normalized = prompt.replace(/\r/g, '').replace(/\n{3,}/g, '\n\n').trim();
  if (!normalized) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 prompt 为空。`);
  }
  if (looksTruncatedPromptText(normalized)) {
    throw new Error(`Prompt output for shot ${shotId} ends with an ellipsis and looks incomplete.`);
  }
  if (normalized.includes('镜头身份：') || normalized.includes('场面机制：') || normalized.includes('结果锚定：')) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 prompt 仍是结构栏目复述，没有压缩成可复制执行文本。`);
  }
  return normalized;
}

function looksTruncatedPromptText(value: string): boolean {
  const trimmed = value.trim();
  if (!trimmed) return false;
  return /(?:\.{3}|\u2026+)\s*$/.test(trimmed);
}

function seedanceCharCount(value: string): number {
  return Array.from(value).length;
}

function normalizeSeedanceInline(value: string): string {
  return value
    .replace(/\r/g, '')
    .replace(/\n+/g, ' ')
    .replace(/[ \t]+/g, ' ')
    .replace(/\s*([；;，,。])/g, '$1')
    .replace(/([；;，,。])\s*/g, '$1')
    .trim();
}

function clampSeedanceInline(value: string, maxChars: number): string {
  const normalized = normalizeSeedanceInline(value);
  if (seedanceCharCount(normalized) <= maxChars) return normalized;
  return `${Array.from(normalized).slice(0, Math.max(0, maxChars - 1)).join('')}…`;
}

function splitSeedanceClauses(value: string): string[] {
  return normalizeSeedanceInline(value)
    .split(/[；;。]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function compactSeedanceClauses(value: string, maxChars: number, maxClauses = 3): string {
  const clauses = splitSeedanceClauses(value);
  if (!clauses.length) return clampSeedanceInline(value, maxChars);
  const kept: string[] = [];
  for (const clause of clauses) {
    if (kept.length >= maxClauses) break;
    const compactClause = clampSeedanceInline(
      clause,
      Math.max(8, Math.floor(maxChars / Math.max(1, maxClauses))),
    );
    const candidate = [...kept, compactClause].join('；');
    if (seedanceCharCount(candidate) > maxChars && kept.length) break;
    kept.push(compactClause);
  }
  return clampSeedanceInline(kept.join('；') || clauses[0], maxChars);
}

function compactShotSegments(value: string, maxSegmentChars = 18): string {
  const normalized = normalizeSeedanceInline(value);
  const parts = normalized.split(/(?=镜头\d+)/).map((item) => item.trim()).filter(Boolean);
  if (parts.length <= 1) return '';
  return parts
    .map((part, index) => {
      const match = part.match(/镜头(\d+)(?:\/镜头\d+)?[:：]?(.+)?/);
      const id = match?.[1] ?? String(index + 1);
      const body = match?.[2]?.trim() || part;
      return `镜${id}:${compactSeedanceClauses(body, maxSegmentChars, 2)}`;
    })
    .join('；');
}

function compactLabeledBody(
  value: string,
  labels: Array<{ label: string; short: string }>,
  maxChars: number,
): string {
  const normalized = normalizeSeedanceInline(value);
  const parts = labels
    .map(({ label, short }) => {
      const escaped = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const match = normalized.match(new RegExp(`${escaped}[:：]?([^；;]+)`));
      if (!match?.[1]) return '';
      return `${short}=${clampSeedanceInline(match[1], 14)}`;
    })
    .filter(Boolean);
  if (!parts.length) return compactSeedanceClauses(normalized, maxChars, 3);
  return clampSeedanceInline(parts.join('；'), maxChars);
}

function compactMustShowBody(value: string): string {
  return value
    .split(/\n+/)
    .flatMap((line) => line.split(/[；;]/))
    .map((item) => item.replace(/^\d+\.\s*/, '').trim())
    .filter(Boolean)
    .slice(0, 6)
    .map((item) => clampSeedanceInline(item, 18))
    .join('；');
}

function compactReferenceBody(value: string): string {
  return value
    .split(/\n+/)
    .map((line) => normalizeSeedanceInline(line))
    .filter(Boolean)
    .slice(0, 3)
    .map((line) => {
      const [head, tail = ''] = line.split(/[:：]/, 2);
      return tail ? `${head}:${clampSeedanceInline(tail, 18)}` : clampSeedanceInline(head, 18);
    })
    .join('\n');
}

function compactNailsBody(value: string): string {
  return value
    .split(/\n+/)
    .map((line) => normalizeSeedanceInline(line))
    .filter(Boolean)
    .slice(0, 4)
    .map((line) => {
      const [head, tail = ''] = line.split(/[:：]/, 2);
      return tail ? `${head}:${clampSeedanceInline(tail, 18)}` : clampSeedanceInline(head, 18);
    })
    .join('\n');
}

function compactMountBody(value: string): string {
  const parts = normalizeSeedanceInline(value)
    .split(/[；;\n]/)
    .map((item) => item.trim())
    .filter(Boolean)
    .slice(0, 4)
    .map((item) => clampSeedanceInline(item, 24));
  return parts.join('；');
}

function compactSeedanceSectionBodyV2(index: number, body: string): string {
  const normalized = body.trim();
  if (!normalized) return normalized;
  if (index === SEEDANCE_PROMPT_SECTION_INDEX) return normalized;
  switch (index) {
    case 0:
      return compactMountBody(normalized);
    case 1:
    case 2:
    case 3:
    case 6:
    case 7:
    case 8:
      return compactSeedanceClauses(normalized, 54, 3);
    case 4:
      return compactLabeledBody(
        normalized,
        [
          { label: '前景', short: '前' },
          { label: '中景', short: '中' },
          { label: '后景', short: '后' },
          { label: '焦点落点', short: '焦点' },
        ],
        84,
      );
    case 5:
      return compactLabeledBody(
        normalized,
        [
          { label: '光源', short: '光源' },
          { label: '明暗关系', short: '明暗' },
          { label: '层次分配', short: '层次' },
          { label: '灯光任务', short: '任务' },
        ],
        96,
      );
    case 10:
      return compactLabeledBody(
        normalized,
        [
          { label: '主镜', short: '主镜' },
          { label: '关键节点', short: '节点' },
          { label: '动态策略', short: '策略' },
        ],
        84,
      );
    case 11:
      return compactSeedanceClauses(normalized, 72, 3);
    case 12:
      return compactLabeledBody(
        normalized,
        [
          { label: '插针', short: '插针' },
          { label: '甩拍', short: '甩拍' },
          { label: '慢镜头', short: '慢镜' },
        ],
        72,
      );
    case 13:
      return compactSeedanceClauses(normalized, 60, 3);
    case 14:
      return compactNailsBody(normalized);
    default:
      return compactSeedanceClauses(normalized, 48, 3);
  }
}

function assertSeedanceCardV2(shotId: string, seedanceCard: string): string {
  const card = seedanceCard.trim();
  if (!card) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 缺少 seedanceCard。`);
  }
  const firstLine = card
    .split(/\r?\n/)
    .map((line) => line.trim())
    .find(Boolean);
  if (!firstLine?.startsWith('【分镜')) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 seedanceCard 首行不是结构化标题。${PROMPT_CARD_HEADER_RULE}`);
  }
  const missing = PROMPT_CARD_SECTION_HEADINGS.filter((heading) => !card.includes(heading));
  if (missing.length) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 seedanceCard 缺少固定栏位：${missing.join('、')}。`);
  }

  const { sections } = parseSeedanceCardSections(card);
  const sectionMap = new Map(sections.map((section) => [section.heading, section.body]));

  const mountBody = sectionMap.get('挂载')?.trim() ?? '';
  if (!mountBody || !/(角色：|场景：|声音：|道具：)/.test(mountBody)) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的挂载区不合格。${PROMPT_MOUNT_TOKEN_RULE}`);
  }
  const mountTokens = mountBody
    .split(/[；;\n]/)
    .map((item) => item.replace(/^(角色|场景|声音|道具)：/, '').trim())
    .filter(Boolean);
  if (!mountTokens.length || mountTokens.some((token) => looksNoisyStructuredToken(token))) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的挂载区混入了动作残片、截断短语或占位符。`);
  }

  const compositionBody = sectionMap.get('构图锚点')?.trim() ?? '';
  if (!/前景[:：]/.test(compositionBody) || !/中景[:：]/.test(compositionBody) || !/后景[:：]/.test(compositionBody)) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的构图锚点缺少前景 / 中景 / 后景。`);
  }

  const lightingBody = sectionMap.get('灯光布置与基调')?.trim() ?? '';
  if (!/光源[:：]/.test(lightingBody) || !/灯光任务[:：]/.test(lightingBody)) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的灯光布置与基调缺少光源或灯光任务。`);
  }

  const continuityBody = sectionMap.get('连续性约束')?.trim() ?? '';
  if (!/(必须|不能|先|再|最后|始终)/.test(continuityBody)) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的连续性约束缺少硬约束语气。`);
  }

  const nailsBody = sectionMap.get('钉子4行')?.trim() ?? '';
  const nailLines = nailsBody
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean);
  if (nailLines.length !== 4) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的钉子4行不是严格四行。`);
  }

  return card;
}

function assertPromptBodyV2(shotId: string, prompt: string): string {
  const normalized = prompt.replace(/\r/g, '').replace(/\n{3,}/g, '\n\n').trim();
  if (!normalized) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 prompt 为空。`);
  }
  if (looksTruncatedPromptText(normalized)) {
    throw new Error(`Prompt output for shot ${shotId} ends with an ellipsis and looks incomplete.`);
  }
  if (
    normalized.includes('挂载：') ||
    normalized.includes('相机位置：') ||
    normalized.includes('灯光布置与基调：') ||
    normalized.includes('钉子4行：')
  ) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 prompt 仍是结构栏目复述，没有压缩成可复制执行文本。`);
  }
  return normalized;
}

type ParsedSeedanceSection = {
  heading: string;
  body: string;
};

function compactSeedanceSectionBody(index: number, body: string): string {
  const normalized = body.trim();
  if (!normalized) return normalized;
  if (index === SEEDANCE_PROMPT_SECTION_INDEX) return normalized;
  switch (index) {
    case 0: {
      const tokens = Array.from(normalized.matchAll(MOUNT_TOKEN_RE))
        .map((match) => `|@=${String(match[1] ?? '').trim()}|`)
        .filter(Boolean);
      return tokens.slice(0, 6).join(' ');
    }
    case 1:
      return compactShotSegments(normalized, 16) || compactSeedanceClauses(normalized, 42, 3);
    case 2:
      return compactShotSegments(normalized, 14) || compactSeedanceClauses(normalized, 38, 3);
    case 3:
      return compactSeedanceClauses(normalized, 34, 3);
    case 4:
      return compactLabeledBody(
        normalized,
        [
          { label: '前景', short: '前' },
          { label: '中景', short: '中' },
          { label: '后景', short: '后' },
          { label: '中心物', short: '中心' },
          { label: '遮挡关系', short: '遮挡' },
          { label: '焦点顺序', short: '焦点' },
        ],
        72,
      );
    case 5:
      return compactShotSegments(normalized, 15) || compactSeedanceClauses(normalized, 52, 3);
    case 6:
      return compactSeedanceClauses(normalized, 34, 2);
    case 7:
      return compactSeedanceClauses(normalized, 36, 2);
    case 8:
    case 9:
      return compactSeedanceClauses(normalized, 30, 2);
    case 10: {
      const vertical = normalized.match(/9:16[:：=]?([^;\n]+)/)?.[1]?.trim() || '';
      const wide = normalized.match(/16[:.]?9[:：=]?([^;\n]+)/)?.[1]?.trim() || '';
      return [`9:16=${clampSeedanceInline(vertical, 14)}`, `16:9=${clampSeedanceInline(wide, 16)}`]
        .filter((item) => !item.endsWith('='))
        .join('\n');
    }
    case 11:
      return compactSeedanceClauses(normalized, 34, 3);
    case 12:
      return compactSeedanceClauses(normalized, 40, 3);
    case 14:
      return compactMustShowBody(normalized);
    case 15:
      return compactReferenceBody(normalized);
    case 16:
      return compactSeedanceClauses(normalized, 38, 3);
    case 17:
      return compactSeedanceClauses(normalized, 34, 3);
    case 18:
      return compactReferenceBody(normalized);
    case 19:
      return compactSeedanceClauses(normalized, 30, 2);
    case 20:
      return compactNailsBody(normalized);
    default:
      return compactSeedanceClauses(normalized, 32, 2);
  }
}

function parseSeedanceCardSections(seedanceCard: string): { header: string; sections: ParsedSeedanceSection[] } {
  const lines = seedanceCard.replace(/\r/g, '').split('\n');
  const header = lines.find((line) => line.trim())?.trim() || '';
  const sections: ParsedSeedanceSection[] = [];
  let current: ParsedSeedanceSection | null = null;

  for (const line of lines.slice(1)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const heading = PROMPT_CARD_SECTION_HEADINGS.find((item) => trimmed === item);
    if (heading) {
      if (current) {
        current.body = current.body.trim();
        sections.push(current);
      }
      current = { heading, body: '' };
      continue;
    }
    if (current) {
      current.body = current.body ? `${current.body}\n${trimmed}` : trimmed;
    }
  }

  if (current) {
    current.body = current.body.trim();
    sections.push(current);
  }

  return { header, sections };
}

function renderParsedSeedanceCard(header: string, sections: ParsedSeedanceSection[]): string {
  const lines = [header, ''];
  for (const section of sections) {
    lines.push(section.heading, section.body || '同上', '');
  }
  while (lines.length && !lines[lines.length - 1]) lines.pop();
  return lines.join('\n').trim();
}

function tightenSeedanceCard(seedanceCard: string): string {
  const { header, sections } = parseSeedanceCardSections(seedanceCard);
  if (!header || !sections.length) return seedanceCard.trim();
  return renderParsedSeedanceCard(header, sections);
}

function parsePromptShotPackList(raw: unknown): PromptShotPack[] {
  if (!Array.isArray(raw) || raw.length === 0) {
    throw new Error('Prompt 模型返回：必须包含非空 `shotPrompts` 数组。');
  }
  return raw.map((item, idx) => {
    if (!item || typeof item !== 'object') {
      throw new Error(`Prompt 模型返回：shotPrompts[${idx}] 必须是对象。`);
    }
    const row = item as Record<string, unknown>;
    const shot_id = String(row.shot_id ?? row.shotId ?? '').trim();
    const prompt = String(row.prompt ?? '').trim();
    const negative_prompt =
      String(row.negative_prompt ?? row.negativePrompt ?? DEFAULT_NEG).trim() || DEFAULT_NEG;
    if (!shot_id) {
      throw new Error(`Prompt 模型返回：shotPrompts[${idx}] 缺少 shot_id。`);
    }
    if (!prompt) {
      throw new Error(`Prompt 模型返回：shotPrompts[${idx}] 缺少 prompt。`);
    }
    const dimensions = normalizePromptDimensions(row.dimensions, idx);
    const character_asset_ids = Array.isArray(row.character_asset_ids)
      ? row.character_asset_ids.map((value) => String(value))
      : [];
    const scene_asset_ids = Array.isArray(row.scene_asset_ids)
      ? row.scene_asset_ids.map((value) => String(value))
      : [];
    return {
      shot_id,
      prompt,
      negative_prompt,
      dimensions,
      character_asset_ids,
      scene_asset_ids,
      seedanceCard: typeof row.seedanceCard === 'string' ? row.seedanceCard : '',
    };
  });
}

export function assertPromptOutput(
  value: unknown,
  fallback?: Partial<Pick<PromptOutput, 'system' | 'userTemplate' | 'negative' | 'parameters'>>,
): PromptOutput {
  if (!value || typeof value !== 'object') {
    throw new Error('Prompt 模型返回：顶层必须是 JSON 对象。');
  }
  const raw = value as Record<string, unknown>;
  const system =
    typeof raw.system === 'string' && raw.system.trim()
      ? raw.system.trim()
      : typeof fallback?.system === 'string' && fallback.system.trim()
        ? fallback.system.trim()
        : '';
  if (!system) {
    throw new Error('Prompt 模型返回：缺少非空 `system`。');
  }
  const userTemplate =
    typeof raw.userTemplate === 'string'
      ? raw.userTemplate
      : typeof fallback?.userTemplate === 'string'
        ? fallback.userTemplate
        : '';
  if (typeof userTemplate !== 'string') {
    throw new Error('Prompt 模型返回：缺少 `userTemplate`。');
  }
  const rawParameters =
    raw.parameters && typeof raw.parameters === 'object' && !Array.isArray(raw.parameters)
      ? (raw.parameters as Record<string, unknown>)
      : fallback?.parameters && typeof fallback.parameters === 'object'
        ? fallback.parameters
        : null;
  if (!rawParameters || Array.isArray(rawParameters)) {
    throw new Error('Prompt 模型返回：缺少 `parameters` 对象。');
  }
  const parameters: Record<string, string> = {};
  for (const [key, item] of Object.entries(rawParameters)) {
    parameters[key] = item == null ? '' : String(item);
  }
  const negative =
    typeof raw.negative === 'string' && raw.negative.trim()
      ? raw.negative.trim()
      : typeof fallback?.negative === 'string' && fallback.negative.trim()
        ? fallback.negative.trim()
        : DEFAULT_NEG;
  return {
    system,
    userTemplate,
    negative,
    parameters,
    shotPrompts: parsePromptShotPackList(raw.shotPrompts),
  };
}

function normalizeShotIdToken(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  const digits = trimmed.match(/\d+/g)?.join('-') ?? '';
  return digits || trimmed.toLowerCase();
}

function tryParseStoryboardFromInputText(raw: string): StoryboardOutput | null {
  const trimmed = raw.trim();
  const direct = tryParseStoryboardOutput(trimmed);
  if (direct) return direct;
  try {
    return tryParseStoryboardOutput(JSON.parse(trimmed));
  } catch {
    const objectStart = trimmed.indexOf('{');
    const objectEnd = trimmed.lastIndexOf('}');
    if (objectStart !== -1 && objectEnd > objectStart) {
      try {
        return tryParseStoryboardOutput(JSON.parse(trimmed.slice(objectStart, objectEnd + 1)));
      } catch {
        return null;
      }
    }
    return null;
  }
}

function findSourceShot(sourceStoryboard: StoryboardOutput | null, pack: PromptShotPack, index: number): StoryboardShot | null {
  if (!sourceStoryboard?.shots?.length) return null;
  const targetToken = normalizeShotIdToken(pack.shot_id);
  return (
    sourceStoryboard.shots.find((shot) => normalizeShotIdToken(String(shot.id)) === targetToken) ??
    sourceStoryboard.shots[index] ??
    null
  );
}

function normalizePromptOutput(output: PromptOutput, sourceStoryboard: StoryboardOutput | null): PromptOutput {
  const shotPrompts = (output.shotPrompts ?? []).map((pack, index) => {
    const sourceShot = findSourceShot(sourceStoryboard, pack, index);
    return {
      ...pack,
      shot_id: sourceShot ? String(sourceShot.id) : pack.shot_id,
      prompt: String(pack.prompt ?? '').replace(/\r/g, '').replace(/\n{3,}/g, '\n\n').trim(),
      seedanceCard:
        typeof pack.seedanceCard === 'string' ? tightenSeedanceCard(pack.seedanceCard) : '',
    };
  });
  return {
    ...output,
    parameters: {
      ...output.parameters,
      format: output.parameters.format || 'sd2_storyboard_dense_v2',
    },
    shotPrompts,
  };
}

function outputNeedsCompressionRepair(output: PromptOutput): boolean {
  return (output.shotPrompts ?? []).some((pack) => {
    const prompt = String(pack.prompt ?? '').trim();
    if (prompt && Array.from(prompt).length > MAX_PROMPT_CHARS) return true;
    return false;
  });
}

function stripLineEndingEllipsis(value: string): string {
  return value
    .replace(/\r/g, '')
    .split('\n')
    .map((line) => line.replace(/(?:\.{3}|\u2026+)\s*$/g, '').trimEnd())
    .join('\n')
    .trim();
}

function sanitizePromptOutputEllipsis(output: PromptOutput): PromptOutput {
  return {
    ...output,
    shotPrompts: (output.shotPrompts ?? []).map((pack) => ({
      ...pack,
      prompt: stripLineEndingEllipsis(pack.prompt ?? ''),
      seedanceCard: stripLineEndingEllipsis(pack.seedanceCard ?? ''),
    })),
  };
}

function validatePromptCoverage(output: PromptOutput, sourceStoryboard: StoryboardOutput | null): void {
  if (!sourceStoryboard?.shots?.length) return;
  const expected = sourceStoryboard.shots.map((shot) => String(shot.id));
  const actual = output.shotPrompts?.map((shot) => shot.shot_id) ?? [];
  if (actual.length !== expected.length) {
    throw new Error(
      `Prompt 输出镜头数量不完整：镜头表共 ${expected.length} 条镜头，但当前仅生成了 ${actual.length} 条。`,
    );
  }
  const expectedSet = new Set(expected.map(normalizeShotIdToken));
  const actualSet = new Set(actual.map(normalizeShotIdToken));
  for (const id of expectedSet) {
    if (!actualSet.has(id)) {
      throw new Error('Prompt 输出镜头编号不完整：未覆盖镜头表中的全部镜头。');
    }
  }
  for (const pack of output.shotPrompts ?? []) {
    if (Array.from(pack.prompt).length > MAX_PROMPT_CHARS) {
      throw new Error(`Prompt 输出超出字数限制：镜头 ${pack.shot_id} 的提示词超过 2500 字。`);
    }
    assertPromptBodyV2(pack.shot_id, pack.prompt);
    if (!String(pack.seedanceCard ?? '').trim()) {
      throw new Error(`Prompt 模型返回：镜头 ${pack.shot_id} 缺少 seedanceCard。`);
    }
  }
}

function buildPromptUserMessage(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput | null,
): string {
  const sourceShotHints =
    sourceStoryboard?.shots?.length
      ? [
          `【源镜头总数】${sourceStoryboard.shots.length}`,
          `【源镜头编号】${sourceStoryboard.shots.map((shot) => shot.id).join(', ')}`,
          '【硬性要求】你必须为每一条源镜头各生成一条 shotPrompts 项，数量必须与源镜头完全一致，不得只输出第一条镜头。',
        ].join('\n')
      : '';
  return [
    '以下是部门 Input 正文，可能是镜头表 JSON，也可能是自然语言补充。请输出完整 PromptOutput JSON。',
    '',
    '【模板硬约束】',
    PROMPT_CARD_HEADER_RULE,
    PROMPT_MOUNT_TOKEN_RULE,
    PROMPT_COPY_CHAR_LIMIT_RULE,
    PROMPT_LOCAL_COMPRESSION_RULE,
    PROMPT_TIMING_SYSTEM_RULE,
    'prompt body must not end with `...` or a unicode ellipsis; it must close on a complete result beat.',
    'seedanceCard 标题中的秒数必须是按内容推算出的真实总时长，不得固定写 15 秒。',
    '如果一条镜头组实际 5 秒就能完成，就写 5 秒；不要因为上限是 15 秒就把所有内容拉满到 15 秒。',
    '连续镜头组的秒数占比和时间区间只写在“摄影机动态参数”里，其它模块不要重复写。',
    'prompt 本体必须是“提示词(复制到即梦)”类型的压缩执行文本，不得逐条复述栏目标题。',
    '空镜、环境镜、道具镜、无人物镜头里，不要写眼神、微表情、角色朝向等人物描述。',
    `seedanceCard 必须按以下顺序完整包含栏位：${PROMPT_CARD_SECTION_HEADINGS.join('、')}。`,
    '“【双版本锚】”内必须同时出现 9:16 与 16:9。',
    '“提示词(复制到即梦)”必须是可直接复制执行的中文主导版本。',
    '“【目标物Must-Show】”“【参照/覆盖/稳帧】”“【声画同步】”“【微表情】”“【文戏附加】”“【钉子4行】”不得缺失。',
    '',
    '【定稿依据】若 Input 含 JSON 字段 `shots`，其中每条镜头的 `description`、`content` 均视为最终定稿，生成时必须逐镜落实。',
    '【同场合并】若某条镜头含 `mergedMembers`，对应项中的 `prompt` 与 `seedanceCard` 都要明确写出镜头1 / 镜头2 / 镜头3 的连续推进。',
    sourceShotHints,
    '',
    '【资产占位 ID】请为各 shot 写入 `character_asset_ids` / `scene_asset_ids`；没有真实 ID 时可留空数组，但键不可缺失。',
    JSON.stringify(assetRefs, null, 2),
    '',
    '--- Input ---',
    brief.trim() || '（空）',
  ]
    .filter(Boolean)
    .join('\n');
}

function buildCoverageRepairUserMessage(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput,
  invalidOutput: PromptOutput,
  failureReason?: string,
): string {
  const invalidShotPrompts = invalidOutput.shotPrompts ?? [];
  const failureSummary = failureReason ? `[Previous failure] ${failureReason}` : '';
  return [
    failureSummary,
    '你上一次返回的 PromptOutput 不完整，请重新输出完整 JSON。',
    `【必须覆盖的镜头总数】${sourceStoryboard.shots.length}`,
    `【必须覆盖的镜头编号】${sourceStoryboard.shots.map((shot) => shot.id).join(', ')}`,
    `【上一次返回的镜头编号】${invalidShotPrompts.map((shot) => shot.shot_id).join(', ')}`,
    '硬性要求：',
    '1. shotPrompts.length 必须等于源镜头数。',
    '2. 每一条源镜头都必须有对应 shot_id。',
    '3. 每个 shot 都必须带完整 seedanceCard，不得缺少固定栏位。',
    `4. “挂载”必须符合这条规则：${PROMPT_MOUNT_TOKEN_RULE}`,
    `5. “提示词(复制到即梦)”必须符合这条规则：${PROMPT_COPY_CHAR_LIMIT_RULE}`,
    '6. prompt 本体必须是压缩后的执行文本，不得逐条复述栏目标题。',
    '7. 空镜/无人物镜头不得出现眼神、微表情、角色朝向等人物描述。',
    '8. 不得返回解释文本、markdown 或半截 JSON。',
    '',
    '【固定栏位】',
    PROMPT_CARD_SECTION_HEADINGS.join('、'),
    '',
    '【资产占位 ID】',
    JSON.stringify(assetRefs, null, 2),
    '',
    '【源镜头表】',
    JSON.stringify(sourceStoryboard, null, 2),
    '',
    '【上一次不完整的输出】',
    JSON.stringify(invalidOutput, null, 2),
    '',
    '【原始 Input】',
    brief.trim() || '（空）',
  ].join('\n');
}

function buildCompressionRepairUserMessage(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput | null,
  draftOutput: PromptOutput,
): string {
  return [
    '你上一次返回的 PromptOutput 语义基本可用，但长度与结构压缩不符合当前工具的本地压缩规则。请在不改坏镜头语义的前提下，重写为更短、更稳的版本。',
    '',
    '【本次修订目标】',
    PROMPT_COPY_CHAR_LIMIT_RULE,
    PROMPT_LOCAL_COMPRESSION_RULE,
    '禁止简单截断，禁止在结尾补 `...` 或 `…`，禁止删除固定标题，禁止把同一句原文重复灌入多个模块。',
    '如果某些信息必须压缩，优先压缩非核心模块，而不是删掉镜头命题、主事件、关系变化、空间切割、焦点顺序、结果位和 Must-Show。',
    '',
    '【资产占位 ID】',
    JSON.stringify(assetRefs, null, 2),
    '',
    sourceStoryboard
      ? ['【源镜头表】', JSON.stringify(sourceStoryboard, null, 2), ''].join('\n')
      : '',
    '【待压缩的当前输出】',
    JSON.stringify(draftOutput, null, 2),
    '',
    '【原始 Input】',
    brief.trim() || '（空）',
  ]
    .filter(Boolean)
    .join('\n');
}

function buildPromptUserMessageV2(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput | null,
): string {
  const sourceShotHints =
    sourceStoryboard?.shots?.length
      ? [
          `【源镜头总数】${sourceStoryboard.shots.length}`,
          `【源镜头编号】${sourceStoryboard.shots.map((shot) => shot.id).join(', ')}`,
          '【硬性要求】你必须为每一条源镜头各生成一条 shotPrompts 项，数量必须与源镜头完全一致，不得只输出第一条镜头。',
        ].join('\n')
      : '';
  return [
    '以下是部门 Input 正文，可能是镜头表 JSON，也可能是自然语言补充。请输出完整 PromptOutput JSON。',
    '',
    '【模板硬约束】',
    PROMPT_CARD_HEADER_RULE,
    PROMPT_MOUNT_TOKEN_RULE,
    PROMPT_COPY_CHAR_LIMIT_RULE,
    PROMPT_LOCAL_COMPRESSION_RULE,
    PROMPT_TIMING_SYSTEM_RULE,
    'prompt body must not end with `...` or a unicode ellipsis; it must close on a complete result beat.',
    'prompt 本体必须是压缩后的执行文本，不得逐条复述栏目标题。',
    '空镜、环境镜、道具镜、无人物镜头里，不要硬写人物眼神、嘴角或面部停顿。',
    `seedanceCard 必须按以下顺序完整包含栏位：${PROMPT_CARD_SECTION_HEADINGS.join('、')}。`,
    '“构图锚点”必须写出前景 / 中景 / 后景 / 焦点落点。',
    '“灯光布置与基调”必须同时写出光源、明暗关系、层次分配、灯光任务。',
    '“连续性约束”必须带硬约束语气，明确方向、顺序与接镜规则。',
    '“摄影机动态参数”必须是主镜参数、关键节点参数和动态策略的组合。',
    '“插针 / 甩拍 / 慢镜头”必须写清是否使用与使用瞬间，不用时明确写“无”。',
    '“钉子4行”必须严格四行。',
    '',
    '【定稿依据】若 Input 含 JSON 字段 `shots`，其中每条镜头的 `description`、`content` 均视为最终定稿，生成时必须逐镜落实。',
    '【同场合并】若某条镜头含 `mergedMembers`，对应项中的 `prompt` 与 `seedanceCard` 都要明确写出镜头1 / 镜头2 / 镜头3 的连续推进。',
    sourceShotHints,
    '',
    '【资产占位 ID】请为各 shot 写入 `character_asset_ids` / `scene_asset_ids`；没有真实 ID 时可留空数组，但键不可缺失。',
    JSON.stringify(assetRefs, null, 2),
    '',
    '--- Input ---',
    brief.trim() || '（空）',
  ].filter(Boolean).join('\n');
}

function buildCoverageRepairUserMessageV2(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput,
  invalidOutput: PromptOutput,
  failureReason?: string,
): string {
  const invalidShotPrompts = invalidOutput.shotPrompts ?? [];
  const failureSummary = failureReason ? `[Previous failure] ${failureReason}` : '';
  return [
    failureSummary,
    '你上一次返回的 PromptOutput 不完整，请重新输出完整 JSON。',
    `【必须覆盖的镜头总数】${sourceStoryboard.shots.length}`,
    `【必须覆盖的镜头编号】${sourceStoryboard.shots.map((shot) => shot.id).join(', ')}`,
    `【上一次返回的镜头编号】${invalidShotPrompts.map((shot) => shot.shot_id).join(', ')}`,
    '硬性要求：',
    '1. shotPrompts.length 必须等于源镜头数。',
    '2. 每一条源镜头都必须有对应 shot_id。',
    '3. 每个 shot 都必须带完整 seedanceCard，不得缺少固定栏位。',
    `4. “挂载”必须符合这条规则：${PROMPT_MOUNT_TOKEN_RULE}`,
    `5. “提示词”必须符合这条规则：${PROMPT_COPY_CHAR_LIMIT_RULE}`,
    '6. “构图锚点”必须写出前景 / 中景 / 后景 / 焦点落点。',
    '7. “灯光布置与基调”必须写出光源、明暗关系、层次分配、灯光任务。',
    '8. “连续性约束”必须使用必须 / 不能 / 先 / 再 / 最后 / 始终保持这类硬约束语气。',
    '9. “钉子4行”必须严格四行。',
    '10. prompt 本体必须是压缩后的执行文本，不得逐条复述栏目标题。',
    '11. 空镜 / 无人物镜头不许写人物眼神、嘴角或面部停顿。',
    '12. 不得返回解释文本、markdown 或半截 JSON。',
    '',
    '【固定栏位】',
    PROMPT_CARD_SECTION_HEADINGS.join('、'),
    '',
    '【资产占位 ID】',
    JSON.stringify(assetRefs, null, 2),
    '',
    '【源镜头表】',
    JSON.stringify(sourceStoryboard, null, 2),
    '',
    '【上一次不完整的输出】',
    JSON.stringify(invalidOutput, null, 2),
    '',
    '【原始 Input】',
    brief.trim() || '（空）',
  ].join('\n');
}

function buildCompressionRepairUserMessageV2(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput | null,
  draftOutput: PromptOutput,
): string {
  return [
    '你上一次返回的 PromptOutput 语义基本可用，但长度与结构压缩不符合当前工具的本地压缩规则。请在不破坏镜头语义的前提下，重写为更短、更稳的版本。',
    '',
    '【本次修订目标】',
    PROMPT_COPY_CHAR_LIMIT_RULE,
    PROMPT_LOCAL_COMPRESSION_RULE,
    '禁止简单截断，禁止在结尾补 `...` 或 `…`，禁止删除固定标题，禁止把同一句原文重复灌入多个模块。',
    '如果某些信息必须压缩，优先压缩非核心模块，而不是删掉构图前中后景、灯光任务、连续性约束、提示词和钉子4行。',
    '',
    '【资产占位 ID】',
    JSON.stringify(assetRefs, null, 2),
    '',
    sourceStoryboard ? ['【源镜头表】', JSON.stringify(sourceStoryboard, null, 2), ''].join('\n') : '',
    '【待压缩的当前输出】',
    JSON.stringify(draftOutput, null, 2),
    '',
    '【原始 Input】',
    brief.trim() || '（空）',
  ].filter(Boolean).join('\n');
}

function buildPromptUserMessageV3(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput | null,
): string {
  const sourceShotHints =
    sourceStoryboard?.shots?.length
      ? [
          `【源镜头总数】${sourceStoryboard.shots.length}`,
          `【源镜头编号】${sourceStoryboard.shots.map((shot) => shot.id).join(', ')}`,
          '【硬性要求】你必须为每一条源镜头各生成一条 shotPrompts 项，数量必须与源镜头完全一致，不得只输出第一条镜头。',
        ].join('\n')
      : '';

  return [
    '以下是部门 Input 正文，可能是镜头表 JSON，也可能是自然语言补充。请输出完整 PromptOutput JSON。',
    '',
    '【模板硬约束】',
    PROMPT_CARD_HEADER_RULE,
    PROMPT_MOUNT_TOKEN_RULE,
    PROMPT_COPY_CHAR_LIMIT_RULE,
    PROMPT_LOCAL_COMPRESSION_RULE,
    PROMPT_TIMING_SYSTEM_RULE,
    'prompt body must not end with `...` or a unicode ellipsis; it must close on a complete result beat.',
    'seedanceCard 标题中的秒数必须是按内容推算出的真实总时长，不得固定写 15 秒。',
    '如果一条镜头组实际 5 秒就能完成，就写 5 秒；不要因为上限是 15 秒就把所有内容拉满到 15 秒。',
    '连续镜头组必须显式写出每个子镜头的秒数占比和时间区间，并让时长与动作密度匹配。',
    'prompt 本体必须是压缩后的执行文本，不得逐条复述栏目标题。',
    '空镜、环境镜、道具镜、无人物镜头里，不要硬写人物眼神、嘴角或面部停顿。',
    `seedanceCard 必须按以下顺序完整包含栏位：${PROMPT_CARD_SECTION_HEADINGS.join('、')}。`,
    '“构图锚点”必须写出前景 / 中景 / 后景 / 焦点落点。',
    '“灯光布置与基调”必须同时写出光源、明暗关系、层次分配、灯光任务。',
    '“连续性约束”必须带硬约束语气，明确方向、顺序与接镜规则。',
    '“摄影机动态参数”必须是主镜参数、关键节点参数和动态策略的组合。',
    '“插针 / 甩拍 / 慢镜头”必须写清是否使用与使用瞬间，不用时明确写“无”。',
    '“钉子4行”必须严格四行。',
    '',
    '【定稿依据】若 Input 含 JSON 字段 `shots`，其中每条镜头的 `description`、`content`、`type`、`movement`、`sceneRef`、`action`、`durationSec`、`note` 均视为最终定稿，生成时必须逐镜落实。',
    '【同场合并】若某条镜头含 `mergedMembers`，对应项中的 `prompt` 与 `seedanceCard` 都要明确写出镜头1 / 镜头2 / 镜头3 的连续推进。',
    '【时长判断】先判断这一条镜头真正需要几秒，再写内容；不要先写满 15 秒再去塞动作。',
    '【时长分配】如果镜头很短，3 秒或 5 秒都可以；如果是连续动作组，再在总时长内合理分配给每个子镜头，但只在“摄影机动态参数”里展开写秒数。',
    sourceShotHints,
    '',
    '【资产占位 ID】请为各 shot 写入 `character_asset_ids` / `scene_asset_ids`；没有真实 ID 时可留空数组，但键不可缺失。',
    JSON.stringify(assetRefs, null, 2),
    '',
    '--- Input ---',
    brief.trim() || '（空）',
  ].filter(Boolean).join('\n');
}

function buildCoverageRepairUserMessageV3(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput,
  invalidOutput: PromptOutput,
  failureReason?: string,
): string {
  const invalidShotPrompts = invalidOutput.shotPrompts ?? [];
  const failureSummary = failureReason ? `[Previous failure] ${failureReason}` : '';

  return [
    failureSummary,
    '你上一次返回的 PromptOutput 不完整，请重新输出完整 JSON。',
    `【必须覆盖的镜头总数】${sourceStoryboard.shots.length}`,
    `【必须覆盖的镜头编号】${sourceStoryboard.shots.map((shot) => shot.id).join(', ')}`,
    `【上一次返回的镜头编号】${invalidShotPrompts.map((shot) => shot.shot_id).join(', ')}`,
    '硬性要求：',
    '1. shotPrompts.length 必须等于源镜头数。',
    '2. 每一条源镜头都必须有对应 shot_id。',
    '3. 每个 shot 都必须带完整 seedanceCard，不得缺少固定栏位。',
    `4. “挂载”必须符合这条规则：${PROMPT_MOUNT_TOKEN_RULE}`,
    `5. “提示词”必须符合这条规则：${PROMPT_COPY_CHAR_LIMIT_RULE}`,
    `6. 时长规划必须符合这条规则：${PROMPT_TIMING_SYSTEM_RULE}`,
    '7. “构图锚点”必须写出前景 / 中景 / 后景 / 焦点落点。',
    '8. “灯光布置与基调”必须写出光源、明暗关系、层次分配、灯光任务。',
    '9. “连续性约束”必须使用必须 / 不能 / 先 / 再 / 最后 / 始终保持这类硬约束语气。',
    '10. “钉子4行”必须严格四行。',
    '11. prompt 本体必须是压缩后的执行文本，不得逐条复述栏目标题。',
    '12. 空镜 / 无人物镜头不许写人物眼神、嘴角或面部停顿。',
    '13. 不得返回解释文本、markdown 或半截 JSON。',
    '14. 不得把标题时长固定写成 15 秒；必须根据镜头内容重新判断总时长与每段秒数。',
    '15. 秒数区间和分段时长只允许出现在“摄影机动态参数”里，起幅、落幅、连续性约束、提示词不要重复写。',
    '',
    '【固定栏位】',
    PROMPT_CARD_SECTION_HEADINGS.join('、'),
    '',
    '【资产占位 ID】',
    JSON.stringify(assetRefs, null, 2),
    '',
    '【源镜头表】',
    JSON.stringify(sourceStoryboard, null, 2),
    '',
    '【上一次不完整的输出】',
    JSON.stringify(invalidOutput, null, 2),
    '',
    '【原始 Input】',
    brief.trim() || '（空）',
  ].join('\n');
}

function buildCompressionRepairUserMessageV3(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput | null,
  draftOutput: PromptOutput,
): string {
  return [
    '你上一次返回的 PromptOutput 语义基本可用，但长度与结构压缩不符合当前工具的规则。请在不破坏镜头语义的前提下，重写为更短、更稳的版本。',
    '',
    '【本次修订目标】',
    PROMPT_COPY_CHAR_LIMIT_RULE,
    PROMPT_LOCAL_COMPRESSION_RULE,
    PROMPT_TIMING_SYSTEM_RULE,
    '禁止简单截断，禁止在结尾补 `...` 或 `…`，禁止删除固定标题，禁止把同一句原文重复灌入多个模块。',
    '如果某些信息必须压缩，优先压缩非核心模块，而不是删掉构图前中后景、灯光任务、连续性约束、提示词和钉子4行。',
    '压缩修订时不得改变已经合理的总时长和分段时长分配，不得把原本 5 秒可完成的镜头改写成 15 秒。',
    '压缩修订时也不要把秒数区间扩散到其它模块；秒数信息只保留在“摄影机动态参数”。',
    '',
    '【资产占位 ID】',
    JSON.stringify(assetRefs, null, 2),
    '',
    sourceStoryboard ? ['【源镜头表】', JSON.stringify(sourceStoryboard, null, 2), ''].join('\n') : '',
    '【待压缩的当前输出】',
    JSON.stringify(draftOutput, null, 2),
    '',
    '【原始 Input】',
    brief.trim() || '（空）',
  ].filter(Boolean).join('\n');
}

void assertSeedanceCard;
void assertPromptBody;
void assertSeedanceCardV2;
void compactSeedanceSectionBody;
void compactSeedanceSectionBodyV2;
void buildPromptUserMessage;
void buildPromptUserMessageV2;
void buildCoverageRepairUserMessage;
void buildCoverageRepairUserMessageV2;
void buildCompressionRepairUserMessage;
void buildCompressionRepairUserMessageV2;
void MAX_SEEDANCE_CARD_CHARS;
void SEEDANCE_OPTIONAL_SECTION_INDICES;

export async function runPromptEmployee(
  brief: string,
  approvedAssets: ApprovedAsset[] = [],
  executionSystemPrompt?: string,
  onDelta?: (delta: string, accumulated: string) => void,
  signal?: AbortSignal,
): Promise<PromptOutput> {
  const assetRefs = promptAssetRefsFromApproved(approvedAssets);
  const sourceStoryboard = tryParseStoryboardFromInputText(brief);
  const systemBase = executionSystemPrompt?.trim() || PROMPT_DEPT_AGENT_SYSTEM;
  const systemPrompt = `${systemBase}\n\n${PROMPT_TIMING_SYSTEM_RULE}\n\n【输出 JSON 形状参考】\n${PROMPT_DEPT_OUTPUT_SHAPE}`;
  const outputFallback: Partial<Pick<PromptOutput, 'system' | 'userTemplate' | 'negative' | 'parameters'>> = {
    system: systemBase,
    userTemplate: brief.trim() || 'Prompt generated from current storyboard input.',
    negative: DEFAULT_NEG,
    parameters: {
      engine: 'jimeng',
      aspect: '16:9',
      format: 'sd2_storyboard_dense_v2',
    },
  };

  let draftOutput = assertPromptOutput(
    await invokeLlmJsonObjectStream({
      systemPrompt,
      userPrompt: buildPromptUserMessageV3(brief, assetRefs, sourceStoryboard),
      temperature: 0.35,
      onDelta,
      signal,
    }),
    outputFallback,
  );

  if (outputNeedsCompressionRepair(draftOutput)) {
    draftOutput = assertPromptOutput(
      await invokeLlmJsonObjectStream({
        systemPrompt,
        userPrompt: buildCompressionRepairUserMessageV3(
          brief,
          assetRefs,
          sourceStoryboard,
          draftOutput,
        ),
        temperature: 0.2,
        onDelta,
        signal,
      }),
      outputFallback,
    );
  }

  let output = normalizePromptOutput(draftOutput, sourceStoryboard);

  try {
    validatePromptCoverage(output, sourceStoryboard);
    return sanitizePromptOutputEllipsis(output);
  } catch (error) {
    if (!sourceStoryboard?.shots?.length) throw error;
    const failureReason = error instanceof Error ? error.message : String(error);
    const repairedParsed = await invokeLlmJsonObjectStream({
      systemPrompt,
      userPrompt: buildCoverageRepairUserMessageV3(
        brief,
        assetRefs,
        sourceStoryboard,
        output,
        failureReason,
      ),
      temperature: 0.2,
      onDelta,
      signal,
    });
    output = normalizePromptOutput(assertPromptOutput(repairedParsed, outputFallback), sourceStoryboard);
    validatePromptCoverage(output, sourceStoryboard);
    return sanitizePromptOutputEllipsis(output);
  }
}

export type LeaderDecision = { approved: true } | { approved: false; feedback: string };

export async function runPromptLeaderReview(
  output: PromptOutput,
  orderedSkillIds: string[] = [],
  signal?: AbortSignal,
): Promise<LeaderDecision> {
  void output;
  void orderedSkillIds;
  void signal;
  return { approved: true };

  const { systemPrompt } = resolveAndComposeMountedSkills('prompt', PROMPT_LEADER_SPEC, orderedSkillIds);
  const result = await invokeLlmLeaderReview({
    systemPrompt,
    userPrompt: `以下为员工产出的 PromptOutput JSON，请按 Prompt 总监规范审核，重点检查新 15 字段完整性、挂载分类、构图前中后景、灯光布置、连续性约束、钉子4行和最终执行性：\n\n${JSON.stringify(output, null, 2)}`,
    temperature: 0.2,
    signal,
  });
  return result.approved
    ? { approved: true }
    : { approved: false, feedback: result.feedback ?? '请按审核意见补齐缺失栏位，并提高镜头卡片的可执行性。' };
}
