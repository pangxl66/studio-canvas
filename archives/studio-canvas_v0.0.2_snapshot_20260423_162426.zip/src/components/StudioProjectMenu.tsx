import { Panel } from '@xyflow/react';
import { saveAs } from 'file-saver';
import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent } from 'react';
import {
  createStudioProjectId,
  getStudioProjectRecord,
  listStudioRecentProjects,
  parseStudioProjectJsonFile,
  putStudioAutosave,
  putStudioProjectRecord,
  pushStudioRecentProject,
  setActiveStudioProjectRef,
  stringifyStudioProjectPayloadWithMeta,
  STUDIO_PROJECT_JSON_VERSION,
  type StudioProjectFilePayload,
  type StudioRecentProjectRef,
} from '@/services/studioProjectPersistence';
import { STUDIO_OPEN_SETTINGS_EVENT } from '@/components/StudioSettings';
import { toPersistableNodesAndEdges } from '@/utils/studioNodePersistence';
import { useStudioStore } from '@/store/useStudioStore';

const AUTOSAVE_INTERVAL_MS = 5 * 60 * 1000;
const MAX_RECENT_PROJECTS = 10;

function sanitizeFileName(name: string): string {
  return name.replace(/[\\/:*?"<>|]+/g, '-').trim() || 'studio-project';
}

function formatTime(ts: number): string {
  return new Date(ts).toLocaleString();
}

function sourceLabel(source: StudioRecentProjectRef['source']): string {
  if (source === 'file') return '文件导入';
  if (source === 'autosave') return '自动存档';
  return '工作区';
}

export function StudioProjectMenu() {
  const fileRef = useRef<HTMLInputElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);
  const hydrateProject = useStudioStore((state) => state.hydrateProject);
  const pushMessage = useStudioStore((state) => state.pushMessage);
  const createNewProject = useStudioStore((state) => state.createNewProject);
  const setCurrentProjectMeta = useStudioStore((state) => state.setCurrentProjectMeta);
  const currentProjectName = useStudioStore((state) => state.currentProjectName);
  const nodeCount = useStudioStore((state) => state.nodes.length);
  const edgeCount = useStudioStore((state) => state.edges.length);
  const [recentProjects, setRecentProjects] = useState<StudioRecentProjectRef[]>([]);
  const [menuOpen, setMenuOpen] = useState(false);
  const [recentOpen, setRecentOpen] = useState(false);

  const refreshProjectData = useCallback(async () => {
    try {
      const recents = await listStudioRecentProjects();
      setRecentProjects(recents.slice(0, MAX_RECENT_PROJECTS));
    } catch (error) {
      console.warn(error);
    }
  }, []);

  const rememberRecent = useCallback(
    async (projectId: string, projectName: string, source: StudioRecentProjectRef['source']) => {
      await pushStudioRecentProject({ projectId, projectName, source });
      await refreshProjectData();
    },
    [refreshProjectData],
  );

  const closeMenus = useCallback(() => {
    setMenuOpen(false);
    setRecentOpen(false);
  }, []);

  const saveProjectToFile = useCallback(() => {
    const { nodes, edges, currentProjectId: projectId, currentProjectName: projectName } = useStudioStore.getState();
    const body = stringifyStudioProjectPayloadWithMeta(nodes, edges, {
      projectId: projectId ?? undefined,
      projectName,
    });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const blob = new Blob([body], { type: 'application/json;charset=utf-8' });
    saveAs(blob, `${sanitizeFileName(projectName)}-${stamp}.json`);
    pushMessage({
      role: 'broadcast',
      text: `已导出项目文件，包含 ${nodes.length} 个节点和 ${edges.length} 条连线。`,
    });
    closeMenus();
  }, [closeMenus, pushMessage]);

  const openProjectRecord = useCallback(
    async (projectId: string) => {
      const record = await getStudioProjectRecord(projectId);
      if (!record) {
        pushMessage({ role: 'system', text: '打开失败：找不到该项目记录。' });
        await refreshProjectData();
        return;
      }
      const { nodes } = useStudioStore.getState();
      if (nodes.length > 0) {
        const ok = window.confirm(`打开项目“${record.projectName}”将替换当前画布，是否继续？`);
        if (!ok) return;
      }
      hydrateProject(record.nodes, record.edges, {
        projectId: record.projectId,
        projectName: record.projectName,
        broadcastText: `已打开项目“${record.projectName}”。`,
      });
      await setActiveStudioProjectRef({
        projectId: record.projectId,
        projectName: record.projectName,
      });
      await rememberRecent(record.projectId, record.projectName, 'workspace');
      closeMenus();
    },
    [closeMenus, hydrateProject, pushMessage, refreshProjectData, rememberRecent],
  );

  const onFileChange = useCallback(
    async (event: ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      event.target.value = '';
      if (!file) return;
      const reader = new FileReader();
      reader.onload = async () => {
        const text = typeof reader.result === 'string' ? reader.result : '';
        const payload = parseStudioProjectJsonFile(text);
        if (!payload) {
          pushMessage({ role: 'system', text: '打开项目失败：文件格式无效或已损坏。' });
          return;
        }
        const nextProjectId = payload.projectId ?? createStudioProjectId();
        const nextProjectName = payload.projectName ?? file.name.replace(/\.json$/i, '');
        hydrateProject(payload.nodes, payload.edges, {
          projectId: nextProjectId,
          projectName: nextProjectName,
          broadcastText: `已导入项目文件，共 ${payload.nodes.length} 个节点和 ${payload.edges.length} 条连线。`,
        });
        await putStudioProjectRecord(nextProjectId, nextProjectName, payload.nodes, payload.edges);
        await setActiveStudioProjectRef({
          projectId: nextProjectId,
          projectName: nextProjectName,
        });
        await rememberRecent(nextProjectId, nextProjectName, 'file');
        closeMenus();
      };
      reader.onerror = () => {
        pushMessage({ role: 'system', text: '打开项目失败：无法读取所选文件。' });
      };
      reader.readAsText(file, 'UTF-8');
    },
    [closeMenus, hydrateProject, pushMessage, rememberRecent],
  );

  const openFilePicker = useCallback(() => {
    const { nodes } = useStudioStore.getState();
    if (nodes.length > 0) {
      const ok = window.confirm('当前画布已有内容。导入项目文件将替换当前内容，是否继续？');
      if (!ok) return;
    }
    fileRef.current?.click();
  }, []);

  const saveProjectToWorkspace = useCallback(async () => {
    const { nodes, edges, currentProjectId: projectIdInState, currentProjectName: projectNameInState } =
      useStudioStore.getState();
    const suggestedName = projectNameInState || '未命名项目';
    const projectName = window.prompt('项目名称', suggestedName)?.trim();
    if (!projectName) return;
    const projectId = projectIdInState ?? createStudioProjectId();
    setCurrentProjectMeta(projectId, projectName);
    await putStudioProjectRecord(projectId, projectName, nodes, edges);
    await setActiveStudioProjectRef({ projectId, projectName });
    await rememberRecent(projectId, projectName, 'workspace');
    pushMessage({
      role: 'broadcast',
      text: `已将项目“${projectName}”保存到工作区。`,
    });
    closeMenus();
  }, [closeMenus, pushMessage, rememberRecent, setCurrentProjectMeta]);

  const createProject = useCallback(async () => {
    const { nodes } = useStudioStore.getState();
    if (nodes.length > 0) {
      const ok = window.confirm('新建项目会清空当前画布，是否继续？');
      if (!ok) return;
    }
    const projectName = window.prompt('新项目名称', currentProjectName || '未命名项目')?.trim();
    if (projectName == null) return;
    const projectId = createNewProject(projectName);
    await setActiveStudioProjectRef({
      projectId,
      projectName: projectName || '未命名项目',
    });
    await refreshProjectData();
    closeMenus();
  }, [closeMenus, createNewProject, currentProjectName, refreshProjectData]);

  const openSettings = useCallback(() => {
    window.dispatchEvent(new Event(STUDIO_OPEN_SETTINGS_EVENT));
    closeMenus();
  }, [closeMenus]);

  const currentSummaryText = useMemo(
    () => `${nodeCount} 个节点 · ${edgeCount} 条连线`,
    [edgeCount, nodeCount],
  );

  useEffect(() => {
    void refreshProjectData();
  }, [refreshProjectData]);

  useEffect(() => {
    const tick = async () => {
      const {
        nodes,
        edges,
        currentProjectId: projectId,
        currentProjectName: projectName,
      } = useStudioStore.getState();
      const { nodes: persistableNodes, edges: persistableEdges } = toPersistableNodesAndEdges(nodes, edges);
      const payload: StudioProjectFilePayload = {
        version: STUDIO_PROJECT_JSON_VERSION,
        savedAt: Date.now(),
        nodes: persistableNodes,
        edges: persistableEdges,
        projectId: projectId ?? undefined,
        projectName,
      };
      try {
        await putStudioAutosave(payload);
        if (projectId) {
          await putStudioProjectRecord(projectId, projectName, nodes, edges);
          await setActiveStudioProjectRef({ projectId, projectName });
        }
      } catch (error) {
        console.warn('IndexedDB autosave failed', error);
      }
    };

    const id = window.setInterval(() => {
      void tick();
    }, AUTOSAVE_INTERVAL_MS);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const onPointerDown = (event: PointerEvent) => {
      if (!menuRef.current?.contains(event.target as Node)) {
        closeMenus();
      }
    };
    window.addEventListener('pointerdown', onPointerDown);
    return () => window.removeEventListener('pointerdown', onPointerDown);
  }, [closeMenus, menuOpen]);

  return (
    <Panel position="top-left" className="studio-project-panel">
      <div ref={menuRef} className="studio-project-hub nodrag nopan">
        <div className="studio-project-hub__rail">
          <button
            type="button"
            className="studio-project-hub__menu-btn"
            aria-haspopup="menu"
            aria-expanded={menuOpen}
            onClick={() => {
              setMenuOpen((prev) => !prev);
              setRecentOpen(false);
            }}
          >
            文件
          </button>
          <div className="studio-project-hub__current">
            <strong className="studio-project-hub__name">{currentProjectName}</strong>
            <span className="studio-project-hub__meta">{currentSummaryText}</span>
          </div>
          <button type="button" className="studio-project-hub__quick" onClick={() => void saveProjectToWorkspace()}>
            保存
          </button>
        </div>

        {menuOpen ? (
          <div className="studio-project-menu" role="menu" aria-label="文件菜单">
            <button type="button" className="studio-project-menu__item" onClick={() => void createProject()}>
              <span>新建项目</span>
            </button>
            <button type="button" className="studio-project-menu__item" onClick={openFilePicker}>
              <span>打开项目文件</span>
            </button>
            <button type="button" className="studio-project-menu__item" onClick={saveProjectToFile}>
              <span>导出项目文件</span>
            </button>
            <button type="button" className="studio-project-menu__item" onClick={() => void saveProjectToWorkspace()}>
              <span>保存到工作区</span>
            </button>
            <div
              className={`studio-project-menu__item studio-project-menu__item--submenu ${recentOpen ? 'studio-project-menu__item--open' : ''}`}
              onMouseEnter={() => setRecentOpen(true)}
              onMouseLeave={() => setRecentOpen(false)}
            >
              <button
                type="button"
                className="studio-project-menu__submenu-trigger"
                onClick={() => setRecentOpen((prev) => !prev)}
              >
                <span>最近项目</span>
                <span className="studio-project-menu__caret">›</span>
              </button>
              {recentOpen ? (
                <div className="studio-project-menu__submenu" role="menu" aria-label="最近项目">
                  {recentProjects.length > 0 ? (
                    recentProjects.map((item) => (
                      <button
                        key={`${item.projectId}:${item.openedAt}`}
                        type="button"
                        className="studio-project-menu__recent"
                        onClick={() => void openProjectRecord(item.projectId)}
                      >
                        <strong>{item.projectName}</strong>
                        <span>{sourceLabel(item.source)}</span>
                        <time>{formatTime(item.openedAt)}</time>
                      </button>
                    ))
                  ) : (
                    <div className="studio-project-menu__empty">暂无最近项目</div>
                  )}
                </div>
              ) : null}
            </div>
            <button type="button" className="studio-project-menu__item" onClick={openSettings}>
              <span>模型设置</span>
            </button>
          </div>
        ) : null}
      </div>

      <input
        ref={fileRef}
        type="file"
        accept=".json,application/json"
        className="studio-project-file-input"
        aria-hidden
        tabIndex={-1}
        onChange={onFileChange}
      />
    </Panel>
  );
}
