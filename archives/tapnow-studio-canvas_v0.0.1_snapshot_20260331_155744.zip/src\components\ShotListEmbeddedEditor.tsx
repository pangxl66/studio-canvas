import { Handle, Position, useUpdateNodeInternals } from '@xyflow/react';
import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type MouseEvent as ReactMouseEvent,
  type PointerEvent as ReactPointerEvent,
} from 'react';
import { reindexStoryboardShotIds, tryParseStoryboardOutput } from '@/agents/storyboardAgents';
import {
  blankShot,
  mergeConsecutiveRange,
  mergeSameSceneGroups,
  selectionCanMergeConsecutive,
} from '@/components/detailPanel/StoryboardShotListTable';
import { ShotListCanvasDecisionStrip } from '@/components/ShotListCanvasDecisionStrip';
import { useStudioStore } from '@/store/useStudioStore';
import type { StoryboardOutput, StoryboardShot, StudioNodeData } from '@/types/studio';
import { makeShotListItemOutputHandleId, parseShotListItemOutputHandleId } from '@/utils/shotListWire';

type EditableField = 'type' | 'movement' | 'description' | 'content';

const TRASH_ICON = (
  <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden>
    <path
      fill="currentColor"
      d="M6 7h12l-1 14H7L6 7zm3-3h6l1 2H8l1-2zM9 10v9h2v-9H9zm4 0v9h2v-9h-2z"
    />
  </svg>
);

function ShotCanvasRow({
  sh,
  rowIdx,
  selected,
  selectedGroupCount,
  hovered,
  promptLinkCount,
  onHoverPort,
  onToggleSelect,
  onDelete,
  onLiveField,
  onFlushPersist,
  stopCanvas,
}: {
  sh: StoryboardShot;
  rowIdx: number;
  selected: boolean;
  selectedGroupCount: number;
  hovered: boolean;
  promptLinkCount: number;
  onHoverPort: (hovering: boolean) => void;
  onToggleSelect: () => void;
  onDelete: () => void;
  onLiveField: (field: EditableField, value: string) => void;
  onFlushPersist: () => void;
  stopCanvas: (e: ReactPointerEvent | ReactMouseEvent) => void;
}) {
  const [editingField, setEditingField] = useState<EditableField | null>(null);
  const [type, setType] = useState(sh.type);
  const [movement, setMovement] = useState(sh.movement);
  const [description, setDescription] = useState(sh.description);
  const [content, setContent] = useState(sh.content);

  useEffect(() => {
    if (editingField !== 'type') setType(sh.type);
  }, [sh.type, editingField]);
  useEffect(() => {
    if (editingField !== 'movement') setMovement(sh.movement);
  }, [sh.movement, editingField]);
  useEffect(() => {
    if (editingField !== 'description') setDescription(sh.description);
  }, [sh.description, editingField]);
  useEffect(() => {
    if (editingField !== 'content') setContent(sh.content);
  }, [sh.content, editingField]);

  useEffect(() => {
    setType(sh.type);
    setMovement(sh.movement);
    setDescription(sh.description);
    setContent(sh.content);
  }, [sh.id]);

  const endEdit = useCallback(() => {
    onFlushPersist();
    setEditingField(null);
  }, [onFlushPersist]);

  const cellDisplay = (text: string, emptyLabel: string) =>
    text.trim() ? text : emptyLabel;

  return (
    <tr
      className={`${hovered ? 'shot-list-canvas__row--port-hovered ' : ''}${
        selected && selectedGroupCount >= 2 ? 'shot-list-canvas__row--group-ready ' : ''
      }${
        promptLinkCount > 0 ? 'shot-list-canvas__row--connected' : ''
      }`.trim()}
    >
      <td className="shot-list-canvas__td shot-list-canvas__td--check">
        <input
          type="checkbox"
          className="nodrag nopan nowheel"
          checked={selected}
          onChange={onToggleSelect}
          onPointerDown={stopCanvas}
          onMouseDown={stopCanvas}
          aria-label={`选择镜头 ${rowIdx + 1}`}
        />
      </td>
      <td className="shot-list-canvas__td shot-list-canvas__td--id">#{sh.id}</td>
      <td className="shot-list-canvas__td">
        {editingField === 'type' ? (
          <input
            type="text"
            className="shot-list-canvas__input nodrag nopan nowheel"
            value={type}
            autoFocus
            onChange={(e) => {
              const v = e.target.value;
              setType(v);
              onLiveField('type', v);
            }}
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onBlur={endEdit}
            aria-label="景别"
          />
        ) : (
          <button
            type="button"
            className="shot-list-canvas__cell-display nodrag nopan nowheel"
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onClick={(e) => {
              stopCanvas(e);
              setEditingField('type');
            }}
          >
            {cellDisplay(sh.type, '点击编辑')}
          </button>
        )}
      </td>
      <td className="shot-list-canvas__td">
        {editingField === 'movement' ? (
          <input
            type="text"
            className="shot-list-canvas__input nodrag nopan nowheel"
            value={movement}
            autoFocus
            onChange={(e) => {
              const v = e.target.value;
              setMovement(v);
              onLiveField('movement', v);
            }}
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onBlur={endEdit}
            aria-label="运镜"
          />
        ) : (
          <button
            type="button"
            className="shot-list-canvas__cell-display nodrag nopan nowheel"
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onClick={(e) => {
              stopCanvas(e);
              setEditingField('movement');
            }}
          >
            {cellDisplay(sh.movement, '点击编辑')}
          </button>
        )}
      </td>
      <td className="shot-list-canvas__td">
        {editingField === 'description' ? (
          <textarea
            className="shot-list-canvas__textarea nodrag nopan nowheel"
            value={description}
            autoFocus
            rows={3}
            onChange={(e) => {
              const v = e.target.value;
              setDescription(v);
              onLiveField('description', v);
            }}
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onBlur={endEdit}
            aria-label="画面描述"
          />
        ) : (
          <button
            type="button"
            className="shot-list-canvas__cell-display shot-list-canvas__cell-display--multiline nodrag nopan nowheel"
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onClick={(e) => {
              stopCanvas(e);
              setEditingField('description');
            }}
          >
            {cellDisplay(sh.description, '点击编辑画面描述')}
          </button>
        )}
      </td>
      <td className="shot-list-canvas__td">
        {editingField === 'content' ? (
          <textarea
            className="shot-list-canvas__textarea nodrag nopan nowheel"
            value={content}
            autoFocus
            rows={3}
            onChange={(e) => {
              const v = e.target.value;
              setContent(v);
              onLiveField('content', v);
            }}
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onBlur={endEdit}
            aria-label="台词"
          />
        ) : (
          <button
            type="button"
            className="shot-list-canvas__cell-display shot-list-canvas__cell-display--multiline nodrag nopan nowheel"
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onClick={(e) => {
              stopCanvas(e);
              setEditingField('content');
            }}
          >
            {cellDisplay(sh.content, '点击编辑台词')}
          </button>
        )}
      </td>
      <td className="shot-list-canvas__td shot-list-canvas__td--op">
        <button
          type="button"
          className="shot-list-canvas__icon-trash nodrag nopan nowheel"
          title="删除此镜头"
          aria-label={`删除镜头 ${rowIdx + 1}`}
          onPointerDown={stopCanvas}
          onMouseDown={stopCanvas}
          onClick={() => {
            onFlushPersist();
            onDelete();
          }}
        >
          {TRASH_ICON}
        </button>
      </td>
      <td className="shot-list-canvas__td shot-list-canvas__td--port">
        <div
          className={`shot-list-canvas__port-cell${
            promptLinkCount > 0 ? ' shot-list-canvas__port-cell--connected' : ''
          }`}
          onMouseEnter={() => onHoverPort(true)}
          onMouseLeave={() => onHoverPort(false)}
        >
          <span className="shot-list-canvas__port-label">
            {promptLinkCount > 0 ? `已接入 ${promptLinkCount}` : 'Prompt'}
          </span>
          <Handle
            type="source"
            position={Position.Right}
            id={makeShotListItemOutputHandleId(sh.wireId ?? String(sh.id))}
            className="shot-list-canvas__row-handle"
            title={`输出当前镜头 #${sh.id} 到 Prompt 部`}
          />
        </div>
      </td>
    </tr>
  );
}

export function ShotListEmbeddedEditor({
  id,
  data,
  viewportHeight,
}: {
  id: string;
  data: StudioNodeData;
  viewportHeight?: number;
}) {
  const patchShotListNodeOutput = useStudioStore((s) => s.patchShotListNodeOutput);
  const setShotListSelectedWires = useStudioStore((s) => s.setShotListSelectedWires);
  const parentId = data.sourceStoryboardNodeId ?? null;
  const edges = useStudioStore((s) => s.edges);
  const updateNodeInternals = useUpdateNodeInternals();

  const parentReviewData = useStudioStore((s) => {
    if (!parentId) return null;
    const n = s.nodes.find((x) => x.id === parentId);
    if (n?.type !== 'department' || n.data.type !== 'storyboard') return null;
    return n.data;
  });

  const output = useMemo((): StoryboardOutput | null => {
    if (data.type !== 'shot_list_node' || data.output == null) return null;
    return tryParseStoryboardOutput(data.output);
  }, [data.output, data.type]);

  const shots = output?.shots ?? [];

  const [selected, setSelected] = useState<Set<number>>(() => new Set());
  const [hoveredWireId, setHoveredWireId] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const refreshFrameRef = useRef<number | null>(null);

  const promptLinkCounts = useMemo(() => {
    const counts = new Map<string, number>();
    for (const edge of edges) {
      if (edge.source !== id) continue;
      const wireId = parseShotListItemOutputHandleId(edge.sourceHandle);
      if (!wireId) continue;
      counts.set(wireId, (counts.get(wireId) ?? 0) + 1);
    }
    return counts;
  }, [edges, id]);

  const mergeInfo = useMemo(() => selectionCanMergeConsecutive(selected), [selected]);
  const selectedWireIds = useMemo(
    () =>
      Array.from(selected)
        .sort((a, b) => a - b)
        .map((index) => shots[index]?.wireId ?? String(shots[index]?.id ?? ''))
        .filter((wireId) => wireId.trim() !== ''),
    [selected, shots],
  );

  const persistTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingRef = useRef<{ rowIdx: number; field: EditableField; value: string } | null>(null);

  const scheduleHandleRefresh = useCallback(() => {
    if (refreshFrameRef.current != null) return;
    refreshFrameRef.current = window.requestAnimationFrame(() => {
      refreshFrameRef.current = null;
      updateNodeInternals(id);
    });
  }, [id, updateNodeInternals]);

  const applyPendingToStore = useCallback(() => {
    const p = pendingRef.current;
    pendingRef.current = null;
    if (!p) return;
    const row = useStudioStore.getState().nodes.find((n) => n.id === id)?.data;
    if (row?.type !== 'shot_list_node' || row.output == null) return;
    const out = tryParseStoryboardOutput(row.output);
    if (!out || p.rowIdx < 0 || p.rowIdx >= out.shots.length) return;
    const next = out.shots.map((s, i) => {
      if (i !== p.rowIdx) return s;
      if (p.field === 'type') return { ...s, type: p.value };
      if (p.field === 'movement') return { ...s, movement: p.value };
      if (p.field === 'description') return { ...s, description: p.value };
      return { ...s, content: p.value };
    });
    patchShotListNodeOutput(id, { ...out, shots: reindexStoryboardShotIds(next) }, true);
  }, [id, patchShotListNodeOutput]);

  const flushPersist = useCallback(() => {
    if (persistTimerRef.current) {
      clearTimeout(persistTimerRef.current);
      persistTimerRef.current = null;
    }
    applyPendingToStore();
  }, [applyPendingToStore]);

  const onLiveField = useCallback(
    (rowIdx: number, field: EditableField, value: string) => {
      pendingRef.current = { rowIdx, field, value };
      if (persistTimerRef.current) clearTimeout(persistTimerRef.current);
      persistTimerRef.current = setTimeout(() => {
        persistTimerRef.current = null;
        applyPendingToStore();
      }, 100);
    },
    [applyPendingToStore],
  );

  useEffect(() => {
    setSelected((prev) => {
      const next = new Set<number>();
      for (const i of prev) {
        if (i < shots.length) next.add(i);
      }
      return next;
    });
  }, [shots.length]);

  useEffect(() => {
    setShotListSelectedWires(id, selectedWireIds);
  }, [id, selectedWireIds, setShotListSelectedWires]);

  useEffect(() => {
    scheduleHandleRefresh();
  }, [scheduleHandleRefresh, selectedWireIds, shots.length]);

  useEffect(
    () => () => {
      setShotListSelectedWires(id, []);
      if (refreshFrameRef.current != null) {
        window.cancelAnimationFrame(refreshFrameRef.current);
      }
    },
    [id, setShotListSelectedWires],
  );

  const toggleSelect = useCallback((index: number) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  }, []);

  const onMerge = useCallback(() => {
    flushPersist();
    if (!mergeInfo.ok || mergeInfo.lo == null || mergeInfo.hi == null) return;
    const row = useStudioStore.getState().nodes.find((n) => n.id === id)?.data;
    if (row?.type !== 'shot_list_node' || row.output == null) return;
    const out = tryParseStoryboardOutput(row.output);
    if (!out) return;
    const next = mergeConsecutiveRange(out.shots, mergeInfo.lo, mergeInfo.hi);
    setSelected(new Set());
    patchShotListNodeOutput(id, { ...out, shots: reindexStoryboardShotIds(next) }, true);
  }, [mergeInfo, id, patchShotListNodeOutput, flushPersist]);

  const onMergeSameScene = useCallback(() => {
    flushPersist();
    const row = useStudioStore.getState().nodes.find((n) => n.id === id)?.data;
    if (row?.type !== 'shot_list_node' || row.output == null) return;
    const out = tryParseStoryboardOutput(row.output);
    if (!out) return;
    setSelected(new Set());
    patchShotListNodeOutput(id, { ...out, shots: mergeSameSceneGroups(out.shots) }, true);
  }, [id, patchShotListNodeOutput, flushPersist]);

  const onDelete = useCallback(
    (index: number) => {
      flushPersist();
      const row = useStudioStore.getState().nodes.find((n) => n.id === id)?.data;
      if (row?.type !== 'shot_list_node' || row.output == null) return;
      const out = tryParseStoryboardOutput(row.output);
      if (!out || index < 0 || index >= out.shots.length) return;
      const next = out.shots.filter((_, i) => i !== index);
      setSelected((prev) => {
        const n = new Set<number>();
        for (const i of prev) {
          if (i === index) continue;
          if (i > index) n.add(i - 1);
          else n.add(i);
        }
        return n;
      });
      patchShotListNodeOutput(id, { ...out, shots: reindexStoryboardShotIds(next) }, true);
    },
    [id, patchShotListNodeOutput, flushPersist],
  );

  const onAppendRow = useCallback(() => {
    flushPersist();
    const row = useStudioStore.getState().nodes.find((n) => n.id === id)?.data;
    const out =
      row?.type === 'shot_list_node' && row.output != null
        ? tryParseStoryboardOutput(row.output)
        : null;
    const base = out ?? { shots: [] as StoryboardShot[], narrativeBeats: [] as string[] };
    const last = base.shots[base.shots.length - 1];
    const sceneRef = last?.sceneRef;
    const nextShots = [...base.shots, blankShot(sceneRef)];
    const beats =
      base.narrativeBeats?.length > 0
        ? base.narrativeBeats
        : nextShots.length > 0
          ? ['手动维护的镜头表']
          : [];
    patchShotListNodeOutput(id, { ...base, narrativeBeats: beats, shots: reindexStoryboardShotIds(nextShots) }, true);
  }, [id, patchShotListNodeOutput, flushPersist]);

  const stopCanvas = useCallback((e: ReactPointerEvent | ReactMouseEvent) => {
    e.stopPropagation();
  }, []);

  const showMergeBar = selected.size >= 2;
  const scrollViewportHeight = Math.max(220, (viewportHeight ?? 560) - 210);

  const decisionStrip =
    parentId != null && parentReviewData != null ? (
      <ShotListCanvasDecisionStrip parentId={parentId} parentData={parentReviewData} />
    ) : null;

  if (!output || shots.length === 0) {
    return (
      <div
        className="shot-list-canvas__stack nodrag nopan nowheel"
        onPointerDown={stopCanvas}
        onMouseDown={stopCanvas}
      >
        {decisionStrip}
        <div className="shot-list-canvas__empty shot-list-canvas__empty--padded">
          <p className="shot-list-canvas__empty-text">暂无镜头数据</p>
          <p className="shot-list-canvas__empty-hint">可从父分镜同步生成，或点击下方手动新增第一行</p>
          <button
            type="button"
            className="shot-list-canvas__btn shot-list-canvas__btn--add nodrag nopan nowheel"
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onClick={onAppendRow}
          >
            + 新增镜头
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="shot-list-canvas__root nodrag nopan nowheel"
      onPointerDown={stopCanvas}
      onMouseDown={stopCanvas}
    >
      {decisionStrip}
      {showMergeBar ? (
        <div className="shot-list-canvas__toolbar">
          <button
            type="button"
            className="shot-list-canvas__btn shot-list-canvas__btn--merge nodrag nopan nowheel"
            title="将同一场次下的连续镜头按 15 秒上限自动合并"
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onClick={onMergeSameScene}
          >
            同场合并
          </button>
          <button
            type="button"
            className="shot-list-canvas__btn shot-list-canvas__btn--merge nodrag nopan nowheel"
            disabled={!mergeInfo.ok}
            title={
              mergeInfo.ok
                ? '将连续选中的多行合并为一行'
                : '请选择行号连续的多行（中间不能空行）'
            }
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onClick={onMerge}
          >
            合并选中项
          </button>
          <span className="shot-list-canvas__toolbar-hint">已选 {selected.size} 行</span>
        </div>
      ) : (
        <div className="shot-list-canvas__toolbar shot-list-canvas__toolbar--subtle">
          <button
            type="button"
            className="shot-list-canvas__btn shot-list-canvas__btn--merge nodrag nopan nowheel"
            title="将同一场次下的连续镜头按 15 秒上限自动合并"
            onPointerDown={stopCanvas}
            onMouseDown={stopCanvas}
            onClick={onMergeSameScene}
          >
            同场合并
          </button>
          <span className="shot-list-canvas__toolbar-hint">勾选至少 2 行（须连续）后可手动合并</span>
        </div>
      )}
      <div
        ref={scrollRef}
        className="shot-list-canvas__scroll"
        style={{ maxHeight: scrollViewportHeight, height: scrollViewportHeight }}
        onScroll={scheduleHandleRefresh}
      >
        <table className="shot-list-canvas__table">
          <thead>
            <tr>
              <th className="shot-list-canvas__th shot-list-canvas__th--check" scope="col">
                选
              </th>
              <th className="shot-list-canvas__th" scope="col">
                镜头号
              </th>
              <th className="shot-list-canvas__th" scope="col">
                景别
              </th>
              <th className="shot-list-canvas__th" scope="col">
                运镜
              </th>
              <th className="shot-list-canvas__th shot-list-canvas__th--wide" scope="col">
                画面描述
              </th>
              <th className="shot-list-canvas__th shot-list-canvas__th--wide" scope="col">
                台词
              </th>
              <th className="shot-list-canvas__th shot-list-canvas__th--op" scope="col">
                操作
              </th>
              <th className="shot-list-canvas__th shot-list-canvas__th--port" scope="col">
                输出
              </th>
            </tr>
          </thead>
          <tbody>
            {shots.map((sh, rowIdx) => (
              <ShotCanvasRow
                key={sh.id}
                sh={sh}
                rowIdx={rowIdx}
                selected={selected.has(rowIdx)}
                selectedGroupCount={selectedWireIds.length}
                hovered={hoveredWireId === (sh.wireId ?? String(sh.id))}
                promptLinkCount={promptLinkCounts.get(sh.wireId ?? String(sh.id)) ?? 0}
                onHoverPort={(hovering) => setHoveredWireId(hovering ? (sh.wireId ?? String(sh.id)) : null)}
                onToggleSelect={() => toggleSelect(rowIdx)}
                onDelete={() => onDelete(rowIdx)}
                onLiveField={(field, value) => onLiveField(rowIdx, field, value)}
                onFlushPersist={flushPersist}
                stopCanvas={stopCanvas}
              />
            ))}
          </tbody>
        </table>
      </div>
      <div className="shot-list-canvas__footer nodrag nopan nowheel">
        <button
          type="button"
          className="shot-list-canvas__btn shot-list-canvas__btn--add nodrag nopan nowheel"
          onPointerDown={stopCanvas}
          onMouseDown={stopCanvas}
          onClick={onAppendRow}
        >
          + 新增镜头
        </button>
      </div>
    </div>
  );
}
