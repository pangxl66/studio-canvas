/**
 * LLM 网关：通过 OpenAI 兼容接口 POST 到 `{baseUrl}/chat/completions`。
 * baseUrl + apiKey 来自设置或环境变量。
 */

import { safeJsonParse } from '@/services/safeJsonParse';


export type ModelGatewayConfig = {
  /** API 根地址，例如 `https://api.openai.com/v1` */
  baseUrl: string;
  apiKey: string;
  /** 默认模型 id，可被请求参数覆盖 */
  model?: string;
  /** 请求超时时间，默认 180 秒 */
  timeoutMs?: number;
};

export type RequestLLMParams = {
  systemPrompt: string;
  userPrompt: string;
  temperature: number;
  jsonMode: boolean;
  /** 可选：覆盖默认模型 */
  model?: string;
  signal?: AbortSignal;
};

export type RequestLLMError = {
  code: string;
  message: string;
  /** 当前错误是否已经自动重试过 1 次 */
  retried: boolean;
};

export type RequestLLMResult =
  | { ok: true; content: string }
  | { ok: false; error: RequestLLMError };

type ChatMessageContentPart = { type?: string; text?: string; content?: string };

type ChatCompletionsResponse = {
  choices?: Array<{
    message?: { content?: string | null | ChatMessageContentPart[] };
    finish_reason?: string | null;
  }>;
  error?: { message?: string; type?: string; code?: string };
};

type StreamChunkJson = {
  choices?: Array<{ delta?: { content?: string | null } }>;
  error?: { message?: string; code?: string; type?: string };
};

const DEFAULT_TIMEOUT_MS = 180_000;
const CHAT_COMPLETIONS_PATH = '/chat/completions';
const USER_ABORT_MESSAGE = '已手动停止当前任务。';

function normalizeBaseUrl(baseUrl: string): string {
  return baseUrl.trim().replace(/\/+$/, '');
}

function normalizeOpenAiCompatibleBaseUrl(baseUrl: string): string {
  const normalized = normalizeBaseUrl(baseUrl);
  try {
    const url = new URL(normalized);
    const path = url.pathname.replace(/\/+$/, '');
    // 很多 OpenAI 兼容网关把主页放在 `/`，API 真正挂在 `/v1`。
    if (!path) {
      url.pathname = '/v1';
      return url.toString().replace(/\/+$/, '');
    }
  } catch {
    // URL 解析失败时保持原样。
  }
  return normalized;
}

function buildUrl(baseUrl: string): string {
  return `${normalizeOpenAiCompatibleBaseUrl(baseUrl)}${CHAT_COMPLETIONS_PATH}`;
}

function parseAssistantContent(data: ChatCompletionsResponse): string | null {
  const raw = data.choices?.[0]?.message?.content;
  if (raw == null) return null;
  if (typeof raw === 'string') return raw;
  if (Array.isArray(raw)) {
    const parts = raw.map((p) => {
      if (typeof p === 'string') return p;
      if (p && typeof p === 'object') {
        const o = p as ChatMessageContentPart;
        if (typeof o.text === 'string') return o.text;
        if (typeof o.content === 'string') return o.content;
      }
      return '';
    });
    const joined = parts.join('');
    return joined || null;
  }
  return String(raw);
}

/** 去掉 BOM、JSON hijacking 前缀等干扰文本。 */
function normalizeHttpResponseText(raw: string): string {
  let t = raw.replace(/^\uFEFF/, '').trim();
  t = t.replace(/^\)\]\}'\s*\n?/, '').trim();
  return t;
}

function sanitizeGatewayText(raw: string): string {
  return raw
    .replace(/sk-[A-Za-z0-9_-]{6,}/g, 'sk-***')
    .replace(/Bearer\s+[A-Za-z0-9._-]+/gi, 'Bearer ***')
    .replace(/("api[_-]?key"\s*:\s*")([^"]+)(")/gi, '$1***$3')
    .replace(/\s+/g, ' ')
    .trim();
}

function mapNetworkErrorMessage(raw: string): string {
  const text = sanitizeGatewayText(raw);
  if (!text) {
    return '模型网关网络异常：无法连接到上游服务。请检查 Base URL、网络连通性或浏览器拦截设置。';
  }
  if (/Failed to fetch/i.test(text)) {
    return '模型网关网络异常：无法连接到上游服务。请检查 Base URL 是否可访问、接口是否允许跨域，以及当前网络或代理是否正常。';
  }
  if (/NetworkError|Load failed|fetch failed/i.test(text)) {
    return '模型网关网络异常：请求未能到达上游服务。请检查 Base URL、代理转发或浏览器网络权限。';
  }
  return `模型网关网络异常：${text}`;
}

function mapApiErrorMessage(status: number, bodySnippet: string): string | null {
  const text = sanitizeGatewayText(bodySnippet);
  if (!text) return null;

  if (/Concurrency limit exceeded|too many concurrent|concurrency limit|并发.*上限/i.test(text)) {
    return '模型网关并发已达上限：当前账号正在占满并发，请稍后再试。';
  }
  if (/rate limit|too many requests|请求过于频繁/i.test(text)) {
    return '模型网关限流：请求过于频繁，请稍后重试。';
  }
  if (/TokenStatusExhausted|额度已用尽|quota|insufficient_quota|credit/i.test(text)) {
    return '模型网关额度已用尽：当前 API Key 或上游账户余额不足，请更换可用 Key 或检查上游账户额度。';
  }
  if (/invalid.?api.?key|api key.*invalid|key.*invalid|unauthorized/i.test(text)) {
    return '模型网关鉴权失败：当前 API Key 无效，请检查或更换可用 Key。';
  }
  if (/permission|forbidden|no permission|access denied/i.test(text) || status === 403) {
    return '模型网关权限不足：当前账号或 Key 没有访问该模型/接口的权限。';
  }
  if (/model.*not found|unknown model|does not exist/i.test(text)) {
    return '模型网关模型名无效：请检查当前 Deep 模式配置的模型名称。';
  }
  return null;
}

function mapGatewayMessage(raw: string, status = 0): string {
  return mapApiErrorMessage(status, raw) ?? (sanitizeGatewayText(raw) || '上游服务返回异常。');
}

function isRetryableMessage(raw: string): boolean {
  const text = sanitizeGatewayText(raw);
  return /Concurrency limit exceeded|too many concurrent|rate limit|too many requests|temporarily unavailable|service unavailable|upstream|timeout|timed out|econn|network|fetch/i.test(
    text,
  );
}

function shouldRetryGatewayError(error: RequestLLMError): boolean {
  if (error.code === 'USER_ABORT') return false;
  if (error.code === 'NETWORK' || error.code === 'TIMEOUT') return true;
  if (error.code === 'STREAM_ERROR') return isRetryableMessage(error.message);
  if (error.code === 'EMPTY_STREAM' || error.code === 'NO_BODY') return true;
  if (/^HTTP_5\d{2}$/.test(error.code) || error.code === 'HTTP_429') return true;
  return false;
}

async function waitBeforeRetry(ms: number, signal?: AbortSignal): Promise<void> {
  if (!signal) {
    await new Promise((resolve) => setTimeout(resolve, ms));
    return;
  }
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(timer);
      signal.removeEventListener('abort', onAbort);
      reject(new DOMException('Aborted', 'AbortError'));
    };
    signal.addEventListener('abort', onAbort, { once: true });
  });
}

/**
 * 尝试把 HTTP 响应解析成 chat completions JSON。
 * 兼容普通 JSON、带 BOM 的 JSON、以及 SSE `data: {...}` 片段。
 */
function parseChatCompletionsResponseBody(text: string): ChatCompletionsResponse | null {
  const t0 = normalizeHttpResponseText(text);
  if (!t0) return null;

  const tryParse = (s: string): ChatCompletionsResponse | null => {
    const r = safeJsonParse(s);
    if (!r.ok) return null;
    const v = r.value;
    if (v === null || typeof v !== 'object' || Array.isArray(v)) return null;
    return v as ChatCompletionsResponse;
  };

  const direct = tryParse(t0);
  if (direct) return direct;

  if (/^data:\s*/m.test(t0) || /\ndata:\s*/.test(t0)) {
    const chunks: string[] = [];
    for (const line of t0.split(/\r?\n/)) {
      const m = line.match(/^data:\s*(.*)$/);
      if (!m) continue;
      const payload = m[1].trim();
      if (payload === '[DONE]' || payload === '') continue;
      chunks.push(payload);
    }
    const merged = tryParse(chunks.join(''));
    if (merged) return merged;
    for (let i = chunks.length - 1; i >= 0; i--) {
      const one = tryParse(chunks[i]);
      if (one) return one;
    }
  }

  const start = t0.indexOf('{');
  if (start < 0) return null;
  let depth = 0;
  let inStr = false;
  let esc = false;
  for (let i = start; i < t0.length; i++) {
    const c = t0[i];
    if (inStr) {
      if (esc) {
        esc = false;
        continue;
      }
      if (c === '\\') {
        esc = true;
        continue;
      }
      if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') {
      inStr = true;
      continue;
    }
    if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (depth === 0) {
        return tryParse(t0.slice(start, i + 1));
      }
    }
  }
  return null;
}

function mapHttpToFriendly(status: number, bodySnippet: string): string {
  const mapped = mapApiErrorMessage(status, bodySnippet);
  if (mapped) return mapped;
  const snippet = sanitizeGatewayText(bodySnippet);

  if (status === 401 || status === 403) {
    return `模型网关鉴权失败：请检查 Base URL、API Key 或上游网关权限配置。${
      snippet ? ` 服务端返回：${snippet.slice(0, 240)}` : ''
    }`;
  }
  if (status === 429) {
    return '模型网关限流：请求过于频繁或额度已用尽，请稍后重试。';
  }
  if (status >= 500) {
    return '模型网关服务异常：上游服务暂时不可用，请稍后重试。';
  }
  if (status === 400) {
    return `模型网关请求无效：请检查模型名、Base URL 或请求格式。${
      snippet ? ` 服务端返回：${snippet.slice(0, 240)}` : ''
    }`;
  }
  return `HTTP ${status}${snippet ? ` · ${snippet.slice(0, 200)}` : ''}`;
}

async function requestLLMOnce(
  config: ModelGatewayConfig,
  params: RequestLLMParams,
  model: string,
): Promise<RequestLLMResult> {
  const timeoutMs = config.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const url = buildUrl(config.baseUrl);

  const body: Record<string, unknown> = {
    model,
    temperature: params.temperature,
    messages: [
      { role: 'system', content: params.systemPrompt },
      { role: 'user', content: params.userPrompt },
    ],
  };

  if (params.jsonMode) {
    body.response_format = { type: 'json_object' };
  }

  const controller = new AbortController();
  let abortedByUser = false;
  const onExternalAbort = () => {
    abortedByUser = true;
    controller.abort();
  };
  if (params.signal) {
    if (params.signal.aborted) {
      abortedByUser = true;
      controller.abort();
    } else {
      params.signal.addEventListener('abort', onExternalAbort, { once: true });
    }
  }
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${config.apiKey}`,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });

    const text = await res.text();
    let data: ChatCompletionsResponse;
    if (!text.trim()) {
      data = {};
    } else {
        const parsed = parseChatCompletionsResponseBody(text);
        if (!parsed) {
        const sanitized = sanitizeGatewayText(text);
        const hint = sanitized.length > 120 ? `${sanitized.slice(0, 120)}…` : sanitized;
        return {
          ok: false,
          error: {
            code: 'INVALID_JSON',
            message: `模型网关返回的不是合法 JSON。HTTP ${res.status}，响应片段：${hint.replace(/\s+/g, ' ')}`,
            retried: false,
          },
        };
      }
      data = parsed;
    }

    if (!res.ok) {
      const apiMsg = data.error?.message;
      const snippet = apiMsg ?? text;
      return {
        ok: false,
        error: {
          code: `HTTP_${res.status}`,
          message: mapHttpToFriendly(res.status, snippet),
          retried: false,
        },
      };
    }

    const content = parseAssistantContent(data);
    if (content == null) {
      return {
        ok: false,
        error: {
          code: 'EMPTY_CONTENT',
          message: '模型网关返回成功，但响应里缺少 `choices[0].message.content`。',
          retried: false,
        },
      };
    }

    return { ok: true, content };
  } catch (e) {
    const name = e instanceof Error ? e.name : '';
    const isAbort = name === 'AbortError' || (e instanceof DOMException && e.name === 'AbortError');
    if (isAbort) {
      if (abortedByUser) {
        return {
          ok: false,
          error: {
            code: 'USER_ABORT',
            message: USER_ABORT_MESSAGE,
            retried: false,
          },
        };
      }
      return {
        ok: false,
        error: {
          code: 'TIMEOUT',
          message: `模型网关请求超时：已等待 ${timeoutMs / 1000}s，未收到完整响应。`,
          retried: false,
        },
      };
    }
    const msg = e instanceof Error ? e.message : String(e);
    return {
      ok: false,
      error: {
        code: 'NETWORK',
        message: mapNetworkErrorMessage(msg),
        retried: false,
      },
    };
  } finally {
    clearTimeout(timer);
    params.signal?.removeEventListener('abort', onExternalAbort);
  }
}

/**
 * 非流式请求。
 * 遇到临时异常时会自动重试一次，最终仍失败则返回错误对象。
 */
export async function requestLLM(
  config: ModelGatewayConfig,
  params: RequestLLMParams,
): Promise<RequestLLMResult> {
  const model = (params.model ?? config.model)?.trim();
  if (!model) {
    return {
      ok: false,
      error: {
        code: 'MISSING_MODEL',
        message: '未配置模型名：请在网关配置或当前请求里提供 model。',
        retried: false,
      },
    };
  }

  const first = await requestLLMOnce(config, params, model);
  if (first.ok) return first;
  if (first.error.code === 'USER_ABORT') return first;
  if (!shouldRetryGatewayError(first.error)) return first;

  try {
    await waitBeforeRetry(first.error.code === 'HTTP_429' || first.error.code === 'STREAM_ERROR' ? 1600 : 900, params.signal);
  } catch {
    return {
      ok: false,
      error: {
        code: 'USER_ABORT',
        message: USER_ABORT_MESSAGE,
        retried: false,
      },
    };
  }

  const second = await requestLLMOnce(config, params, model);
  if (second.ok) return second;
  if (second.error.code === 'USER_ABORT') return second;

  return {
    ok: false,
    error: {
      code: second.error.code,
      message: `${second.error.message} 已自动重试 1 次，但仍然失败。`,
      retried: true,
    },
  };
}

export type RequestLLMStreamParams = RequestLLMParams & {
  /** 每次收到新增量时调用 */
  onDelta: (delta: string, accumulated: string) => void;
  onComplete?: (fullText: string) => void;
};

/**
 * 流式请求：消费 chat completions 的 SSE `data: {...}` 数据。
 * 遇到临时异常时会自动重试一次，最终仍失败则返回错误对象。
 */
async function requestLLMStreamOnce(
  config: ModelGatewayConfig,
  params: RequestLLMStreamParams,
): Promise<RequestLLMResult> {
  const model = (params.model ?? config.model)?.trim();
  if (!model) {
    return {
      ok: false,
      error: {
        code: 'MISSING_MODEL',
        message: '未配置模型名：请在网关配置或当前请求里提供 model。',
        retried: false,
      },
    };
  }

  const timeoutMs = config.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const url = buildUrl(config.baseUrl);
  const body: Record<string, unknown> = {
    model,
    stream: true,
    temperature: params.temperature,
    messages: [
      { role: 'system', content: params.systemPrompt },
      { role: 'user', content: params.userPrompt },
    ],
  };
  if (params.jsonMode) {
    body.response_format = { type: 'json_object' };
  }

  const controller = new AbortController();
  let abortedByUser = false;
  const onExternalAbort = () => {
    abortedByUser = true;
    controller.abort();
  };
  if (params.signal) {
    if (params.signal.aborted) {
      abortedByUser = true;
      controller.abort();
    } else {
      params.signal.addEventListener('abort', onExternalAbort, { once: true });
    }
  }
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let accumulated = '';

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${config.apiKey}`,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });

    if (!res.ok) {
      const snippet = await res.text();
      return {
        ok: false,
        error: {
          code: `HTTP_${res.status}`,
          message: mapHttpToFriendly(res.status, snippet),
          retried: false,
        },
      };
    }

    const reader = res.body?.getReader();
    if (!reader) {
      return {
        ok: false,
        error: {
          code: 'NO_BODY',
          message: '模型网关响应中没有可读取的数据流。',
          retried: false,
        },
      };
    }

    const decoder = new TextDecoder();
    let lineBuf = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      lineBuf += decoder.decode(value, { stream: true });
      const lines = lineBuf.split('\n');
      lineBuf = lines.pop() ?? '';
      for (const rawLine of lines) {
        const line = rawLine.trim();
        if (!line || line === 'data: [DONE]') continue;
        if (!line.startsWith('data: ')) continue;
        const payload = line.slice(6);
        const parsedChunk = safeJsonParse(payload);
        if (!parsedChunk.ok || parsedChunk.value == null || typeof parsedChunk.value !== 'object') {
          continue;
        }
        const json = parsedChunk.value as StreamChunkJson;
        if (json.error?.message) {
          const rawCode = String(json.error.code ?? '').trim();
          const normalizedCode =
            rawCode === '429' || /rate.?limit|concurrency/i.test(json.error.message)
              ? 'HTTP_429'
              : rawCode || 'STREAM_ERROR';
          return {
            ok: false,
            error: {
              code: normalizedCode,
              message: mapGatewayMessage(json.error.message, 0),
              retried: false,
            },
          };
        }
        const piece = json.choices?.[0]?.delta?.content;
        if (piece) {
          accumulated += piece;
          params.onDelta(piece, accumulated);
        }
      }
    }

    params.onComplete?.(accumulated);

    if (!accumulated.trim()) {
      return {
        ok: false,
        error: {
          code: 'EMPTY_STREAM',
          message: '模型网关流式响应结束了，但没有收到任何内容。',
          retried: false,
        },
      };
    }

    return { ok: true, content: accumulated };
  } catch (e) {
    const name = e instanceof Error ? e.name : '';
    const isAbort = name === 'AbortError' || (e instanceof DOMException && e.name === 'AbortError');
    if (isAbort) {
      if (abortedByUser) {
        return {
          ok: false,
          error: {
            code: 'USER_ABORT',
            message: USER_ABORT_MESSAGE,
            retried: false,
          },
        };
      }
      return {
        ok: false,
        error: {
          code: 'TIMEOUT',
          message: `模型网关流式请求超时：已等待 ${timeoutMs / 1000}s。`,
          retried: false,
        },
      };
    }
    const msg = e instanceof Error ? e.message : String(e);
    return {
      ok: false,
      error: {
        code: 'NETWORK',
        message: mapNetworkErrorMessage(msg),
        retried: false,
      },
    };
  } finally {
    clearTimeout(timer);
    params.signal?.removeEventListener('abort', onExternalAbort);
  }
}

export async function requestLLMStream(
  config: ModelGatewayConfig,
  params: RequestLLMStreamParams,
): Promise<RequestLLMResult> {
  const first = await requestLLMStreamOnce(config, params);
  if (first.ok) return first;
  if (first.error.code === 'USER_ABORT') return first;
  if (!shouldRetryGatewayError(first.error)) return first;

  try {
    await waitBeforeRetry(
      first.error.code === 'HTTP_429' || /并发|限流/.test(first.error.message) ? 1600 : 900,
      params.signal,
    );
  } catch {
    return {
      ok: false,
      error: {
        code: 'USER_ABORT',
        message: USER_ABORT_MESSAGE,
        retried: false,
      },
    };
  }

  const second = await requestLLMStreamOnce(config, params);
  if (second.ok) return second;
  if (second.error.code === 'USER_ABORT') return second;

  return {
    ok: false,
    error: {
      code: second.error.code,
      message: `${second.error.message} 已自动重试 1 次，但仍然失败。`,
      retried: true,
    },
  };
}
