import { assertPromptOutput } from '@/agents/promptAgents';
import { assertStoryboardOutput } from '@/agents/storyboardAgents';
import { assertWritingOutput } from '@/agents/writingAgents';
import { getResolvedPipelineExecutionMode } from '@/config/llmSettings';
import { invokeLlmJsonObject } from '@/services/llmJsonClient';
import type {
  AssistantHistoryEntry,
  PromptOutput,
  StoryboardOutput,
  StudioNodeData,
  WritingOutput,
} from '@/types/studio';

export type AssistantNodeAction = 'chat' | 'revise_output' | 'update_task' | 'update_preferences';

type NodeAssistantBase = {
  assistantReply: string;
  action: AssistantNodeAction;
  applyChange: boolean;
  taskInstruction: string;
  assistantPreferences: string;
};

export type NodeAssistantResult =
  | (NodeAssistantBase & {
      targetKind: 'text';
      updatedText: string;
    })
  | (NodeAssistantBase & {
      targetKind: 'writing' | 'storyboard' | 'prompt';
      updatedOutput: WritingOutput | StoryboardOutput | PromptOutput | null;
    });

function stringify(value: unknown): string {
  try {
    return JSON.stringify(value, null, 2);
  } catch {
    return String(value ?? '');
  }
}

function buildHistoryText(history: AssistantHistoryEntry[]): string {
  if (!history.length) return '[]';
  return stringify(history.slice(-12));
}

function normalizeAction(value: unknown): AssistantNodeAction {
  const text = String(value ?? '').trim();
  if (text === 'revise_output' || text === 'update_task' || text === 'update_preferences') {
    return text;
  }
  return 'chat';
}

function nonEmptyString(value: unknown, fallback = ''): string {
  return typeof value === 'string' ? value.trim() : fallback;
}

function looksLikeQuestion(text: string): boolean {
  const normalized = text.trim();
  if (!normalized) return false;
  return /[?？]$/.test(normalized) || ['怎么', '如何', '为什么', '是否', '能不能', '可不可以', '是什么', '吗'].some((token) => normalized.includes(token));
}

function looksLikeDirectRevisionRequest(text: string): boolean {
  const normalized = text.trim();
  if (!normalized || looksLikeQuestion(normalized)) return false;
  return [
    '修改',
    '改',
    '调整',
    '优化',
    '细化',
    '详细',
    '丰富',
    '补充',
    '加强',
    '弱化',
    '精简',
    '简化',
    '压缩',
    '增加',
    '减少',
    '删掉',
    '删除',
    '纠正',
    '修正',
    '替换',
    '改为',
    '改掉',
    '错别字',
    '别字',
    '锚点',
    '限制',
    '控制',
    '保留',
    '重写',
    '改成',
    '换成',
    '不够',
    '太',
    '更',
  ].some((token) => normalized.includes(token));
}

function looksLikePreferenceRequest(text: string): boolean {
  const normalized = text.trim();
  if (!normalized || looksLikeQuestion(normalized)) return false;
  return ['以后', '默认', '长期', '记住', '一直', '始终', '固定风格', '都按'].some((token) =>
    normalized.includes(token),
  );
}

function looksLikeFutureTaskRequest(text: string): boolean {
  const normalized = text.trim();
  if (!normalized || looksLikeQuestion(normalized)) return false;
  return ['下次', '后续', '之后', '重新生成时', '执行时', '后面', '下一版', '下一轮'].some((token) =>
    normalized.includes(token),
  );
}

function looksLikeImmediateExecutionCommand(text: string): boolean {
  const normalized = text.trim();
  if (!normalized || looksLikeQuestion(normalized)) return false;
  if (looksLikePreferenceRequest(normalized) || looksLikeFutureTaskRequest(normalized)) return false;
  return true;
}

function shouldForceStructuredRevision(args: {
  currentOutput: WritingOutput | StoryboardOutput | PromptOutput | null;
  userMessage: string;
  action: AssistantNodeAction;
  applyChange: boolean;
}): boolean {
  if (!args.currentOutput) return false;
  if (!(looksLikeDirectRevisionRequest(args.userMessage) || looksLikeImmediateExecutionCommand(args.userMessage))) {
    return false;
  }
  return (
    args.action === 'chat' ||
    args.action === 'update_task' ||
    args.action === 'update_preferences' ||
    !args.applyChange
  );
}

function ensureObject(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('智能助手返回格式错误：顶层必须是 JSON 对象。');
  }
  return value as Record<string, unknown>;
}

function parseAssistantEnvelope(value: unknown) {
  const obj = ensureObject(value);
  const assistantReplyRaw = obj.assistant_reply ?? obj.assistantReply;
  const applyChangeRaw = obj.apply_change ?? obj.applyChange;
  const taskInstructionRaw = obj.task_instruction ?? obj.taskInstruction;
  const assistantPreferencesRaw = obj.assistant_preferences ?? obj.assistantPreferences;
  const updatedOutputRaw = obj.updated_output ?? obj.updatedOutput;
  const updatedTextRaw = obj.updated_text ?? obj.updatedText;
  return {
    assistantReply: nonEmptyString(assistantReplyRaw, '我已经理解你的意思了。'),
    action: normalizeAction(obj.action),
    applyChange: applyChangeRaw === true || String(applyChangeRaw ?? '').trim().toLowerCase() === 'true',
    taskInstruction: typeof taskInstructionRaw === 'string' ? String(taskInstructionRaw) : '',
    assistantPreferences:
      typeof assistantPreferencesRaw === 'string' ? String(assistantPreferencesRaw) : '',
    updatedOutput: updatedOutputRaw,
    updatedText: typeof updatedTextRaw === 'string' ? String(updatedTextRaw) : '',
  };
}

function buildCommonPromptParts(args: {
  roleLabel: string;
  targetLabel: string;
  currentOutputText: string;
  currentTaskInstruction: string;
  currentPreferences: string;
  history: AssistantHistoryEntry[];
  userMessage: string;
  outputInstruction: string;
  extraRules: string[];
}) {
  return [
    `你是一个对话式${args.roleLabel}助手，由 GPT API 驱动。你既能聊天答疑，也能直接修改当前选中节点的内容，还能记录长期偏好。`,
    '你必须先判断用户意图，再决定执行哪一种动作。',
    '',
    '可选动作 action 只有四种：chat、revise_output、update_task、update_preferences。',
    '1. chat：用户在闲聊、提问、讨论方案，但没有要求你立即修改当前结果。',
    '2. revise_output：用户明确要求直接修改当前节点已经生成的内容。',
    '3. update_task：用户想补充下次执行时要遵守的任务要求、风格限制或方向约束。',
    '4. update_preferences：用户想让你记住长期偏好，例如“以后更电影感”“默认更克制”。',
    '',
    '严格输出 JSON 对象，不要 markdown，不要解释性前缀。',
    'JSON 对象必须且仅有这些字段：assistant_reply, action, apply_change, updated_output, updated_text, task_instruction, assistant_preferences。',
    '',
    '通用约束：',
    '- 当 action=chat 时：apply_change=false，并保持 updated_output / updated_text 为原值。',
    '- 当 action=update_task 时：apply_change=true，但不要直接改当前 output，只更新 task_instruction。',
    '- 当 action=update_preferences 时：apply_change=true，但不要直接改当前 output，只更新 assistant_preferences。',
    '- assistant_reply 必须自然、简洁，像创作搭子，不要机械复述规则。',
    ...args.extraRules,
    '',
    `当前目标节点：${args.targetLabel}`,
    `当前节点内容：\n${args.currentOutputText}`,
    '',
    `当前任务补充要求：\n${args.currentTaskInstruction || '（当前无额外任务要求）'}`,
    '',
    `当前长期偏好：\n${args.currentPreferences || '（当前无长期偏好）'}`,
    '',
    `历史对话：\n${buildHistoryText(args.history)}`,
    '',
    `本轮用户消息：\n${args.userMessage.trim()}`,
    '',
    `updated_output 的结构要求：\n${args.outputInstruction}`,
  ].join('\n');
}

function buildAssistantSystemPrompt(roleLabel: string): string {
  return `你是对话式${roleLabel}助手。你要在聊天、直接改稿、更新任务要求、记录长期偏好之间做准确判断。`;
}

function isGatewayUnavailableError(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error ?? '');
  return /(上游服务|网络异常|Failed to fetch|fetch failed|网关|超时|timeout|temporarily unavailable|unavailable|503|504|ECONN|socket)/i.test(
    message,
  );
}

async function invokeAssistantJsonObject(params: {
  systemPrompt: string;
  userPrompt: string;
  temperature?: number;
}): Promise<unknown> {
  if (getResolvedPipelineExecutionMode() !== 'model') {
    throw new Error('当前为 Fast 本地模式：智能助手改稿只在 Deep/API 模式下可用。请先切到 Deep 再发送反馈。');
  }

  let lastError: unknown;
  const maxAttempts = 3;
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      return await invokeLlmJsonObject(params);
    } catch (error) {
      lastError = error;
      if (!isGatewayUnavailableError(error) || attempt >= maxAttempts) {
        if (attempt >= maxAttempts && isGatewayUnavailableError(error)) {
          throw new Error(
            `${error instanceof Error ? error.message : String(error)} 节点助手已自动重试 ${maxAttempts} 轮，但本次模型调用仍未成功。`,
          );
        }
        throw error;
      }
      await new Promise((resolve) => setTimeout(resolve, 450 * attempt));
    }
  }
  throw lastError instanceof Error ? lastError : new Error(String(lastError ?? '节点助手调用失败。'));
}

export async function runTextNodeAssistant(params: {
  data: StudioNodeData;
  history: AssistantHistoryEntry[];
  userMessage: string;
}): Promise<NodeAssistantResult> {
  const currentText = params.data.raw_text ?? params.data.input ?? '';
  const prompt = buildCommonPromptParts({
    roleLabel: '文本创作',
    targetLabel: `${params.data.label}（文本卡片）`,
    currentOutputText: currentText || '（当前为空文本）',
    currentTaskInstruction: params.data.assistant_task_instruction ?? '',
    currentPreferences: params.data.assistant_preferences ?? '',
    history: params.history,
    userMessage: params.userMessage,
    outputInstruction:
      '文本卡片不使用 updated_output，请保持为 null；若 action=revise_output，则 updated_text 必须返回完整新文本。',
    extraRules: [
      '- 文本卡片可用 revise_output，updated_text 必须是完整的新文本，而不是摘要或 diff。',
      '- 如果用户只是在补充“下次写得更克制、口语一些”这类要求，可使用 update_task。',
    ],
  });

  const parsed = parseAssistantEnvelope(
    await invokeAssistantJsonObject({
      systemPrompt: buildAssistantSystemPrompt('文本创作'),
      userPrompt: prompt,
      temperature: 0.35,
    }),
  );

  return {
    targetKind: 'text',
    assistantReply: parsed.assistantReply,
    action: parsed.action,
    applyChange: parsed.applyChange,
    updatedText: parsed.updatedText || currentText,
    taskInstruction: parsed.taskInstruction || (params.data.assistant_task_instruction ?? ''),
    assistantPreferences: parsed.assistantPreferences || (params.data.assistant_preferences ?? ''),
  };
}

async function runStructuredNodeAssistant<T extends 'writing' | 'storyboard' | 'prompt'>(params: {
  kind: T;
  data: StudioNodeData;
  currentOutput: WritingOutput | StoryboardOutput | PromptOutput | null;
  history: AssistantHistoryEntry[];
  userMessage: string;
}): Promise<NodeAssistantResult> {
  const roleLabel =
    params.kind === 'writing' ? '编剧策划' : params.kind === 'storyboard' ? '分镜设计' : 'Prompt 设计';
  const targetLabel =
    params.kind === 'writing'
      ? `${params.data.label}（编剧节点）`
      : params.kind === 'storyboard'
        ? `${params.data.label}（分镜 / 镜头表节点）`
        : `${params.data.label}（Prompt 节点）`;

  const outputInstruction =
    params.kind === 'writing'
      ? 'updated_output 必须是完整 WritingOutput JSON，包含 plannedEpisodeCount、episodes、scenes。'
      : params.kind === 'storyboard'
        ? 'updated_output 必须是完整 StoryboardOutput JSON，优先包含 narrativeBeats 和 shots；shots 中每项至少要有 id、type、movement、description、content，可选 sceneRef、action、durationSec、note、mergedMembers。'
        : 'updated_output 必须是完整 PromptOutput JSON，包含 system、userTemplate、negative、parameters、shotPrompts；shotPrompts 每项都必须有 shot_id、prompt、negative_prompt、dimensions、character_asset_ids、scene_asset_ids、seedanceCard。修改 Prompt 时必须保留完整即梦工业模板，不得把 seedanceCard 压缩成普通段落。';

  const extraRules =
    params.kind === 'writing'
      ? [
          '- 如果当前节点还没有 output，且用户只是在补充方向，请优先使用 update_task，不要臆造完整写作结果。',
          '- revise_output 时必须返回完整 WritingOutput，而不是只改某一段。',
        ]
      : params.kind === 'storyboard'
        ? [
            '- revise_output 仅在用户明确要求修改当前分镜结果时使用。',
            '- 如果当前节点还没有分镜结果，且用户只是在补充方向，请优先使用 update_task。',
            '- 修改分镜时要返回完整 StoryboardOutput，而不是只给建议。',
          ]
        : [
            '- revise_output 仅在用户明确要求修改当前 Prompt 结果时使用。',
            '- 如果当前节点还没有 Prompt 输出，且用户只是在补充方向，请优先使用 update_task。',
            '- 修改 Prompt 时要返回完整 PromptOutput，而不是只给建议。',
            '- 修改 Prompt 时必须继续保留完整 seedanceCard 模板、双版本构图、挂载、起端、变化、落幅、稳幅、过门、运动协议、声音/氛围、钉子4行等关键字段。',
          ];

  const prompt = buildCommonPromptParts({
    roleLabel,
    targetLabel,
    currentOutputText: params.currentOutput ? stringify(params.currentOutput) : '（当前节点尚无 output）',
    currentTaskInstruction: params.data.assistant_task_instruction ?? '',
    currentPreferences: params.data.assistant_preferences ?? '',
    history: params.history,
    userMessage: params.userMessage,
    outputInstruction,
    extraRules,
  });

  let parsed = parseAssistantEnvelope(
    await invokeAssistantJsonObject({
      systemPrompt: buildAssistantSystemPrompt(roleLabel),
      userPrompt: prompt,
      temperature: 0.35,
    }),
  );

  if (
    shouldForceStructuredRevision({
      currentOutput: params.currentOutput,
      userMessage: params.userMessage,
      action: parsed.action,
      applyChange: parsed.applyChange,
    })
  ) {
    const forcedPrompt = [
      prompt,
      '',
      '【强制改稿模式】',
      '用户这次是在对当前已生成结果提出直接修改意见，不是闲聊，也不是只更新下次执行要求。',
      '这一次必须返回：',
      '- action = revise_output',
      '- apply_change = true',
      '- updated_output = 完整的新结果，不能只给建议，不能省略原有关键字段',
      '- assistant_reply = 简短说明你已经按意见完成了修改',
    ].join('\n');

    parsed = parseAssistantEnvelope(
      await invokeAssistantJsonObject({
        systemPrompt: buildAssistantSystemPrompt(roleLabel),
        userPrompt: forcedPrompt,
        temperature: 0.2,
      }),
    );
  }

  let updatedOutput = params.currentOutput;
  if (parsed.action === 'revise_output' && parsed.applyChange) {
    if (params.kind === 'writing') updatedOutput = assertWritingOutput(parsed.updatedOutput);
    if (params.kind === 'storyboard') updatedOutput = assertStoryboardOutput(parsed.updatedOutput);
    if (params.kind === 'prompt') updatedOutput = assertPromptOutput(parsed.updatedOutput);
  }

  return {
    targetKind: params.kind,
    assistantReply: parsed.assistantReply,
    action: parsed.action,
    applyChange: parsed.applyChange,
    updatedOutput,
    taskInstruction: parsed.taskInstruction || (params.data.assistant_task_instruction ?? ''),
    assistantPreferences: parsed.assistantPreferences || (params.data.assistant_preferences ?? ''),
  };
}

export async function runNodeAssistant(params: {
  data: StudioNodeData;
  history: AssistantHistoryEntry[];
  userMessage: string;
  currentOutput?: WritingOutput | StoryboardOutput | PromptOutput | null;
}): Promise<NodeAssistantResult> {
  if (params.data.type === 'text_node') {
    return runTextNodeAssistant({
      data: params.data,
      history: params.history,
      userMessage: params.userMessage,
    });
  }
  if (params.data.type === 'writing') {
    return runStructuredNodeAssistant({
      kind: 'writing',
      data: params.data,
      currentOutput: (params.currentOutput as WritingOutput | null | undefined) ?? null,
      history: params.history,
      userMessage: params.userMessage,
    });
  }
  if (params.data.type === 'storyboard' || params.data.type === 'shot_list_node') {
    return runStructuredNodeAssistant({
      kind: 'storyboard',
      data: params.data,
      currentOutput: (params.currentOutput as StoryboardOutput | null | undefined) ?? null,
      history: params.history,
      userMessage: params.userMessage,
    });
  }
  if (params.data.type === 'prompt') {
    return runStructuredNodeAssistant({
      kind: 'prompt',
      data: params.data,
      currentOutput: (params.currentOutput as PromptOutput | null | undefined) ?? null,
      history: params.history,
      userMessage: params.userMessage,
    });
  }
  throw new Error('当前节点类型暂不支持智能助手。');
}
