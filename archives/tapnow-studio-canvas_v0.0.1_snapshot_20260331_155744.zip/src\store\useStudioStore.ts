﻿/**
 * Studio 閻㈣绔烽崗銊ョ湰閻樿埖鈧緤绱橺ustand閿?
 *
 * 閳?閼哄倻鍋?`data` 韫囧懎锝為敍姝ヾ, type, department, status, input, output, review_result, version閿涘牏琚崹瀣剁窗`StudioNodeData`閿?
 * 閳?濞翠焦鎸夌痪璺ㄥЦ閹緤绱癗OT_STARTED 閳?IN_PROGRESS 閳?REVIEWED閿涘牊鈧崵娲冨鏌ユ閿涘矁顕涢幆鍛蓟闁绱氶埆?IN_PROGRESS閿涘牅绱崠鏍嚡娴狅綇绱殀 APPROVED | REJECTED閿涙稒妫悽璇茬娴犲秴褰查崙铏瑰箛 WAITING_REVIEW
 *    - 閺嶏繝鐛欓敍姝歝anTransitionPipelineStatus`閿?/workflow.ts閿? `patchNodeData` 閸愬懎顕?`status` 閻ㄥ嫭鐗庢?
 *    - 娑撳鐖跺鏇犳暏閿涙氨绱崜褑绁禍褌绮涢悽?`getLatestApprovedWritingBundle`閿涙稑鍨庨梹婊堝劥姒涙顓婚悪顒傜彌濞戝牐鍨傞懞鍌滃仯 `input` 缁绢垱鏋冮張顒婄礄閸欘垱甯?TEXT_NODE閿?
 */
import {
  addEdge,
  applyEdgeChanges,
  applyNodeChanges,
  type Connection,
  type Edge,
  type EdgeChange,
  type NodeChange,
} from '@xyflow/react';
import { create } from 'zustand';
import { runPromptLeaderReview } from '@/agents/promptAgents';
import {
  cloneStoryboardOutput,
  runStoryboardLeaderReview,
  tryParseStoryboardOutput,
} from '@/agents/storyboardAgents';
import { runWritingLeaderReview } from '@/agents/writingAgents';
import { executeEmployeePhase, executeLeaderPhase } from '@/services/agents/executeTask';
import { runNodeAssistant } from '@/services/nodeAssistant';
import { ingestWritingOutputToProjectContext } from '@/services/ProjectContext';
import { mergeDownstreamSkillsFromChain } from '@/services/skillChain';
import { getSkillById, normalizeMountedSkillIdsForKind } from '@/services/skillLoader';
import {
  buildWorkflowAgentStageHint,
  buildWorkflowAgentStartMessage,
  detectWorkflowAgentInputType,
  detectWorkflowAgentIntent,
  detectWorkflowAgentMode,
  resolveWorkflowRoute,
  stageLabel,
  type WorkflowAgentSession,
} from '@/services/workflowAgent';
import {
  DEPT_OUTPUT_HANDLE_ID,
  mergedTextInputForDepartment,
  mergedUpstreamForTextNode,
  resolveDepartmentExecutionInput,
} from '@/services/graphInput';
import {
  SHOT_LIST_LINK_HANDLE_ID,
  SHOT_LIST_PARENT_HANDLE_ID,
  isShotListItemOutputHandleId,
  makeShotListItemOutputHandleId,
  parseShotListItemOutputHandleId,
} from '@/utils/shotListWire';
import type { StudioRFNode } from '@/types/reactFlow';
import {
  type AssistantHistoryEntry,
  type ApprovedAsset,
  type ChatMessage,
  type Department,
  type NodeKind,
  type NodeStatus,
  type PromptOutput,
  type StoryboardOutput,
  type StudioNodeData,
  type WritingOutput,
  DEFAULT_AI_REVIEW_PASS_SUMMARY,
  REVIEW_RESULT_APPROVE_AS_IS,
  REVIEW_RESULT_MANUAL_PASS,
} from '@/types/studio';
import { layoutStudioNodesWithDagre } from '@/utils/dagreLayout';
import {
  normalizeRestoredStudioNode,
  rebindStudioNodeRuntimeHandlers,
  stripFunctionsDeep,
} from '@/utils/studioNodePersistence';
import { formatReviewOptimizationPayload } from '@/utils/pipelineReviewContentPreview';
import { formatPipelineOutputPreview, typewriterStream } from '@/utils/streamPreview';
import { canTransitionPipelineStatus, PIPELINE_INITIAL_STATUS } from './workflow';

function uid(prefix: string) {
  return `${prefix}_${Math.random().toString(36).slice(2, 10)}`;
}

type PipelineKind = Exclude<NodeKind, 'text_node' | 'shot_list_node' | 'storyboard_file_node'>;

function kindToDepartment(kind: PipelineKind): Department {
  if (kind === 'writing') return 'WRITING';
  if (kind === 'storyboard') return 'STORYBOARD';
  return 'PROMPT';
}

function deptLabel(d: Department): string {
  if (d === 'WRITING') return '缂傛牕澧介柈?';
  if (d === 'STORYBOARD') return '閸掑棝鏆呴柈?';
  if (d === 'TEXT') return '閺傚洦婀伴崡锛勫';
  if (d === 'SHOT_LIST') return '闂€婊冦仈鐞?';
  return 'Prompt闁?';
}

/** 閸涙ê浼愮€瑰本鍨氶崥搴ゅ殰閸斻劏袝閸欐垶鈧崵娲冪€光剝鐗抽崜宥囨畱缁涘绶熼敍鍫燁嚑缁夋帪绱?*/
const LEADER_AUTO_DELAY_MS = 1000;
const STOP_TASK_MESSAGE = '瀹稿弶澧滈崝銊ヤ粻濮濄垹缍嬮崜宥勬崲閸斅扳偓?';
const SHOT_LIST_DEFAULT_WIDTH = 800;
const SHOT_LIST_DEFAULT_HEIGHT = 420;
const UNDO_STACK_LIMIT = 60;
const activeTaskAbortControllers = new Map<string, AbortController>();

/** 闁劑妫梻鏉戞彥闁喐濯虹痪鍖＄窗閸掑棝鏆?閳?Prompt 娑撳秴婀銈夋懠閸愬拑绱欐い鑽ょ病闂€婊冦仈鐞涖劌鐡欓懞鍌滃仯 Output閿涘鈧?*/
function canDeptChain(upstream: PipelineKind, downstream: PipelineKind): boolean {
  if (upstream === 'writing' && downstream === 'storyboard') return true;
  if (upstream === 'writing' && downstream === 'prompt') return true;
  return false;
}

function makeTextNodeData(id: string, text = '', positionLabel?: string): StudioNodeData {
  return {
    id,
    type: 'text_node',
    department: 'TEXT',
    status: 'APPROVED',
    input: text,
    raw_text: text,
    output: null,
    review_result: null,
    version: 0,
    label: positionLabel ?? '閺傚洦婀伴崡锛勫',
    assistant_preferences: '',
    assistant_task_instruction: '',
  };
}

function makeStoryboardFileNodeData(id: string, positionLabel?: string): StudioNodeData {
  return {
    id,
    type: 'storyboard_file_node',
    department: 'STORYBOARD_FILE',
    status: 'APPROVED',
    input: '',
    output: null,
    review_result: null,
    version: 0,
    label: positionLabel ?? '分镜表文件',
    assistant_preferences: '',
    assistant_task_instruction: '',
  };
}

function makeNodeData(
  id: string,
  kind: PipelineKind,
  input = '',
  positionLabel?: string,
): StudioNodeData {
  const department = kindToDepartment(kind);
  return {
    id,
    type: kind,
    department,
    status: PIPELINE_INITIAL_STATUS,
    input,
    output: null,
    review_result: null,
    version: 0,
    label: positionLabel ?? `${deptLabel(department)} 璺?${id.slice(-4)}`,
    mounted_skills: normalizeMountedSkillIdsForKind(kind, []),
    assistant_preferences: '',
    assistant_task_instruction: '',
  };
}

function makeShotListNodeData(
  id: string,
  output: StoryboardOutput | null,
  snapshot: StoryboardOutput | null,
  opts?: {
    sourceStoryboardNodeId?: string;
    sourceStoryboardFileNodeId?: string;
    sourceSceneCount?: number;
  },
): StudioNodeData {
  return {
    id,
    type: 'shot_list_node',
    department: 'SHOT_LIST',
    status: 'APPROVED',
    input: '',
    output,
    review_result: null,
    version: 0,
    label: `分镜表 · ${id.slice(-4)}`,
    sourceStoryboardNodeId: opts?.sourceStoryboardNodeId,
    sourceStoryboardFileNodeId: opts?.sourceStoryboardFileNodeId,
    canvasWidth: SHOT_LIST_DEFAULT_WIDTH,
    canvasHeight: SHOT_LIST_DEFAULT_HEIGHT,
    storyboard_ai_snapshot: snapshot,
    sourceSceneCount: opts?.sourceSceneCount,
    mounted_skills: [],
    assistant_preferences: '',
    assistant_task_instruction: '',
  };
}

function getNodeAssistantHistory(messages: ChatMessage[], nodeId: string): AssistantHistoryEntry[] {
  return messages
    .filter((msg) => msg.nodeId === nodeId && (msg.role === 'user' || msg.role === 'assistant'))
    .slice(-12)
    .map((msg) => ({
      role: msg.role === 'assistant' ? 'assistant' : 'user',
      content: msg.text,
    }));
}

function findStoryboardShotListChild(
  nodes: StudioRFNode[],
  edges: Edge[],
  parentNodeId: string,
): StudioRFNode | null {
  const edge = edges.find(
    (e) => e.source === parentNodeId && e.sourceHandle === SHOT_LIST_LINK_HANDLE_ID,
  );
  if (!edge) return null;
  return (
    nodes.find(
      (n) => n.id === edge.target && n.type === 'shotList' && n.data.type === 'shot_list_node',
    ) ?? null
  );
}

type StudioState = {
  nodes: StudioRFNode[];
  edges: Edge[];
  assets: ApprovedAsset[];
  messages: ChatMessage[];
  activeNodeId: string | null;
  selectedNodeId: string | null;
  detailOpen: boolean;
  requestFitNodeId: string | null;
  shotListSelectedWiresByNodeId: Record<string, string[]>;
  undoStack: UndoSnapshot[];
  workflowAgentSession: WorkflowAgentSession | null;

  onNodesChange: (changes: NodeChange<StudioRFNode>[]) => void;
  onEdgesChange: (changes: EdgeChange<Edge>[]) => void;
  /** 閹?id 缁夊娅庢潻鐐靛殠楠炶泛鍩涢弬棰佺瑓濞撴悂鍎撮梻?/ 閺傚洦婀伴懞鍌滃仯閻ㄥ嫬鎮庨獮鎯扮翻閸?*/
  removeEdges: (edgeIds: string[]) => void;
  onConnect: (c: Connection) => void;
  setShotListSelectedWires: (nodeId: string, wireIds: string[]) => void;
  setSelected: (id: string | null) => void;
  setDetailOpen: (open: boolean) => void;
  setActiveNodeId: (id: string | null) => void;
  consumeFitRequest: () => void;
  pushMessage: (m: Omit<ChatMessage, 'id' | 'ts'> & { id?: string }) => string;
  linkChatMessageToNode: (messageId: string, nodeId: string) => void;
  submitAssistantChat: (text: string, position?: { x: number; y: number }) => Promise<void>;
  submitWorkflowAgentChat: (text: string, position?: { x: number; y: number }) => Promise<void>;
  clearWorkflowAgentSession: () => void;
  registerAsset: (a: ApprovedAsset) => void;
  patchNodeData: (id: string, patch: Partial<StudioNodeData>, bumpVersion?: boolean) => void;
  /** 闂€婊冦仈鐞涖劏濡悙纭呫€冮弽鑲╃椽鏉堟埊绱版稉搴ｅ煑閸掑棝鏆呴懞鍌滃仯 `output` 閸氬本顒為獮璺哄煕閺傞绗呭〒?Prompt 缁涘鎮庨獮鎯扮翻閸?*/
  patchShotListNodeOutput: (shotListId: string, output: StoryboardOutput, bumpVersion?: boolean) => void;
  /** 閸掑棝鏆呴崨妯轰紣娴溠冨毉閺堝鏅ラ梹婊冦仈閸氬函绱伴懛顏勫З閸︺劋绗呴弬鐟板灡瀵ゆ椽鏆呮径纾嬨€冪€涙劘濡悙鐟拌嫙鏉╃偟鍤庨敍灞惧灗閸掗攱鏌婂鍙夋箒鐎涙劘濡悙瑙勬殶閹?*/
  ensureShotListForStoryboard: (storyboardNodeId: string) => void;
  /** 鐏忓棗缍嬮崜宥呭瀻闂€?output 閹恒劑鈧礁鍩屽鑼拨鐎规氨娈戦梹婊冦仈鐞涖劌鐡欓懞鍌滃仯閿涘牅绗夐崘娆忔礀閻栨儼濡悙鐧哥礆 */
  syncShotListNodesFromStoryboard: (storyboardNodeId: string) => void;
  ensureShotListForStoryboardFile: (storyboardFileNodeId: string) => void;
  syncShotListNodesFromStoryboardFile: (storyboardFileNodeId: string) => void;
  setStatus: (id: string, next: NodeStatus) => boolean;
  addDepartmentNode: (kind: PipelineKind, position?: { x: number; y: number }) => string;
  addTextNode: (text?: string, position?: { x: number; y: number }) => string;
  addStoryboardFileNode: (position?: { x: number; y: number }) => string;
  /** 閸︺劍瀵氱€规艾娼楅弽鍥у灡瀵?TEXT_NODE閿涘苯鑻熸潻鐐插煂闁劑妫?Input閿涘澅argetHandle `in`閿?*/
  createTextNodeLinkedToDepartment: (deptId: string, position: { x: number; y: number }) => string;
  /** 娴犲骸褰為弻鍕缁惧潡鍣撮弨鎯ф躬缁岃櫣娅ф径鍕倵閿涘瞼鏁遍懣婊冨礋闁瀚ㄩ崚娑樼紦閼哄倻鍋ｉ獮鎯板殰閸斻劏绻涚痪?*/
  completeConnectionMenuPick: (p: {
    fromNodeId: string;
    fromHandleId: string | null;
    fromHandleType: 'source' | 'target' | null;
    pick: 'text_node' | 'storyboard_file_node' | 'writing' | 'storyboard' | 'prompt';
    flowPosition: { x: number; y: number };
  }) => string | undefined;
  startWritingPipeline: (text: string, position?: { x: number; y: number }) => string;
  startStoryboardPipeline: (position?: { x: number; y: number }) => string;
  /** 閸掑棝鏆呴悪顒傜彌濡€崇础閿涙艾鐔€娴滃骸缍嬮崜?`input` 閸撗勬拱閺傚洦婀伴幏鍡毿掗梹婊冦仈閿涘苯鐣幋鎰倵鏉╂稑鍙?REVIEWED閿涘牊鍨ㄩ弮褎鈧?WAITING_REVIEW閿?*/
  runStoryboardFromInput: (id: string) => void;
  /** 閻㈣绔烽妴灞惧⒔鐞涘被鈧稄绱伴崗鍫濇値楠?Input 鏉╃偛鍙嗛崘宥堢獓缂傛牕澧介崨妯轰紣 閳?REVIEWED */
  runWritingFromInput: (id: string) => void;
  startPromptPipeline: (brief: string, position?: { x: number; y: number }) => string;
  /** 閻㈣绔烽妴灞惧⒔鐞涘被鈧稄绱伴崗鍫濇値楠?Input 鏉╃偛鍙嗛崘宥堢獓 Prompt 閸涙ê浼?閳?REVIEWED */
  runPromptFromInput: (id: string) => void;
  /**
   * 閺嶇绺鹃幍褑顢戦崗銉ュ經閿涙艾鎮庨獮?Input 閳?IN_PROGRESS 閳?閸涙ê浼?+ 閼奉亜濮╅幀鑽ゆ磧 閳?REVIEWED閿涘牆鎯?ai_review_feedback閿涘鈧?
   * `optimizeFromReviewed`閿涙矮绮庡鏌ユ閹焦瀵滈幇蹇氼潌鏉╊厺鍞妴鍌濇硶闁劑妫潏鎾冲弳娴犲秳绶风挧鏍︾瑐濞?APPROVED 鐠у嫪楠囬妴?
   */
  executeNodeTask: (nodeId: string, opts?: { optimizeFromReviewed?: boolean }) => Promise<void>;
  stopNodeTask: (nodeId?: string | null) => void;
  /** 瀹告煡妲勯敍姘殺閵嗗本澧界悰?AI 娴兼ê瀵查妴宥呭晸閸忋儱宸婚崣鎻掕嫙闁插秵鏌婄捄鎴濇喅瀹?+ 閹崵娲?*/
  runReviewedOptimization: (nodeId?: string | null) => void;
  /** 瀹告煡妲勯敍姘辨樊閹镐胶骞囬悩鍓佺矒鐎癸繝鈧俺绻冮敍鍫㈢搼閸氬矂鈧銆?B閿?*/
  approveReviewedAsIs: (nodeId?: string | null) => string | undefined;
  /** 鏉╂柨娲栭張顒侇偧鐏忔繆鐦€光剝鐗抽惃鍕窗閺嶅洩濡悙?id閿涘牅绌舵禍搴や喊婢垛晜瀵氭禒銈呭彠閼辨柨鐣炬担宥忕礆閿涙稒婀崣鎴ｆ崳鐎光剝鐗抽弮?undefined */
  triggerLeaderReview: (nodeId?: string | null) => Promise<string | undefined>;
  /**
   * REVIEWED閿涙氨鐡戦崥灞烩偓宀€娣幐浣哄箛閻樺爼鈧俺绻冮妴宥忕礄闁銆?B閿涘苯宸婚崣鑼额唶娑撹桨姹夊銉┾偓姘崇箖閿涘鈧?
   * WAITING_REVIEW閿涘牊妫悽璇茬閿涘绱扮捄瀹犵箖娴滃本顐?AI 閹崵娲冮敍宀€娲块幒?APPROVED閿涘畭review_result` 娑?REVIEW_RESULT_MANUAL_PASS閵?
   */
  manualPassLeaderReview: (nodeId?: string | null) => string | undefined;
  focusNode: (id: string, opts?: { openDetail?: boolean }) => void;
  retryPipeline: (id: string) => void;
  /** 閸欐牗绉烽幍瀣З鐟曞棛娲婇敍灞肩矤鏉╃偟鍤庨柌宥嗘煀閸氬牆鑻?input */
  syncDepartmentInputFromGraph: (deptId: string) => void;
  /** 閹靛綊鍣洪崚鐘绘珟閼哄倻鍋ｉ敍鍫濆礁闁款喗鍨ㄧ粙瀣碍閸栨牭绱?*/
  removeNodesByIds: (ids: string[]) => void;
  /** Dagre 閼奉亜濮╃仦鍌滈獓閹烘帒绔?*/
  layoutCanvasWithDagre: () => void;
  undo: () => void;
  /** 娴?.json / 閼奉亜濮╃€涙ɑ銆傛潪钘夊弳閿涙碍娴涢幑?nodes閵嗕躬dges閿涘本绔荤粚楦跨カ娴溠呮鐠佹澘鑻熼崚閿嬫煀閸ユ儳鎮庨獮鎯扮翻閸?*/
  hydrateProject: (
    nodes: StudioRFNode[],
    edges: Edge[],
    opts?: { broadcastText?: string },
  ) => void;
  /** 妞ょ敻娼伴崝鐘烘祰閹存牗瀵旀稊鍛闁插秷娴囬崥搴窗娑撻缚濡悙?data 闁插秵鏌婇幐鍌濇祰 onExecute / onDelete閿涘湞SON 閺冪姵纭舵穱婵嗙摠閸戣姤鏆熼敍?*/
  ensureRuntimeBindingsOnNodes: () => void;
  /**
   * 閸掗攱鏌?鏉炶棄鍙嗛崥搴窗閹稿鈧苯鍨庨梹婊冪俺娓?閳?闂€婊冦仈鐞涖劑銆婃笟褋鈧秷绻涚痪鍧楀櫢閸?sourceStoryboardNodeId閿涘苯鑻熺€靛綊缍堥悥璺虹摍 output閿?
   * 閺堫偄鐔崚閿嬫煀闁劑妫崥鍫濊嫙鏉堟挸鍙嗛敍鍫濇儓 Prompt 閹恒儵鏆呮径纾嬨€冮敍澶涚礉娣囨繆鐦夋稉搴＄秼閸撳秴娴樻稉鈧懛娣偓?
   */
  reconcileShotListGraphBindings: () => void;
};

const PIPELINE_DECISION_FLASH_MS = 1900;

function schedulePipelineFlashClear(get: () => StudioState, nodeId: string, until: number) {
  window.setTimeout(() => {
    const cur = get().nodes.find((n) => n.id === nodeId)?.data.pipeline_decision_flash;
    if (cur?.until === until) {
      get().patchNodeData(nodeId, { pipeline_decision_flash: null }, false);
    }
  }, PIPELINE_DECISION_FLASH_MS + 120);
}

/** 閹靛濮╂潏鎾冲弳娴兼ê鍘涢敍姘冲閻劍鍩涘鎻掓躬閸欏厖鏅堕棃銏℃緲缁鍒涢敍灞肩瑝鐟曞棛娲婄粩顖氬經閸氬牆鑻熺紒鎾寸亯 */
function shouldPreferManualInput(nodeData: StudioNodeData | undefined): boolean {
  if (!nodeData) return false;
  return nodeData.inputSource === 'manual' && Boolean((nodeData.input ?? '').trim());
}

/** 閸掑棝鏆呴懞鍌滃仯鎼存洑鏅堕崣銉︾労 閳?闂€婊冦仈鐞涖劑銆婃笟褍褰為弻鍕剁窗娑撯偓閺壜ょ珶鐎电懓绨叉稉鈧稉顏嗗煑閸掑棝鏆?id */
function buildStoryboardParentByShotListId(
  nodes: StudioRFNode[],
  edges: Edge[],
): Map<string, string> {
  const map = new Map<string, string>();
  for (const e of edges) {
    if (e.sourceHandle !== SHOT_LIST_LINK_HANDLE_ID) continue;
    if (e.targetHandle != null && e.targetHandle !== SHOT_LIST_PARENT_HANDLE_ID) continue;
    const src = nodes.find((n) => n.id === e.source);
    const tgt = nodes.find((n) => n.id === e.target);
    if (!src || !tgt || tgt.type !== 'shotList' || tgt.data.type !== 'shot_list_node') continue;
    if (
      !(
        (src.type === 'department' && src.data.type === 'storyboard') ||
        src.type === 'storyboardFile'
      )
    ) {
      continue;
    }
    map.set(e.target, e.source);
  }
  return map;
}

function storyboardOutputFingerprint(parsed: ReturnType<typeof tryParseStoryboardOutput>): string {
  if (!parsed) return '';
  try {
    return JSON.stringify({
      shots: parsed.shots,
      beats: parsed.narrativeBeats ?? [],
    });
  } catch {
    return `err:${String(parsed.shots?.length ?? 0)}`;
  }
}

function patchChangesNodeData(
  data: StudioNodeData,
  patch: Partial<StudioNodeData>,
  bumpVersion: boolean,
): boolean {
  if (bumpVersion) return true;
  for (const key of Object.keys(patch) as Array<keyof StudioNodeData>) {
    if (!Object.is(data[key], patch[key])) return true;
  }
  return false;
}

function resyncConsumersAfterEdgeMutation(get: () => StudioState) {
  const { nodes, edges } = get();
  for (const n of nodes) {
    if (n.type === 'department') {
      if (shouldPreferManualInput(n.data)) continue;
      const merged = mergedTextInputForDepartment(n.id, nodes, edges);
      if (merged !== null) {
        get().patchNodeData(n.id, { input: merged, inputSource: 'graph' }, false);
      }
    }
    if (n.type === 'textNode') {
      const m = mergedUpstreamForTextNode(n.id, nodes, edges);
      if (m !== null) {
        get().patchNodeData(n.id, { raw_text: m, input: m }, false);
      }
    }
  }
}

/** 閸掑棝鏆?output 閸欐ɑ娲块崥搴″煕閺傛媽绻涢崷銊ュ礁娓?Output 娑撳﹦娈戞稉瀣埗闁劑妫?/ TEXT 閸氬牆鑻熸潏鎾冲弳 */
function refreshDownstreamAfterDepartmentOutputChange(
  get: () => StudioState,
  departmentId: string,
  options?: { ignoreManualInput?: boolean },
) {
  const { nodes, edges } = get();
  const outgoing = edges.filter(
    (e) =>
      e.source === departmentId &&
      (e.sourceHandle === DEPT_OUTPUT_HANDLE_ID || e.sourceHandle == null),
  );
  const seen = new Set<string>();
  for (const e of outgoing) {
    if (seen.has(e.target)) continue;
    seen.add(e.target);
    const tn = nodes.find((n) => n.id === e.target);
    if (tn?.type === 'department') {
      if (!options?.ignoreManualInput && shouldPreferManualInput(tn.data)) continue;
      const merged = mergedTextInputForDepartment(e.target, nodes, edges);
      if (merged !== null) {
        get().patchNodeData(e.target, { input: merged, inputSource: 'graph' }, false);
      }
    } else if (tn?.type === 'textNode') {
      const m = mergedUpstreamForTextNode(e.target, nodes, edges);
      if (m !== null) {
        get().patchNodeData(e.target, { raw_text: m, input: m }, false);
      }
    }
  }
}

function edgeIdentity(edge: Pick<Edge, 'source' | 'target' | 'sourceHandle' | 'targetHandle'>): string {
  return [edge.source, edge.target, edge.sourceHandle ?? '', edge.targetHandle ?? ''].join('::');
}

function addUniqueAnimatedEdges(edges: Edge[], connections: Connection[]): Edge[] {
  const seen = new Set(edges.map(edgeIdentity));
  let next = edges;
  for (const connection of connections) {
    const key = edgeIdentity(connection);
    if (seen.has(key)) continue;
    seen.add(key);
    next = addEdge({ ...connection, animated: true }, next);
  }
  return next;
}

function resolveShotListSourceHandlesForConnect(
  selectionMap: Record<string, string[]>,
  nodeId: string,
  sourceHandle: string | null | undefined,
): string[] {
  const draggedWireId = parseShotListItemOutputHandleId(sourceHandle);
  if (!draggedWireId) return [sourceHandle ?? DEPT_OUTPUT_HANDLE_ID];
  const selectedWireIds = selectionMap[nodeId] ?? [];
  if (selectedWireIds.length >= 2 && selectedWireIds.includes(draggedWireId)) {
    return selectedWireIds.map((wireId) => makeShotListItemOutputHandleId(wireId));
  }
  return [sourceHandle ?? DEPT_OUTPUT_HANDLE_ID];
}

type UndoSnapshot = {
  nodes: StudioRFNode[];
  edges: Edge[];
  assets: ApprovedAsset[];
  shotListSelectedWiresByNodeId: Record<string, string[]>;
  selectedNodeId: string | null;
  activeNodeId: string | null;
  detailOpen: boolean;
};

function makeRuntimeApi(get: () => StudioState) {
  return {
    executeNodeTask: (id: string) => get().executeNodeTask(id),
    focusNode: (id: string, o?: { openDetail?: boolean }) => get().focusNode(id, o),
    removeNodesByIds: (ids: string[]) => get().removeNodesByIds(ids),
  };
}

function snapshotNodesForUndo(nodes: StudioRFNode[]): StudioRFNode[] {
  return stripFunctionsDeep(nodes) as StudioRFNode[];
}

function makeUndoSnapshot(state: Pick<
  StudioState,
  | 'nodes'
  | 'edges'
  | 'assets'
  | 'shotListSelectedWiresByNodeId'
  | 'selectedNodeId'
  | 'activeNodeId'
  | 'detailOpen'
>): UndoSnapshot {
  return {
    nodes: snapshotNodesForUndo(state.nodes),
    edges: stripFunctionsDeep(state.edges) as Edge[],
    assets: stripFunctionsDeep(state.assets) as ApprovedAsset[],
    shotListSelectedWiresByNodeId: stripFunctionsDeep(
      state.shotListSelectedWiresByNodeId,
    ) as Record<string, string[]>,
    selectedNodeId: state.selectedNodeId,
    activeNodeId: state.activeNodeId,
    detailOpen: state.detailOpen,
  };
}

function undoSnapshotSignature(snapshot: UndoSnapshot): string {
  return JSON.stringify(snapshot);
}

type StudioSet = (
  partial:
    | Partial<StudioState>
    | StudioState
    | ((state: StudioState) => Partial<StudioState> | StudioState),
) => void;

function pushUndoSnapshot(set: StudioSet) {
  set((state) => {
    const snapshot = makeUndoSnapshot(state);
    const prev = state.undoStack[state.undoStack.length - 1];
    if (prev && undoSnapshotSignature(prev) === undoSnapshotSignature(snapshot)) {
      return state;
    }
    const nextStack =
      state.undoStack.length >= UNDO_STACK_LIMIT
        ? [...state.undoStack.slice(state.undoStack.length - UNDO_STACK_LIMIT + 1), snapshot]
        : [...state.undoStack, snapshot];
    return { undoStack: nextStack };
  });
}

function restoreUndoSnapshot(snapshot: UndoSnapshot, get: () => StudioState): Partial<StudioState> {
  const api = makeRuntimeApi(get);
  const normalized = snapshot.nodes.map(normalizeRestoredStudioNode);
  const rebound = rebindStudioNodeRuntimeHandlers(normalized, api).map((node) => ({
    ...node,
    selected: snapshot.selectedNodeId != null && node.id === snapshot.selectedNodeId,
    dragging: false,
  }));
  return {
    nodes: rebound,
    edges: stripFunctionsDeep(snapshot.edges) as Edge[],
    assets: stripFunctionsDeep(snapshot.assets) as ApprovedAsset[],
    shotListSelectedWiresByNodeId: stripFunctionsDeep(
      snapshot.shotListSelectedWiresByNodeId,
    ) as Record<string, string[]>,
    selectedNodeId: snapshot.selectedNodeId,
    activeNodeId: snapshot.activeNodeId,
    detailOpen: snapshot.detailOpen && snapshot.selectedNodeId != null,
    requestFitNodeId: null,
  };
}

function waitWithAbort(ms: number, signal?: AbortSignal): Promise<void> {
  if (!signal) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }
  if (signal.aborted) {
    return Promise.reject(new Error(STOP_TASK_MESSAGE));
  }
  return new Promise((resolve, reject) => {
    const timer = window.setTimeout(() => {
      signal.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      window.clearTimeout(timer);
      reject(new Error(STOP_TASK_MESSAGE));
    };
    signal.addEventListener('abort', onAbort, { once: true });
  });
}

export const useStudioStore = create<StudioState>((set, get) => ({
  nodes: [],
  edges: [],
  assets: [],
  messages: [],
  activeNodeId: null,
  selectedNodeId: null,
  detailOpen: false,
  requestFitNodeId: null,
  shotListSelectedWiresByNodeId: {},
  undoStack: [],
  workflowAgentSession: null,

  onNodesChange: (changes) => {
    if (
      changes.some(
        (change) =>
          change.type === 'remove' ||
          change.type === 'dimensions' ||
          (change.type === 'position' && change.dragging !== true),
      )
    ) {
      pushUndoSnapshot(set);
    }
    set((s) => {
      let toApply = changes as NodeChange<StudioRFNode>[];
      for (const c of changes) {
        if (c.type === 'remove') {
          const n = s.nodes.find((x) => x.id === c.id);
          if (n?.type === 'department' && n.data.type === 'storyboard') {
            for (const m of s.nodes) {
              if (m.type === 'shotList' && m.data.sourceStoryboardNodeId === c.id) {
                if (!toApply.some((t) => t.type === 'remove' && 'id' in t && t.id === m.id)) {
                  toApply = [...toApply, { type: 'remove', id: m.id } as NodeChange<StudioRFNode>];
                }
              }
            }
          }
          if (n?.type === 'storyboardFile') {
            for (const m of s.nodes) {
              if (m.type === 'shotList' && m.data.sourceStoryboardFileNodeId === c.id) {
                if (!toApply.some((t) => t.type === 'remove' && 'id' in t && t.id === m.id)) {
                  toApply = [...toApply, { type: 'remove', id: m.id } as NodeChange<StudioRFNode>];
                }
              }
            }
          }
        }
      }

      const removedIds = toApply
        .filter((c): c is NodeChange<StudioRFNode> & { type: 'remove'; id: string } => c.type === 'remove')
        .map((c) => c.id);

      const nextNodes = applyNodeChanges(toApply, s.nodes) as StudioRFNode[];

      let nextEdges = s.edges;
      let nextShotListSelectedWiresByNodeId = s.shotListSelectedWiresByNodeId;
      if (removedIds.length > 0) {
        const gone = new Set(removedIds);
        nextEdges = s.edges.filter((e) => !gone.has(e.source) && !gone.has(e.target));
        nextShotListSelectedWiresByNodeId = Object.fromEntries(
          Object.entries(s.shotListSelectedWiresByNodeId).filter(([nodeId]) => !gone.has(nodeId)),
        );
      }

      const sel = nextNodes.find((n) => n.selected)?.id ?? null;

      let activeNodeId = s.activeNodeId;
      if (activeNodeId && removedIds.includes(activeNodeId)) {
        activeNodeId = null;
      }

      const detailOpen = sel != null ? s.detailOpen : false;

      return {
        nodes: nextNodes,
        edges: nextEdges,
        selectedNodeId: sel,
        activeNodeId,
        detailOpen,
        shotListSelectedWiresByNodeId: nextShotListSelectedWiresByNodeId,
      };
    });
  },

  onEdgesChange: (changes) => {
    if (changes.some((change) => change.type === 'remove')) {
      pushUndoSnapshot(set);
    }
    set((s) => ({ edges: applyEdgeChanges(changes, s.edges) }));
    if (changes.some((ch) => ch.type === 'remove')) {
      get().reconcileShotListGraphBindings();
    } else {
      resyncConsumersAfterEdgeMutation(get);
    }
  },

  removeEdges: (edgeIds) => {
    if (edgeIds.length === 0) return;
    pushUndoSnapshot(set);
    const drop = new Set(edgeIds);
    set((s) => ({ edges: s.edges.filter((e) => !drop.has(e.id)) }));
    get().reconcileShotListGraphBindings();
    get().pushMessage({
      role: 'system',
      text: `瀹稿弶鏌囧鈧?${edgeIds.length} 閺壜ょ箾缁剧笡`,
    });
  },

  onConnect: (c) => {
    pushUndoSnapshot(set);
    const sourceNodeId = c.source;
    const sourceHandles =
      sourceNodeId != null
        ? resolveShotListSourceHandlesForConnect(
            get().shotListSelectedWiresByNodeId,
            sourceNodeId,
            c.sourceHandle,
          )
        : [c.sourceHandle ?? DEPT_OUTPUT_HANDLE_ID];
    set((s) => ({
      edges: addUniqueAnimatedEdges(
        s.edges,
        sourceHandles.map((sourceHandle) => ({ ...c, sourceHandle })),
      ),
    }));
    const { nodes, edges } = get();
    const tgt = c.target;
    if (!tgt) return;
    const targetNode = nodes.find((n) => n.id === tgt);
    if (targetNode?.type === 'department' && !shouldPreferManualInput(targetNode.data)) {
      const merged = mergedTextInputForDepartment(tgt, nodes, edges);
      if (merged !== null) {
        get().patchNodeData(tgt, { input: merged, inputSource: 'graph' }, false);
      }
    }
    if (targetNode?.type === 'textNode') {
      const m = mergedUpstreamForTextNode(tgt, nodes, edges);
      if (m !== null) {
        get().patchNodeData(tgt, { raw_text: m, input: m }, false);
      }
    }
    get().reconcileShotListGraphBindings();
  },

  setShotListSelectedWires: (nodeId, wireIds) =>
    set((s) => {
      const prev = s.shotListSelectedWiresByNodeId[nodeId] ?? [];
      if (prev.length === wireIds.length && prev.every((wireId, index) => wireId === wireIds[index])) {
        return s;
      }
      if (wireIds.length === 0) {
        if (!(nodeId in s.shotListSelectedWiresByNodeId)) return s;
        const next = { ...s.shotListSelectedWiresByNodeId };
        delete next[nodeId];
        return { shotListSelectedWiresByNodeId: next };
      }
      return {
        shotListSelectedWiresByNodeId: {
          ...s.shotListSelectedWiresByNodeId,
          [nodeId]: wireIds,
        },
      };
    }),

  setSelected: (id) =>
    set((s) => ({
      selectedNodeId: id,
      nodes: s.nodes.map((n) => ({ ...n, selected: id != null && n.id === id })),
    })),
  setDetailOpen: (open) => set({ detailOpen: open }),
  setActiveNodeId: (id) => set({ activeNodeId: id }),

  consumeFitRequest: () => set({ requestFitNodeId: null }),

  clearWorkflowAgentSession: () => set({ workflowAgentSession: null }),

  pushMessage: (m) => {
    const msg: ChatMessage = {
      id: m.id ?? uid('msg'),
      role: m.role,
      text: m.text,
      nodeId: m.nodeId,
      ts: Date.now(),
    };
    set((s) => ({ messages: [...s.messages, msg] }));
    return msg.id;
  },

  linkChatMessageToNode: (messageId, nodeId) => {
    set((s) => ({
      messages: s.messages.map((x) => (x.id === messageId ? { ...x, nodeId } : x)),
    }));
  },

  submitWorkflowAgentChat: async (text, position) => {
    const raw = text.trim();
    if (!raw) return;

    const now = Date.now();
    const flowPos = position ?? { x: 360, y: 260 };
    const currentSession = get().workflowAgentSession;
    const intent = detectWorkflowAgentIntent(raw, currentSession);

    get().pushMessage({ role: 'user', text: raw });

    if (intent === 'restart') {
      set({ workflowAgentSession: null });
      get().pushMessage({
        role: 'assistant',
        text: '瀹稿弶绔荤粚杞扮瑐娑撯偓鏉烆喗绁︾粙瀣╃瑐娑撳鏋冮妴鍌涘Ω閺傛壆娈戠亸蹇氼嚛閹存牕澧介張顒佹瀮閺堫剙褰傜紒娆愬灉閿涘本鍨滄导姘跺櫢閺傞璐熸担鐘侯潐閸掓帟鐭剧痪瑁も偓?',
      });
      return;
    }

    if (!currentSession || intent === 'start') {
      const inputType = detectWorkflowAgentInputType(raw);
      if (inputType === 'unknown') {
        get().pushMessage({
          role: 'assistant',
          text: '閹存垼绻曞▽鈩冪《缁嬪啿鐣鹃崚銈嗘焽鏉╂瑦妲哥亸蹇氼嚛鏉╂ɑ妲搁崜褎婀伴妴鍌欑稑閸欘垯浜掗惄瀛樺复鐠愬瓨娲跨€瑰本鏆ｉ惃鍕劀閺傚浄绱濋幋鏍偓鍛八夋稉鈧崣銉⑩偓婊嗙箹閺勵垰鐨拠绮光偓?閳ユ粏绻栭弰顖氬⒔閺堫兘鈧縿鈧?',
        });
        return;
      }

      const mode = detectWorkflowAgentMode(raw);
      const route = resolveWorkflowRoute(inputType, mode);
      const intro = buildWorkflowAgentStartMessage({ inputType, route, mode });
      const session: WorkflowAgentSession = {
        id: uid('agent'),
        inputType,
        mode,
        route,
        state: 'INIT',
        sourceText: raw,
        lastUserMessage: raw,
        lastAssistantMessage: intro,
        createdAt: now,
        updatedAt: now,
      };

      if (route === 'novel_to_script_to_storyboard_to_prompt') {
        const writingNodeId = get().startWritingPipeline(raw, flowPos);
        session.writingNodeId = writingNodeId;
      } else if (route === 'script_to_storyboard_to_prompt') {
        const storyboardNodeId = get().addDepartmentNode('storyboard', flowPos);
        get().patchNodeData(storyboardNodeId, { input: raw }, false);
        get().focusNode(storyboardNodeId, { openDetail: true });
        void get().executeNodeTask(storyboardNodeId);
        session.storyboardNodeId = storyboardNodeId;
      } else {
        const promptNodeId = get().startPromptPipeline(raw, flowPos);
        session.promptNodeId = promptNodeId;
      }

      set({ workflowAgentSession: session });
      get().pushMessage({
        role: 'assistant',
        text: `${intro}\n\n${buildWorkflowAgentStageHint(session)}`,
      });
      return;
    }

    const updateSession = (patch: Partial<WorkflowAgentSession>) => {
      set((state) => {
        if (!state.workflowAgentSession || state.workflowAgentSession.id !== currentSession.id) {
          return state;
        }
        return {
          workflowAgentSession: {
            ...state.workflowAgentSession,
            ...patch,
            updatedAt: Date.now(),
          },
        };
      });
    };

    if (intent === 'continue') {
      if (
        currentSession.route === 'novel_to_script_to_storyboard_to_prompt' &&
        currentSession.state === 'SCRIPT_READY'
      ) {
        const writingNode = currentSession.writingNodeId
          ? get().nodes.find((node) => node.id === currentSession.writingNodeId)
          : null;
        const writingInput =
          writingNode?.type === 'department' && writingNode.data.output
            ? JSON.stringify(writingNode.data.output, null, 2)
            : currentSession.sourceText;
        const storyboardNodeId = get().addDepartmentNode('storyboard', {
          x: flowPos.x + 180,
          y: flowPos.y + 60,
        });
        get().patchNodeData(storyboardNodeId, { input: writingInput }, false);
        get().focusNode(storyboardNodeId, { openDetail: true });
        void get().executeNodeTask(storyboardNodeId);
        updateSession({
          storyboardNodeId,
          lastUserMessage: raw,
          lastAssistantMessage: '瀹歌弓绮犻崜褎婀伴梼鑸殿唽閸掑洤鍩岄崚鍡涙殔闂冭埖顔岄敍灞绢劀閸︺劎鏁撻幋鎰瀻闂€婧库偓?',
        });
        get().pushMessage({
          role: 'assistant',
          text: '瀹歌弓绮犻崜褎婀伴梼鑸殿唽閸掑洤鍩岄崚鍡涙殔闂冭埖顔岄敍灞绢劀閸︺劎鏁撻幋鎰瀻闂€婧库偓鍌滄晸閹存劕鐣幋鎰倵閿涘本鍨滄导姘Ω瑜版挸澧犲ù浣衡柤閻樿埖鈧焦娲块弬棰佽礋閵嗗苯鍨庨梹婊冨嚒閻㈢喐鍨氶妴宥冣偓?',
          nodeId: storyboardNodeId,
        });
        return;
      }

      if (
        currentSession.promptNodeId &&
        (currentSession.state === 'STORYBOARD_CONFIRMED' ||
          currentSession.state === 'PROMPT_GENERATED')
      ) {
        get().focusNode(currentSession.promptNodeId, { openDetail: true });
        updateSession({
          lastUserMessage: raw,
          lastAssistantMessage: '瀹歌弓璐熸担鐘茬暰娴ｅ秴鍩岃ぐ鎾冲 Prompt 閼哄倻鍋ｉ敍灞肩稑閸欘垯浜掔紒褏鐢荤€癸紕婀呴妴浣镐簳鐠嬪喛绱濋幋鏍纯閹恒儳绮ㄩ弶鐔荤箹娑撯偓鏉烆喗绁︾粙瀣ㄢ偓?',
        });
        get().pushMessage({
          role: 'assistant',
          text: '瀹歌弓璐熸担鐘茬暰娴ｅ秴鍩岃ぐ鎾冲 Prompt 閼哄倻鍋ｉ妴鍌欑稑閸欘垯浜掔紒褏鐢诲顔跨殶閹绘劗銇氱拠宥忕礉閹存牞鈧懎鎲＄拠澶嬪灉閳ユ粌鐣幋鎰ㄢ偓婵堢波閺夌喕绻栨稉鈧潪顔界ウ缁嬪鈧?',
          nodeId: currentSession.promptNodeId,
        });
        return;
      }

      if (
        (currentSession.state === 'STORYBOARD_CONFIRMED' ||
          currentSession.state === 'STORYBOARD_GENERATED' ||
          currentSession.state === 'STORYBOARD_ADJUSTED') &&
        currentSession.route !== 'novel_to_script_to_storyboard_to_prompt' &&
        currentSession.route !== 'script_to_storyboard_to_prompt'
      ) {
        // no-op: quick route handled at start
      }
    }

    if (intent === 'adjust_storyboard') {
      const targetId = currentSession.shotListNodeId ?? currentSession.storyboardNodeId ?? null;
      if (!targetId) {
        get().pushMessage({
          role: 'assistant',
          text: '瑜版挸澧犲ù浣衡柤闁插矁绻曞▽鈩冩箒閸欘垵鐨熼弫瀵告畱閸掑棝鏆呴懞鍌滃仯閵嗗倸鍘涚拋鈺傚灉閹跺﹤鍨庨梹婊呮晸閹存劕鍤弶銉礉閹存垳婊戦崘宥堢箻閸忋儴鐨熼弫鎾▉濞堢偣鈧?',
        });
        return;
      }
      get().focusNode(targetId, { openDetail: true });
      updateSession({
        state:
          currentSession.state === 'STORYBOARD_GENERATED' ? 'STORYBOARD_ADJUSTED' : currentSession.state,
        lastUserMessage: raw,
        lastAssistantMessage: '閹存垵鍑＄紒蹇撳簻娴ｇ姴鐣炬担宥呭煂瑜版挸澧犻崚鍡涙殔閼哄倻鍋ｉ妴鍌欑稑閻滄澘婀崣顖欎簰缂佈呯敾闁鑵戠€瑰喛绱濋柅姘崇箖閼哄倻鍋ｉ懕濠傘亯缁彞鎱ㄩ崚鍡涙殔閵?',
      });
      get().pushMessage({
        role: 'assistant',
        text: '閹存垵鍑＄紒蹇撳簻娴ｇ姴鐣炬担宥呭煂瑜版挸澧犻崚鍡涙殔閼哄倻鍋ｉ妴鍌欑稑閻滄澘婀崣顖欎簰缂佈呯敾闁鑵戠€瑰喛绱濋柅姘崇箖閼哄倻鍋ｉ懕濠傘亯缁彞鎱ㄩ崚鍡涙殔閿涙稒鏁肩€瑰苯鎮楅崘宥呮啞鐠囧鍨滈垾婊呪€樼拋銈呭瀻闂€婧锯偓婵嗗祮閸欘垵绻橀崗銉﹀絹缁€楦跨槤闂冭埖顔岄妴?',
        nodeId: targetId,
      });
      return;
    }

    if (intent === 'confirm_storyboard') {
      const storyboardCarrierId = currentSession.shotListNodeId ?? currentSession.storyboardNodeId ?? null;
      const storyboardCarrier = storyboardCarrierId
        ? get().nodes.find((node) => node.id === storyboardCarrierId)
        : null;
      const storyboardPayload =
        storyboardCarrier?.data.output != null
          ? JSON.stringify(storyboardCarrier.data.output, null, 2)
          : '';
      if (!storyboardPayload) {
        get().pushMessage({
          role: 'assistant',
          text: '閹存垼绻曞▽鈩冨瑏閸掓澘褰茬涵顔款吇閻ㄥ嫬鍨庨梹婊呯波閺嬫嚎鈧倻鐡戦崚鍡涙殔閼哄倻鍋ｉ崗鍫ｇ獓鐎瑰矉绱濋幋鏍偓鍛€樼拋銈勭稑閻滄澘婀柅澶夎厬閻ㄥ嫬姘ㄩ弰顖炴殔婢剁銆冮懞鍌滃仯閵?',
        });
        return;
      }
      const promptNodeId = get().startPromptPipeline(storyboardPayload, {
        x: flowPos.x + 220,
        y: flowPos.y + 80,
      });
      updateSession({
        state: 'STORYBOARD_CONFIRMED',
        promptNodeId,
        lastUserMessage: raw,
        lastAssistantMessage: '閸掑棝鏆呭鑼€樼拋銈忕礉濮濓絽婀潻娑樺弳閹绘劗銇氱拠宥夋▉濞堢偣鈧?',
      });
      get().pushMessage({
        role: 'assistant',
        text: '閸掑棝鏆呭鑼€樼拋銈忕礉濮濓絽婀潻娑樺弳閹绘劗銇氱拠宥夋▉濞堢偣鈧倹鍨滃鑼病閹跺﹤缍嬮崜宥呭瀻闂€婊呯波閺嬫粈姘︾紒?Prompt 閼哄倻鍋ｆ径鍕倞閵?',
        nodeId: promptNodeId,
      });
      return;
    }

    if (intent === 'complete') {
      updateSession({
        state: 'COMPLETED',
        lastUserMessage: raw,
        lastAssistantMessage: '鏉╂瑤绔存潪?Agent 濞翠胶鈻煎鍙夌垼鐠佹澘鐣幋鎰┾偓?',
      });
      get().pushMessage({
        role: 'assistant',
        text: '鏉╂瑤绔存潪?Agent 濞翠胶鈻煎鍙夌垼鐠佹澘鐣幋鎰┾偓鍌欑稑閸欘垯浜掔紒褏鐢诲顔跨殶閻滅増婀侀懞鍌滃仯閿涘本鍨ㄩ懓鍛纯閹恒儱褰傞弬鎵畱閺佸懍绨ㄩ弬鍥ㄦ拱瀵偓閸氼垯绗呮稉鈧潪顔衡偓?',
      });
      return;
    }

    get().pushMessage({
      role: 'assistant',
      text: `瑜版挸澧犲ù浣衡柤閿?{routeLabel(currentSession.route)}\n瑜版挸澧犻梼鑸殿唽閿?{stageLabel(currentSession.state)}\n\n${buildWorkflowAgentStageHint(currentSession)}`,
    });
  },

  submitAssistantChat: async (text) => {
    const raw = text.trim();
    if (!raw) return;

    const selectedId = get().selectedNodeId ?? get().activeNodeId;
    if (!selectedId) {
      get().pushMessage({
        role: 'system',
        text: '鐠囧嘲鍘涢柅澶夎厬娑撯偓娑擃亣濡悙鐧哥礉閸愬秹鈧俺绻冮懕濠傘亯鐠佲晛濮幍瀣╂叏閺€鐟扮秼閸撳秳鎹㈤崝鈩冨灗瑜版挸澧犵紒鎾寸亯閵?',
      });
      return;
    }

    const selectedNode = get().nodes.find((n) => n.id === selectedId);
    if (!selectedNode) {
      get().pushMessage({ role: 'system', text: '瑜版挸澧犻柅澶夎厬閻ㄥ嫯濡悙閫涚瑝鐎涙ê婀妴?' });
      return;
    }

    if (
      selectedNode.type !== 'department' &&
      selectedNode.type !== 'shotList' &&
      selectedNode.type !== 'textNode'
    ) {
      get().pushMessage({
        role: 'system',
        text: '瑜版挸澧犻懞鍌滃仯閺嗗倷绗夐弨顖涘瘮閺呴缚鍏橀崝鈺傚缂傛牞绶妴?',
        nodeId: selectedId,
      });
      return;
    }

    const instructionNode =
      selectedNode.type === 'shotList' && selectedNode.data.sourceStoryboardNodeId
        ? get().nodes.find((n) => n.id === selectedNode.data.sourceStoryboardNodeId) ?? selectedNode
        : selectedNode;

    const outputNode =
      selectedNode.type === 'department' && selectedNode.data.type === 'storyboard'
        ? (findStoryboardShotListChild(get().nodes, get().edges, selectedNode.id) ?? selectedNode)
        : selectedNode;

    const contextData: StudioNodeData = {
      ...selectedNode.data,
      assistant_preferences: instructionNode.data.assistant_preferences ?? '',
      assistant_task_instruction: instructionNode.data.assistant_task_instruction ?? '',
    };

    const currentOutput =
      outputNode.type === 'department' && outputNode.data.type === 'writing'
        ? ((outputNode.data.output as WritingOutput | null) ?? null)
        : outputNode.type === 'department' && outputNode.data.type === 'prompt'
          ? ((outputNode.data.output as PromptOutput | null) ?? null)
          : outputNode.data.output
            ? (tryParseStoryboardOutput(outputNode.data.output) ?? null)
            : null;

    get().pushMessage({ role: 'user', text: raw, nodeId: selectedId });
    get().pushMessage({
      role: 'assistant',
      text: currentOutput
        ? '已收到修改要求，正在调用模型直接调整当前节点结果...'
        : '已收到要求，正在调用模型分析并执行...',
      nodeId: selectedId,
    });

    try {
      const result = await runNodeAssistant({
        data: contextData,
        history: getNodeAssistantHistory(get().messages, selectedId),
        userMessage: raw,
        currentOutput,
      });

      let changed = false;

      if (result.action === 'update_task' && result.applyChange) {
        get().patchNodeData(
          instructionNode.id,
          { assistant_task_instruction: result.taskInstruction },
          false,
        );
        changed = true;
      }

      if (result.action === 'update_preferences' && result.applyChange) {
        get().patchNodeData(
          instructionNode.id,
          { assistant_preferences: result.assistantPreferences },
          false,
        );
        changed = true;
      }

      if (result.targetKind === 'text' && result.action === 'revise_output' && result.applyChange) {
        get().patchNodeData(
          outputNode.id,
          {
            raw_text: result.updatedText,
            input: result.updatedText,
            assistant_preferences: result.assistantPreferences,
            assistant_task_instruction: result.taskInstruction,
          },
          true,
        );
        changed = true;
      }

      if (
        result.targetKind === 'writing' &&
        result.action === 'revise_output' &&
        result.applyChange &&
        result.updatedOutput
      ) {
        get().patchNodeData(
          outputNode.id,
          {
            output: result.updatedOutput,
            assistant_preferences: result.assistantPreferences,
            assistant_task_instruction: result.taskInstruction,
          },
          true,
        );
        changed = true;
      }

      if (
        result.targetKind === 'prompt' &&
        result.action === 'revise_output' &&
        result.applyChange &&
        result.updatedOutput
      ) {
        get().patchNodeData(
          outputNode.id,
          {
            output: result.updatedOutput,
            assistant_preferences: result.assistantPreferences,
            assistant_task_instruction: result.taskInstruction,
          },
          true,
        );
        changed = true;
      }

      if (
        result.targetKind === 'storyboard' &&
        result.action === 'revise_output' &&
        result.applyChange &&
        result.updatedOutput
      ) {
        if (outputNode.type === 'shotList') {
          get().patchShotListNodeOutput(outputNode.id, result.updatedOutput as StoryboardOutput, true);
          get().patchNodeData(
            instructionNode.id,
            {
              assistant_preferences: result.assistantPreferences,
              assistant_task_instruction: result.taskInstruction,
            },
            false,
          );
        } else {
          get().patchNodeData(
            outputNode.id,
            {
              output: result.updatedOutput,
              assistant_preferences: result.assistantPreferences,
              assistant_task_instruction: result.taskInstruction,
            },
            true,
          );
        }
        changed = true;
      }

      if (
        result.action !== 'revise_output' &&
        (result.taskInstruction !== (instructionNode.data.assistant_task_instruction ?? '') ||
          result.assistantPreferences !== (instructionNode.data.assistant_preferences ?? ''))
      ) {
        get().patchNodeData(
          instructionNode.id,
          {
            assistant_task_instruction: result.taskInstruction,
            assistant_preferences: result.assistantPreferences,
          },
          false,
        );
      }

      const workflowSession = get().workflowAgentSession;
      if (workflowSession && changed) {
        const relevantIds = new Set(
          [
            workflowSession.writingNodeId,
            workflowSession.storyboardNodeId,
            workflowSession.shotListNodeId,
            workflowSession.promptNodeId,
            instructionNode.id,
            outputNode.id,
            selectedId,
          ].filter((value): value is string => Boolean(value)),
        );
        if (
          result.targetKind === 'storyboard' &&
          relevantIds.has(selectedId) &&
          (workflowSession.state === 'STORYBOARD_GENERATED' ||
            workflowSession.state === 'STORYBOARD_ADJUSTED')
        ) {
          set((state) =>
            state.workflowAgentSession?.id === workflowSession.id
              ? {
                  workflowAgentSession: {
                    ...state.workflowAgentSession,
                    state: 'STORYBOARD_ADJUSTED',
                    lastAssistantMessage: '已根据你的反馈调整当前分镜结果。',
                    updatedAt: Date.now(),
                  },
                }
              : state,
          );
        }
        if (result.targetKind === 'prompt' && relevantIds.has(selectedId)) {
          set((state) =>
            state.workflowAgentSession?.id === workflowSession.id
              ? {
                  workflowAgentSession: {
                    ...state.workflowAgentSession,
                    state: 'PROMPT_GENERATED',
                    lastAssistantMessage: '已根据你的反馈调整当前提示词结果。',
                    updatedAt: Date.now(),
                  },
                }
              : state,
          );
        }
      }

      const suffix =
        result.action === 'update_task' && result.applyChange
          ? '\n\n我已经记住这条节点要求，后续再次执行这个节点时会自动带上。'
          : result.action === 'update_preferences' && result.applyChange
            ? '\n\n我已经记住这条长期偏好，后面会持续按这个方向帮你调整。'
            : changed
              ? '\n\n我已经把修改直接写回当前选中的节点结果。'
              : '\n\n这次我理解了你的反馈，但模型没有返回可落库的新结果。你可以更明确地说“直接修改当前提示词”，我会继续执行。';

      get().pushMessage({
        role: 'assistant',
        text: `${result.assistantReply}${suffix}`.trim(),
        nodeId: selectedId,
      });
    } catch (e) {
      const errMsg =
        e instanceof Error && e.message.trim()
          ? e.message.trim()
          : '节点助手执行失败，请稍后重试。';
      get().pushMessage({
        role: 'system',
        text: errMsg,
        nodeId: selectedId,
      });
    }
  },

  registerAsset: (a) => {
    const createdAt = a.createdAt ?? Date.now();
    const snapshot: ApprovedAsset = {
      ...a,
      createdAt,
      snapshotId: a.snapshotId ?? `snapshot_${a.nodeId}_${createdAt}`,
    };
    set((s) => ({ assets: [...s.assets, snapshot] }));
  },

  patchNodeData: (id, patch, bumpVersion = false) => {
    const targetPre = get().nodes.find((n) => n.id === id);
    let patchEff: Partial<StudioNodeData> = patch;
    if (targetPre?.type === 'textNode') {
      if (patch.raw_text !== undefined && patch.input === undefined) {
        patchEff = { ...patch, input: patch.raw_text };
      } else if (patch.input !== undefined && patch.raw_text === undefined) {
        patchEff = { ...patch, raw_text: patch.input };
      }
    }
    if (
      targetPre?.type === 'department' &&
      patchEff.mounted_skills !== undefined &&
      (targetPre.data.type === 'writing' ||
        targetPre.data.type === 'storyboard' ||
        targetPre.data.type === 'prompt')
    ) {
      patchEff = {
        ...patchEff,
        mounted_skills: normalizeMountedSkillIdsForKind(targetPre.data.type, patchEff.mounted_skills),
      };
    }

    if (targetPre && !patchChangesNodeData(targetPre.data, patchEff, bumpVersion)) {
      return;
    }

    set((s) => {
      const target = s.nodes.find((n) => n.id === id);
      if (!target) return s;
      if (
        patchEff.status !== undefined &&
        target.data.type !== 'text_node' &&
        target.data.type !== 'shot_list_node' &&
        target.data.type !== 'storyboard_file_node'
      ) {
        if (!canTransitionPipelineStatus(target.data.status, patchEff.status)) {
          return s;
        }
      }
      if (!patchChangesNodeData(target.data, patchEff, bumpVersion)) {
        return s;
      }
      return {
        nodes: s.nodes.map((n) => {
          if (n.id !== id) return n;
          const nextVersion = bumpVersion ? n.data.version + 1 : n.data.version;
          const nextData: StudioNodeData = { ...n.data, ...patchEff, version: nextVersion };
          if (bumpVersion) {
            nextData.lastUpdatedAt = Date.now();
          }
          return { ...n, data: nextData };
        }),
      };
    });

    const updated = get().nodes.find((n) => n.id === id);
    if (updated?.type === 'textNode') {
      const { nodes, edges } = get();
      const targets = [...new Set(edges.filter((e) => e.source === id).map((e) => e.target))];
      for (const tid of targets) {
        const t = nodes.find((n) => n.id === tid);
        if (t?.type === 'department' && shouldPreferManualInput(t.data)) continue;
        const merged = mergedTextInputForDepartment(tid, nodes, edges);
        if (merged !== null) {
          get().patchNodeData(tid, { input: merged, inputSource: 'graph' }, false);
        }
      }
    }
    // 娴犲懎缍?output 閸欐ê瀵查弮璺哄煕閺?Output 鏉╃偟鍤庢稉瀣畱閸氬牆鑻熸潏鎾冲弳閿涙稓鍑?input 閺囧瓨鏌婇懟銉ょ瘍閸掗攱鏌婃导姘遍獓閼?patchNodeTask閳壊eact 閹?Maximum update depth
    const outputTouched = 'output' in patchEff;
    if ((updated?.type === 'department' || updated?.type === 'storyboardFile') && outputTouched) {
      refreshDownstreamAfterDepartmentOutputChange(get, id);
    }

    if (
      updated?.type === 'department' &&
      updated.data.type === 'storyboard' &&
      patchEff.output !== undefined &&
      updated.data.status !== 'IN_PROGRESS'
    ) {
      get().syncShotListNodesFromStoryboard(id);
    }
    if (updated?.type === 'storyboardFile' && patchEff.output !== undefined) {
      get().ensureShotListForStoryboardFile(id);
    }
  },

  syncShotListNodesFromStoryboard: (storyboardId) => {
    const sb = get().nodes.find((n) => n.id === storyboardId);
    if (!sb || sb.type !== 'department' || sb.data.type !== 'storyboard') return;
    if (sb.data.status === 'IN_PROGRESS') return;
    const out = sb.data.output;
    const parsed = out ? tryParseStoryboardOutput(out) : null;
    if (!parsed?.shots?.length) return;
    const snap = sb.data.storyboard_ai_snapshot
      ? cloneStoryboardOutput(sb.data.storyboard_ai_snapshot)
      : cloneStoryboardOutput(parsed);
    const childIds = get()
      .edges.filter(
        (e) => e.source === storyboardId && e.sourceHandle === SHOT_LIST_LINK_HANDLE_ID,
      )
      .map((e) => e.target);
    if (childIds.length === 0) return;
    const parsedKey = storyboardOutputFingerprint(parsed);
    const hasAnyDiff = get().nodes.some((n) => {
      if (!childIds.includes(n.id) || n.type !== 'shotList') return false;
      const childParsed = n.data.output ? tryParseStoryboardOutput(n.data.output) : null;
      return storyboardOutputFingerprint(childParsed) !== parsedKey;
    });
    if (!hasAnyDiff) return;
    set((s) => ({
      nodes: s.nodes.map((n) => {
        if (!childIds.includes(n.id) || n.type !== 'shotList') return n;
        return {
          ...n,
          data: {
            ...n.data,
            output: cloneStoryboardOutput(parsed),
            storyboard_ai_snapshot: snap,
            sourceStoryboardFileNodeId: undefined,
            sourceSceneCount: sb.data.sourceSceneCount,
          },
        };
      }),
    }));
  },

  ensureShotListForStoryboard: (storyboardNodeId) => {
    const sb = get().nodes.find((n) => n.id === storyboardNodeId);
    if (!sb || sb.type !== 'department' || sb.data.type !== 'storyboard') return;
    if (sb.data.status === 'IN_PROGRESS') return;
    const out = sb.data.output;
    const parsed = out ? tryParseStoryboardOutput(out) : null;
    if (!parsed?.shots?.length) return;

    const existing = get().edges.find(
      (e) =>
        e.source === storyboardNodeId && e.sourceHandle === SHOT_LIST_LINK_HANDLE_ID,
    );
    if (existing) {
      get().syncShotListNodesFromStoryboard(storyboardNodeId);
      return;
    }

    const slId = uid('shotlist');
    const snap = sb.data.storyboard_ai_snapshot
      ? cloneStoryboardOutput(sb.data.storyboard_ai_snapshot)
      : cloneStoryboardOutput(parsed);
    const data = makeShotListNodeData(
      slId,
      cloneStoryboardOutput(parsed),
      snap,
      {
        sourceStoryboardNodeId: storyboardNodeId,
        sourceSceneCount: typeof sb.data.sourceSceneCount === 'number' ? sb.data.sourceSceneCount : undefined,
      },
    );
    const pos = { x: sb.position.x, y: sb.position.y + 200 };
    set((s) => ({
      nodes: [
        ...s.nodes,
        {
          id: slId,
          type: 'shotList',
          position: pos,
          selected: false,
          data,
        },
      ],
      edges: addEdge(
        {
          source: storyboardNodeId,
          target: slId,
          sourceHandle: SHOT_LIST_LINK_HANDLE_ID,
          targetHandle: SHOT_LIST_PARENT_HANDLE_ID,
          animated: true,
          style: { strokeDasharray: '6 4' },
        },
        s.edges,
      ),
    }));
    get().pushMessage({
      role: 'broadcast',
      text: '瀹告彃婀崚鍡涙殔閼哄倻鍋ｆ稉瀣殰閸斻劌鍨卞鎭掆偓宀勬殔婢剁銆冮妴宥呯摍閼哄倻鍋ｉ敍娑溿€冮弽鑹邦嚞閸︺劌鐡欓懞鍌滃仯鐠囷附鍎忔稉顓犵椽鏉堟垯鈧?',
      nodeId: slId,
    });
  },

  syncShotListNodesFromStoryboardFile: (storyboardFileId) => {
    const fileNode = get().nodes.find((n) => n.id === storyboardFileId);
    if (!fileNode || fileNode.type !== 'storyboardFile') return;
    const parsed = fileNode.data.output ? tryParseStoryboardOutput(fileNode.data.output) : null;
    if (!parsed?.shots?.length) return;
    const childIds = get()
      .edges.filter(
        (e) => e.source === storyboardFileId && e.sourceHandle === SHOT_LIST_LINK_HANDLE_ID,
      )
      .map((e) => e.target);
    if (childIds.length === 0) return;
    const parsedKey = storyboardOutputFingerprint(parsed);
    const hasAnyDiff = get().nodes.some((n) => {
      if (!childIds.includes(n.id) || n.type !== 'shotList') return false;
      const childParsed = n.data.output ? tryParseStoryboardOutput(n.data.output) : null;
      return storyboardOutputFingerprint(childParsed) !== parsedKey;
    });
    if (!hasAnyDiff) return;
    const snap = cloneStoryboardOutput(parsed);
    set((s) => ({
      nodes: s.nodes.map((n) => {
        if (!childIds.includes(n.id) || n.type !== 'shotList') return n;
        return {
          ...n,
          data: {
            ...n.data,
            output: cloneStoryboardOutput(parsed),
            storyboard_ai_snapshot: snap,
            sourceStoryboardNodeId: undefined,
            sourceStoryboardFileNodeId: storyboardFileId,
            sourceSceneCount: undefined,
          },
        };
      }),
    }));
  },

  ensureShotListForStoryboardFile: (storyboardFileId) => {
    const fileNode = get().nodes.find((n) => n.id === storyboardFileId);
    if (!fileNode || fileNode.type !== 'storyboardFile') return;
    const parsed = fileNode.data.output ? tryParseStoryboardOutput(fileNode.data.output) : null;
    if (!parsed?.shots?.length) return;

    const existing = get().edges.find(
      (e) => e.source === storyboardFileId && e.sourceHandle === SHOT_LIST_LINK_HANDLE_ID,
    );
    if (existing) {
      get().syncShotListNodesFromStoryboardFile(storyboardFileId);
      return;
    }

    const slId = uid('shotlist');
    const data = makeShotListNodeData(
      slId,
      cloneStoryboardOutput(parsed),
      cloneStoryboardOutput(parsed),
      { sourceStoryboardFileNodeId: storyboardFileId },
    );
    const pos = { x: fileNode.position.x, y: fileNode.position.y + 200 };
    set((s) => ({
      nodes: [
        ...s.nodes,
        {
          id: slId,
          type: 'shotList',
          position: pos,
          selected: false,
          data,
        },
      ],
      edges: addEdge(
        {
          source: storyboardFileId,
          target: slId,
          sourceHandle: SHOT_LIST_LINK_HANDLE_ID,
          targetHandle: SHOT_LIST_PARENT_HANDLE_ID,
          animated: true,
          style: { strokeDasharray: '6 4' },
        },
        s.edges,
      ),
    }));
    get().pushMessage({
      role: 'broadcast',
      text: '已根据导入的分镜文件自动生成分镜表节点，可以继续编辑后再连接 Prompt。',
      nodeId: slId,
    });
  },

  patchShotListNodeOutput: (shotListId, output, bumpVersion = true) => {
    if (bumpVersion) {
      pushUndoSnapshot(set);
    }
    const sl = get().nodes.find((n) => n.id === shotListId);
    if (!sl || sl.type !== 'shotList' || sl.data.type !== 'shot_list_node') return;
    const storyboardParentId = sl.data.sourceStoryboardNodeId;
    const storyboardFileParentId = sl.data.sourceStoryboardFileNodeId;
    if (!storyboardParentId && !storyboardFileParentId) return;
    const now = Date.now();
    set((s) => ({
      nodes: s.nodes.map((n) => {
        if (n.id === shotListId) {
          const v = bumpVersion ? n.data.version + 1 : n.data.version;
          return {
            ...n,
            data: {
              ...n.data,
              output,
              version: v,
              ...(bumpVersion ? { lastUpdatedAt: now } : {}),
            },
          };
        }
        if (storyboardParentId && n.id === storyboardParentId && n.type === 'department') {
          const v = bumpVersion ? n.data.version + 1 : n.data.version;
          return {
            ...n,
            data: {
              ...n.data,
              output,
              version: v,
              ...(bumpVersion ? { lastUpdatedAt: now } : {}),
            },
          };
        }
        if (storyboardFileParentId && n.id === storyboardFileParentId && n.type === 'storyboardFile') {
          const v = bumpVersion ? n.data.version + 1 : n.data.version;
          return {
            ...n,
            data: {
              ...n.data,
              output,
              version: v,
              ...(bumpVersion ? { lastUpdatedAt: now } : {}),
            },
          };
        }
        return n;
      }),
    }));
    if (storyboardParentId) {
      refreshDownstreamAfterDepartmentOutputChange(get, storyboardParentId);
    }
    if (storyboardFileParentId) {
      refreshDownstreamAfterDepartmentOutputChange(get, storyboardFileParentId);
    }
    // 閻㈣绔?鐠囷附鍎忛幍瀣暭闂€婊冦仈鐞涖劌鎮楅敍宀勩€忕拋鈺勭箾閸︺劑鏆呮径纾嬨€?Output 娑撳﹦娈?Prompt 婵绮撻崥鍐ㄥ煂閺堚偓閺?JSON閿涘牅绗夐崶鐘绘桨閺夎￥鈧本澧滈崝銊ㄧ翻閸忋儯鈧秷鈧苯宕辨担蹇ョ礆
    refreshDownstreamAfterDepartmentOutputChange(get, shotListId, { ignoreManualInput: true });
  },

  setStatus: (id, next) => {
    const n = get().nodes.find((x) => x.id === id);
    if (!n) return false;
    if (!canTransitionPipelineStatus(n.data.status, next)) return false;
    get().patchNodeData(id, { status: next }, true);
    get().pushMessage({
      role: 'broadcast',
      text: `閼哄倻鍋?${n.data.label} 閳?${next}`,
      nodeId: id,
    });
    return true;
  },

  addDepartmentNode: (kind, position) => {
    pushUndoSnapshot(set);
    const id = uid('node');
    const pos = position ?? { x: 280, y: 220 };
    const data = makeNodeData(id, kind);
    set((s) => ({
      nodes: [
        ...s.nodes,
        {
          id,
          type: 'department',
          position: pos,
          selected: false,
          data,
        },
      ],
    }));
    get().pushMessage({
      role: 'system',
      text: `已停止 ${deptLabel(kindToDepartment(kind))} 的当前任务。`,
      nodeId: id,
    });
    return id;
  },

  addTextNode: (text = '', position) => {
    pushUndoSnapshot(set);
    const id = uid('text');
    const pos = position ?? { x: 320, y: 240 };
    const data = makeTextNodeData(id, text);
    set((s) => ({
      nodes: [
        ...s.nodes,
        {
          id,
          type: 'textNode',
          position: pos,
          selected: false,
          data,
        },
      ],
    }));
    get().pushMessage({
      role: 'system',
      text: '瀹告彃鍨卞鐑樻瀮閺堫剙宕遍悧鍥风窗閹跺﹤褰告笟褍娓鹃悙纭呯箾閸掍即鍎撮梻銊ㄥΝ閻愮懓涔忔笟褝绱濋崘鍛啇娴兼俺鍤滈崝銊ユ倱濮濄儰璐熼柈銊╂，鏉堟挸鍙嗛妴?',
      nodeId: id,
    });
    return id;
  },

  addStoryboardFileNode: (position) => {
    pushUndoSnapshot(set);
    const id = uid('storyfile');
    const pos = position ?? { x: 320, y: 240 };
    const data = makeStoryboardFileNodeData(id);
    set((s) => ({
      nodes: [
        ...s.nodes,
        {
          id,
          type: 'storyboardFile',
          position: pos,
          selected: false,
          data,
        },
      ],
    }));
    get().pushMessage({
      role: 'system',
      text: '瀹告彃鍨卞鍝勫瀻闂€婊嗐€冮弬鍥︽閼哄倻鍋ｉ敍姘嚤閸忋儳骞囬張?Excel 闂€婊冦仈鐞涖劌鎮楅敍灞藉讲閻╁瓨甯存潻鐐插煂 Prompt 閼哄倻鍋ｉ悽鐔稿灇閹绘劗銇氱拠宥冣偓?',
      nodeId: id,
    });
    return id;
  },

  createTextNodeLinkedToDepartment: (deptId, position) => {
    pushUndoSnapshot(set);
    const id = uid('text');
    const data = makeTextNodeData(id, '');
    set((s) => ({
      nodes: [
        ...s.nodes,
        {
          id,
          type: 'textNode',
          position,
          selected: false,
          data,
        },
      ],
      edges: addEdge(
        {
          source: id,
          target: deptId,
          sourceHandle: 'out',
          targetHandle: 'in',
          animated: true,
        },
        s.edges,
      ),
    }));
    const { nodes, edges } = get();
    const deptNode = nodes.find((n) => n.id === deptId);
    if (!shouldPreferManualInput(deptNode?.data)) {
      const merged = mergedTextInputForDepartment(deptId, nodes, edges);
      if (merged !== null) {
        get().patchNodeData(deptId, { input: merged, inputSource: 'graph' }, false);
      }
    }
    get().pushMessage({
      role: 'system',
      text: '瀹告彃鍨卞鐑樻瀮閺堫剙宕遍悧鍥风礉楠炶泛鍑￠幒銉ュ弳闁劑妫潏鎾冲弳缁旑垰褰涢妴?',
      nodeId: id,
    });
    return id;
  },

  completeConnectionMenuPick: (p) => {
    const from = get().nodes.find((n) => n.id === p.fromNodeId);
    if (!from) return undefined;

    const hid = p.fromHandleId ?? '';
    const ht = p.fromHandleType;
    const fp = p.flowPosition;
    const upstreamPos = { x: fp.x - 300, y: fp.y - 70 };
    const downstreamPos = { x: fp.x + 56, y: fp.y - 70 };

    const pushErr = (text: string) => {
      get().pushMessage({ role: 'system', text, nodeId: p.fromNodeId });
      return undefined;
    };

    const syncDeptIn = (deptId: string) => {
      const { nodes, edges } = get();
      const dept = nodes.find((n) => n.id === deptId);
      if (shouldPreferManualInput(dept?.data)) return;
      const merged = mergedTextInputForDepartment(deptId, nodes, edges);
      if (merged !== null) {
        get().patchNodeData(deptId, { input: merged, inputSource: 'graph' }, false);
      }
    };

    const syncTextIn = (textId: string) => {
      const { nodes, edges } = get();
      const m = mergedUpstreamForTextNode(textId, nodes, edges);
      if (m !== null) {
        get().patchNodeData(textId, { raw_text: m, input: m }, false);
      }
    };

    const INPUT_PULL = 'input-pull';

    const feedingDept =
      from.type === 'department' &&
      ((hid === INPUT_PULL && ht === 'source') || (hid === 'in' && ht === 'target'));

    const feedingText = from.type === 'textNode' && hid === 'in' && ht === 'target';

    const fromDownstreamOut =
      ht === 'source' &&
      (hid === 'out' || (from.type === 'shotList' && isShotListItemOutputHandleId(hid)));

    if (feedingDept) {
      const dk = from.data.type as PipelineKind;
      if (p.pick === 'text_node') {
        const id = uid('text');
        const data = makeTextNodeData(id, '');
        set((s) => ({
          nodes: [
            ...s.nodes,
            {
              id,
              type: 'textNode',
              position: upstreamPos,
              selected: false,
              data,
            },
          ],
          edges: addEdge(
            {
              source: id,
              target: from.id,
              sourceHandle: 'out',
              targetHandle: 'in',
              animated: true,
            },
            s.edges,
          ),
        }));
        syncDeptIn(from.id);
        get().pushMessage({
          role: 'system',
          text: '瀹告彃鍨卞鐑樻瀮閺堫剙宕遍悧鍥风礉楠炶泛鍑￠幒銉ュ弳鐠囥儵鍎撮梻銊ㄧ翻閸忋儯鈧?',
          nodeId: id,
        });
        return id;
      }
      if (p.pick === 'storyboard_file_node') {
        if (dk !== 'prompt') {
          return pushErr('閸掑棝鏆呯悰銊︽瀮娴犳儼濡悙鍦窗閸撳秳绮庨弨顖涘瘮娴ｆ粈璐?Prompt 閼哄倻鍋ｉ惃鍕瑐濞撴瓕绶崗銉ｂ偓?');
        }
        const id = get().addStoryboardFileNode(upstreamPos);
        set((s) => ({
          edges: addEdge(
            {
              source: id,
              target: from.id,
              sourceHandle: DEPT_OUTPUT_HANDLE_ID,
              targetHandle: 'in',
              animated: true,
            },
            s.edges,
          ),
        }));
        syncDeptIn(from.id);
        return id;
      }
      const upKind = p.pick as PipelineKind;
      if (!canDeptChain(upKind, dk)) {
        return pushErr('鐠囥儵鍎撮梻銊ц閸ㄥ妫ゅ▔鏇氱稊娑撹桨绗傚〒鍛婂复閸忋儱缍嬮崜宥堝Ν閻愬湱娈?Input閵?');
      }
      const id = get().addDepartmentNode(upKind, upstreamPos);
      set((s) => ({
        edges: addEdge(
          {
            source: id,
            target: from.id,
            sourceHandle: DEPT_OUTPUT_HANDLE_ID,
            targetHandle: 'in',
            animated: true,
          },
          s.edges,
        ),
      }));
      syncDeptIn(from.id);
      return id;
    }

    if (feedingText) {
      if (p.pick === 'text_node') {
        const id = uid('text');
        const data = makeTextNodeData(id, '');
        set((s) => ({
          nodes: [
            ...s.nodes,
            {
              id,
              type: 'textNode',
              position: upstreamPos,
              selected: false,
              data,
            },
          ],
          edges: addEdge(
            {
              source: id,
              target: from.id,
              sourceHandle: 'out',
              targetHandle: 'in',
              animated: true,
            },
            s.edges,
          ),
        }));
        syncTextIn(from.id);
        get().pushMessage({ role: 'system', text: '瀹告彃鍨卞鐑樻瀮閺堫剙宕遍悧鍥风礉楠炶泛鍑￠幒銉ュ弳娑撳﹥鐖堕妴?', nodeId: id });
        return id;
      }
      if (p.pick === 'storyboard_file_node') {
        const id = get().addStoryboardFileNode(upstreamPos);
        set((s) => ({
          edges: addEdge(
            {
              source: id,
              target: from.id,
              sourceHandle: DEPT_OUTPUT_HANDLE_ID,
              targetHandle: 'in',
              animated: true,
            },
            s.edges,
          ),
        }));
        syncTextIn(from.id);
        return id;
      }
      const upKind = p.pick as PipelineKind;
      const id = get().addDepartmentNode(upKind, upstreamPos);
      set((s) => ({
        edges: addEdge(
          {
            source: id,
            target: from.id,
            sourceHandle: DEPT_OUTPUT_HANDLE_ID,
            targetHandle: 'in',
            animated: true,
          },
          s.edges,
        ),
      }));
      syncTextIn(from.id);
      return id;
    }

    if (fromDownstreamOut) {
      if (from.type === 'textNode') {
        if (p.pick === 'text_node') {
          const id = uid('text');
          const data = makeTextNodeData(id, '');
          set((s) => ({
            nodes: [
              ...s.nodes,
              {
                id,
                type: 'textNode',
                position: downstreamPos,
                selected: false,
                data,
              },
            ],
            edges: addEdge(
              {
                source: from.id,
                target: id,
                sourceHandle: 'out',
                targetHandle: 'in',
                animated: true,
              },
              s.edges,
            ),
          }));
          syncTextIn(id);
          get().pushMessage({ role: 'system', text: '瀹告彃鍨卞杞扮瑓濞撳憡鏋冮張顒€宕遍悧鍥风礉楠炶泛鍑￠懛顏勫З鏉╃偟鍤庨妴?', nodeId: id });
          return id;
        }
        if (p.pick === 'storyboard_file_node') {
          return pushErr('閸掑棝鏆呯悰銊︽瀮娴犳儼濡悙閫涚瑝閼虫垝缍旀稉鐑樻瀮閺堫剙宕遍悧鍥╂畱娑撳鐖堕懞鍌滃仯閸掓稑缂撻妴?');
        }
        const tk = p.pick as PipelineKind;
        const id = get().addDepartmentNode(tk, downstreamPos);
        set((s) => ({
          edges: addEdge(
            {
              source: from.id,
              target: id,
              sourceHandle: 'out',
              targetHandle: 'in',
              animated: true,
            },
            s.edges,
          ),
        }));
        syncDeptIn(id);
        return id;
      }

      if (from.type === 'shotList') {
        if (from.data.type !== 'shot_list_node') return pushErr('闂€婊冦仈鐞涖劏濡悙瑙勬殶閹诡喖绱撶敮鎼炩偓?');
        if (p.pick !== 'prompt') {
          return pushErr('闂€婊冦仈鐞涖劌褰告笟?Output 娴犲懏鏁幐浣稿灡瀵よ桨绗呭〒?Prompt 闁煉绱欑拠璇插絿瀹搞儰缍旈崣鏉跨暰缁嬪灝鎮楅惃鍕殔婢惰揪绱氶妴?');
        }
        const id = get().addDepartmentNode('prompt', downstreamPos);
        const sourceHandles = resolveShotListSourceHandlesForConnect(
          get().shotListSelectedWiresByNodeId,
          from.id,
          hid,
        );
        set((s) => ({
          edges: addUniqueAnimatedEdges(
            s.edges,
            sourceHandles.map((sourceHandle) => ({
              source: from.id,
              target: id,
              sourceHandle,
              targetHandle: 'in',
            })),
          ),
        }));
        syncDeptIn(id);
        get().pushMessage({
          role: 'broadcast',
          text:
            hid && hid !== DEPT_OUTPUT_HANDLE_ID
              ? '瀹告彃鍨卞?Prompt 闁煉绱濋獮鑸靛复閸忋儱缍嬮崜宥夋殔婢剁顢?Output閿涙稓鎴风紒顓熷Ω閺囨潙顦块梹婊冦仈鐞涘矁绻涢崚鏉挎倱娑撯偓娑?Prompt閿涘苯褰查悽鐔稿灇婢舵岸鏆呮径瀵哥矋閸氬牊褰佺粈楦跨槤閵?'
              : '瀹告彃鍨卞?Prompt 闁劌鑻熷鍙夊复閸忋儵鏆呮径纾嬨€冪€涙劘濡悙?Output閿涘牅绗岀悰銊︾壐閹靛鏁奸悧鍫熸拱娑撯偓閼疯揪绱氶妴?',
          nodeId: id,
        });
        return id;
      }

      if (from.type === 'storyboardFile') {
        if (p.pick !== 'prompt') {
          return pushErr('閸掑棝鏆呯悰銊︽瀮娴犳儼濡悙鐟板礁娓?Output 娴犲懏鏁幐浣稿灡瀵よ桨绗呭〒?Prompt 閼哄倻鍋ｉ妴?');
        }
        const id = get().addDepartmentNode('prompt', downstreamPos);
        set((s) => ({
          edges: addEdge(
            {
              source: from.id,
              target: id,
              sourceHandle: DEPT_OUTPUT_HANDLE_ID,
              targetHandle: 'in',
              animated: true,
            },
            s.edges,
          ),
        }));
        syncDeptIn(id);
        get().pushMessage({
          role: 'broadcast',
          text: '瀹告彃鍨卞?Prompt 閼哄倻鍋ｉ敍灞借嫙閹恒儱鍙嗙€电厧鍙嗛崥搴ｆ畱閸掑棝鏆呯悰銊︽瀮娴犺翰鈧?',
          nodeId: id,
        });
        return id;
      }

      if (from.type === 'department') {
        const fk = from.data.type as PipelineKind;
        if (p.pick === 'text_node') {
          const id = uid('text');
          const data = makeTextNodeData(id, '');
          set((s) => ({
            nodes: [
              ...s.nodes,
              {
                id,
                type: 'textNode',
                position: downstreamPos,
                selected: false,
                data,
              },
            ],
            edges: addEdge(
              {
                source: from.id,
                target: id,
                sourceHandle: DEPT_OUTPUT_HANDLE_ID,
                targetHandle: 'in',
                animated: true,
              },
              s.edges,
            ),
          }));
          syncTextIn(id);
          get().pushMessage({ role: 'system', text: '瀹告彃鍨卞鐑樻瀮閺堫剙宕遍悧鍥风礉楠炶泛鍑￠幒銉ュ弳闁劑妫潏鎾冲毉閵?', nodeId: id });
          return id;
        }
        if (p.pick === 'storyboard_file_node') {
          return pushErr('閸掑棝鏆呯悰銊︽瀮娴犳儼濡悙閫涚瑝閼虫垝缍旀稉娲劥闂傘劏濡悙鍦畱娑撳鐖堕懞鍌滃仯閸掓稑缂撻妴?');
        }
        const tk = p.pick as PipelineKind;
        if (!canDeptChain(fk, tk)) {
          return pushErr('瑜版挸澧犻柈銊╂， Output 閺冪姵纭堕幒銉ュ弳閹碘偓闁绗呭〒鎼佸劥闂傘劊鈧?');
        }
        const id = get().addDepartmentNode(tk, downstreamPos);
        set((s) => ({
          edges: addEdge(
            {
              source: from.id,
              target: id,
              sourceHandle: DEPT_OUTPUT_HANDLE_ID,
              targetHandle: 'in',
              animated: true,
            },
            s.edges,
          ),
        }));
        syncDeptIn(id);
        const upstreamMounted = Array.isArray(from.data.mounted_skills) ? from.data.mounted_skills : [];
        const chained = mergeDownstreamSkillsFromChain(upstreamMounted, fk, tk);
        if (chained.length > 0) {
          get().patchNodeData(id, { mounted_skills: chained }, false);
          const labels = chained.map((sid) => getSkillById(sid)?.name ?? sid);
          get().pushMessage({
            role: 'system',
            text: `Skill Chain 已同步挂载到当前节点：${labels.join('、')}`,
            nodeId: id,
          });
        }
        return id;
      }
    }

    return pushErr('当前连接不支持该节点类型，请检查起点和终点的组合。');
  },

  startWritingPipeline: (text, position) => {
    const id = get().addDepartmentNode('writing', position);
    get().patchNodeData(id, { input: text }, false);
    get().setActiveNodeId(id);
    get().pushMessage({
      role: 'broadcast',
      text: '编剧节点已开始执行 AI 任务，请稍候。',
      nodeId: id,
    });
    void get().executeNodeTask(id);
    return id;
  },

  executeNodeTask: async (nodeId, opts) => {
    const fromReviewed = opts?.optimizeFromReviewed === true;
    const node = get().nodes.find((n) => n.id === nodeId);
    if (!node || node.type !== 'department') return;
    const kind = node.data.type;
    if (kind !== 'writing' && kind !== 'storyboard' && kind !== 'prompt') return;
    if (fromReviewed) {
      if (node.data.status !== 'REVIEWED') {
        get().pushMessage({
          role: 'system',
          text: '当前节点还没有进入已审核状态，暂时不能基于审核意见继续优化。',
          nodeId,
        });
        return;
      }
    } else if (node.data.status !== 'NOT_STARTED' && node.data.status !== 'REJECTED') {
      get().pushMessage({
        role: 'system',
        text: `当前节点状态是 ${node.data.status}，只有未开始或已驳回的节点才能重新执行。`,
        nodeId,
      });
      return;
    }
    const optimizeFb = fromReviewed ? (node.data.ai_review_feedback?.trim() ?? '') : '';
    // 1. 娴犺濮熼弬鍥ㄦ拱閿涙碍婀?Input 鏉╃偟鍤庨弮璺侯潗缂佸牆鎮庨獮鍓侇伂閸欙絼鏅堕張鈧弬鐗堟瀮閺堫剨绱欓崥?TEXT_NODE.raw_text閿涘绱濋崘宥呭晸閸忋儴濡悙?input 娓氭稑鐫嶇粈?
    const { nodes: n0, edges: e0 } = get();
    const merged0 = mergedTextInputForDepartment(nodeId, n0, e0);
    if (merged0 !== null && merged0.trim() !== '') {
      get().patchNodeData(nodeId, { input: merged0.trim(), inputSource: 'graph' }, false);
    }
    const deptRow = get().nodes.find((n) => n.id === nodeId);
    const inputText = resolveDepartmentExecutionInput(
      nodeId,
      get().nodes,
      get().edges,
      deptRow?.data.input ?? '',
    );
    if (!inputText && !fromReviewed) {
        const msg =
          kind === 'writing'
            ? '鐠囧嘲鍘涢幓鎰返缁辩姵娼楅敍姘殺閺傚洦婀伴崡锛勫鏉╃偛鍩?Input閿涘本鍨ㄩ崷銊嚊閹懍鑵戠划妯垮垱鐏忓繗顕?/ IP 濮濓絾鏋冮妴?'
            : kind === 'storyboard'
            ? '鐠囧嘲鍘涢崘娆忓弳閸撗勬拱閺傚洦婀伴敍姘崇箾閹恒儲鏋冮張顒€宕遍悧鍥у煂 Input 閸氬本顒為敍灞惧灗閸︺劏顕涢幆鍛存桨閺夎￥鈧苯澧介張顒侇劀閺傚洢鈧秳鑵戠划妯垮垱閵?'
            : '鐠囧嘲鍘涢幓鎰返闂団偓濮瑰倽顕╅弰搴窗鐏忓棙鏋冮張顒€宕遍悧鍥箾閸?Input閿涘本鍨ㄩ崷銊嚊閹懍鑵戞繅顐㈠晸娴犺濮熼幓蹇氬牚閵?';
      get().pushMessage({ role: 'system', text: msg, nodeId });
      return;
    }
    // 2. 鏉╂稑鍙嗛幍褑顢戦敍娆糔_PROGRESS + 濞翠礁绱℃０鍕潔鐎涙顔?+ 閽冩繆澹婂ù浣稿帨閿涘牐顫?DepartmentNode閿?
    get().patchNodeData(
      nodeId,
      {
        status: 'IN_PROGRESS',
        ...(fromReviewed
          ? {}
          : {
              output: null,
              review_result: null,
              ai_review_feedback: null,
              leader_review_suggested_pass: undefined,
              ...(kind === 'storyboard' ? { storyboard_ai_snapshot: null } : {}),
            }),
        generation_error: undefined,
        streaming_preview: '',
        generation_phase: 'employee',
      },
      true,
    );
    get().setActiveNodeId(nodeId);
    const broadcastText = fromReviewed
      ? `${deptLabel(kindToDepartment(kind))} 正在按审核意见重新优化。`
      : kind === 'writing'
        ? '编剧节点正在读取输入并生成结果。'
        : kind === 'storyboard'
          ? '分镜节点正在读取输入并生成镜头表。'
          : 'Prompt 节点正在读取输入并生成提示词。';
    get().pushMessage({ role: 'broadcast', text: broadcastText, nodeId });
    activeTaskAbortControllers.get(nodeId)?.abort();
    const controller = new AbortController();
    activeTaskAbortControllers.set(nodeId, controller);
    const ensureNotStopped = () => {
      if (controller.signal.aborted) {
        throw new Error(STOP_TASK_MESSAGE);
      }
    };

    try {
      const src = get().nodes.find((n) => n.id === nodeId);
      const reviewOptimization =
        fromReviewed && src
          ? {
              feedback: optimizeFb || DEFAULT_AI_REVIEW_PASS_SUMMARY,
              currentVersionContent: formatReviewOptimizationPayload(src.data),
            }
          : undefined;
      const taskParams = {
        kind,
        nodeId,
        nodes: get().nodes,
        edges: get().edges,
        fallbackInput: src?.data.input ?? '',
        assets: get().assets,
        sourceSceneCount:
          kind === 'storyboard' && typeof src?.data.sourceSceneCount === 'number'
            ? src.data.sourceSceneCount
            : undefined,
        mountedSkills: Array.isArray(src?.data.mounted_skills) ? src.data.mounted_skills : [],
        taskInstruction:
          typeof src?.data.assistant_task_instruction === 'string'
            ? src.data.assistant_task_instruction
            : '',
        reviewOptimization,
        signal: controller.signal,
        onModelStreamChunk: (_delta: string, accumulated: string) => {
          get().patchNodeData(
            nodeId,
            {
              streaming_preview: accumulated.trim()
                ? `模型正在返回结构化结果，请稍候...\n\n${accumulated}`
                : '模型已连接，正在等待首段输出...',
              generation_phase: 'employee',
            },
            false,
          );
        },
      };

      get().patchNodeData(
        nodeId,
        { streaming_preview: '模型已启动，正在生成内容...', generation_phase: 'employee' },
        false,
      );

      const emp = await executeEmployeePhase(taskParams);
      ensureNotStopped();

      if (emp.ok && emp.skillWarnings?.length) {
        for (const w of emp.skillWarnings) {
          get().pushMessage({ role: 'system', text: w, nodeId });
        }
      }

      if (!emp.ok) {
        const stoppedByUser = (emp.message ?? '') === STOP_TASK_MESSAGE;
        const failMsg = emp.message ?? `${deptLabel(kindToDepartment(kind))} 执行失败，请稍后重试。`;
        get().patchNodeData(
          nodeId,
          {
            status: stoppedByUser && fromReviewed ? 'REVIEWED' : 'NOT_STARTED',
            streaming_preview: undefined,
            generation_phase: undefined,
            generation_error: failMsg,
          },
          true,
        );
        const workflowSession = get().workflowAgentSession;
        if (
          workflowSession &&
          (workflowSession.writingNodeId === nodeId ||
            workflowSession.storyboardNodeId === nodeId ||
            workflowSession.promptNodeId === nodeId)
        ) {
          set((state) =>
            state.workflowAgentSession?.id === workflowSession.id
              ? {
                  workflowAgentSession: {
                    ...state.workflowAgentSession,
                    state: stoppedByUser ? state.workflowAgentSession.state : 'FAILED',
                    lastAssistantMessage: stoppedByUser
                      ? '当前流程任务已停止。'
                      : `${stageLabel(state.workflowAgentSession.state)} 执行失败，请调整后重试。`,
                    updatedAt: Date.now(),
                  },
                }
              : state,
          );
        }
        get().pushMessage({
          role: 'system',
          text: failMsg,
          nodeId,
        });
        return;
      }

      if (kind === 'writing') {
        ingestWritingOutputToProjectContext(nodeId, emp.output as WritingOutput);
        get().pushMessage({
          role: 'system',
          text: 'ProjectContext閿涙艾鍑￠弽瑙勫祦閺堫剛绱崜褌楠囬崙鐑樻纯閺傛澘鍙忕仦鈧憴鎺曞鐠佹儳鐣炬稉搴棑閺嶅ジ鏁嬮悙鐧哥幢閸掑棝鏆?Prompt 鐠嬪啰鏁?API 閺冭泛鐨㈤懛顏勫З闂勫嫬鐢妴?',
          nodeId,
        });
      }

      const previewBody = formatPipelineOutputPreview(kind, emp.output);
      await typewriterStream(
        previewBody,
        (acc) => get().patchNodeData(nodeId, { streaming_preview: acc, generation_phase: 'employee' }, false),
        { chunkChars: 40, delayMs: 20, signal: controller.signal },
      );
      ensureNotStopped();

      const afterEmployee: Partial<StudioNodeData> = {
        output: emp.output,
        input: emp.inputUsed,
        streaming_preview: undefined,
        generation_phase: 'leader',
        generation_error: undefined,
      };
      if (kind === 'storyboard' && emp.narrativeBeatCount != null) {
        afterEmployee.sourceSceneCount = emp.narrativeBeatCount;
      }
      if (kind === 'storyboard' && emp.output) {
        afterEmployee.storyboard_ai_snapshot = cloneStoryboardOutput(emp.output as StoryboardOutput);
      }
      get().patchNodeData(nodeId, afterEmployee, true);

      get().pushMessage({
        role: 'broadcast',
        text: '閸涙ê浼愭径褑鍓冲鎻掔暚閹存劘绶崙鐚寸礉1 缁夋帒鎮楃亸鍡氬殰閸斻劏袝閸欐垶鈧崵娲冩径褑鍓崇€光剝鐗抽垾?',
        nodeId,
      });
      get().patchNodeData(
        nodeId,
        { streaming_preview: '缁涘绶熺憴锕€褰傞幀鑽ゆ磧婢堆嗗壋鐎光剝鐗抽敍鍦揚I閿涘鈧?', generation_phase: 'leader' },
        false,
      );
      await waitWithAbort(LEADER_AUTO_DELAY_MS, controller.signal);
      ensureNotStopped();
      get().patchNodeData(
        nodeId,
        { streaming_preview: '閹崵娲冩径褑鍓冲锝呮躬鐎光剝鐗抽敍鍦揚I閿涘鈧?', generation_phase: 'leader' },
        false,
      );

      const leader = await executeLeaderPhase({
        kind,
        output: emp.output,
        sourceSceneCount:
          kind === 'storyboard'
            ? emp.narrativeBeatCount ?? (typeof src?.data.sourceSceneCount === 'number' ? src.data.sourceSceneCount : undefined)
            : undefined,
        signal: controller.signal,
      });
      ensureNotStopped();

      const feedbackText = leader.approved
        ? (leader.feedback?.trim() || DEFAULT_AI_REVIEW_PASS_SUMMARY)
        : (leader.feedback?.trim() || 'AI 閹崵娲冨楦款唴娣囶喛顓归敍姘愁嚞闂冨懓顕伴幇蹇氼潌閸氬骸婀拠锔藉剰娑擃參鈧瀚ㄩ妴灞惧⒔鐞涘奔绱崠鏍嚡娴狅絻鈧秵鍨ㄩ妴宀€娣幐浣哄箛閻樺爼鈧俺绻冮妴宥冣偓?');

      get().patchNodeData(
        nodeId,
        {
          status: 'REVIEWED',
          ai_review_feedback: feedbackText,
          leader_review_suggested_pass: leader.approved,
          review_result: null,
          streaming_preview: undefined,
          generation_phase: undefined,
          generation_error: undefined,
        },
        true,
      );
      if (kind === 'storyboard') {
        get().ensureShotListForStoryboard(nodeId);
        get().syncShotListNodesFromStoryboard(nodeId);
      }

      const workflowSession = get().workflowAgentSession;
      if (workflowSession) {
        if (kind === 'writing' && workflowSession.writingNodeId === nodeId) {
          set((state) =>
            state.workflowAgentSession?.id === workflowSession.id
              ? {
                  workflowAgentSession: {
                    ...state.workflowAgentSession,
                    state: 'SCRIPT_READY',
                    lastAssistantMessage: '閸撗勬拱闂冭埖顔屽鎻掔暚閹存劧绱濋崣顖欎簰缂佈呯敾鏉╂稑鍙嗛崚鍡涙殔闂冭埖顔岄妴?',
                    updatedAt: Date.now(),
                  },
                }
              : state,
          );
          get().pushMessage({
            role: 'assistant',
            text: 'Agent 閺囧瓨鏌婇敍姘⒔閺堫剟妯佸▓闈涘嚒鐎瑰本鍨氶妴鍌欑稑閸欘垯浜掔紒褏鐢荤拋鈺傚灉鏉╂稑鍙嗛崚鍡涙殔闂冭埖顔岄敍灞肩瘍閸欘垯浜掗崗鍫滄眽瀹搞儱浜曠拫鍐ㄥ⒔閺堫兙鈧?',
            nodeId,
          });
        }
        if (kind === 'storyboard' && workflowSession.storyboardNodeId === nodeId) {
          const shotListChild = findStoryboardShotListChild(get().nodes, get().edges, nodeId);
          set((state) =>
            state.workflowAgentSession?.id === workflowSession.id
              ? {
                  workflowAgentSession: {
                    ...state.workflowAgentSession,
                    state: 'STORYBOARD_GENERATED',
                    shotListNodeId: shotListChild?.id,
                    lastAssistantMessage: '閸掑棝鏆呴梼鑸殿唽瀹告彃鐣幋鎰剁礉閸欘垯浜掔拫鍐╂殻閹存牜鈥樼拋銈呮倵鏉╂稑鍙嗛幓鎰仛鐠囧秹妯佸▓鐐光偓?',
                    updatedAt: Date.now(),
                  },
                }
              : state,
          );
          get().pushMessage({
            role: 'assistant',
            text: 'Agent 閺囧瓨鏌婇敍姘瀻闂€婊冨嚒缂佸繒鏁撻幋鎰暚閹存劑鈧倷缍橀崣顖欎簰閸忓牐鐨熼弫鏉戝瀻闂€婊愮礉閹存牞鈧懐娲块幒銉ユ啞鐠囧鍨滈垾婊呪€樼拋銈呭瀻闂€婧锯偓婵婄箻閸忋儲褰佺粈楦跨槤闂冭埖顔岄妴?',
            nodeId: shotListChild?.id ?? nodeId,
          });
        }
        if (kind === 'prompt' && workflowSession.promptNodeId === nodeId) {
          set((state) =>
            state.workflowAgentSession?.id === workflowSession.id
              ? {
                  workflowAgentSession: {
                    ...state.workflowAgentSession,
                    state: 'PROMPT_GENERATED',
                    lastAssistantMessage: '閹绘劗銇氱拠宥夋▉濞堥潧鍑＄€瑰本鍨氶敍宀冪箹娑撯偓鏉烆喗绁︾粙瀣嚒閸欘垱鏁圭亸淇扁偓?',
                    updatedAt: Date.now(),
                  },
                }
              : state,
          );
          get().pushMessage({
            role: 'assistant',
            text: 'Agent 閺囧瓨鏌婇敍姘絹缁€楦跨槤瀹歌尙绮￠悽鐔稿灇鐎瑰本鍨氶妴鍌欑稑閸欘垯浜掔紒褏鐢诲顔跨殶 Prompt閿涘本鍨ㄩ懓鍛啞鐠囧鍨滈垾婊冪暚閹存劏鈧繃娼电紒鎾存将鏉╂瑤绔存潪顔界ウ缁嬪鈧?',
            nodeId,
          });
        }
      }

      if (leader.approved) {
        const okMsg =
          kind === 'writing'
            ? '编剧节点已通过审核并归档为可用资产。'
            : kind === 'storyboard'
              ? '分镜节点已通过审核并归档为可用资产。'
              : 'Prompt 节点已通过审核并归档为可用资产。';
        get().pushMessage({ role: 'broadcast', text: okMsg, nodeId });
      } else {
        get().pushMessage({
          role: 'broadcast',
          text: `${deptLabel(kindToDepartment(kind))} 审核未通过：${leader.feedback ?? ''}`,
          nodeId,
        });
      }
    } catch (e) {
      const stoppedByUser =
        e instanceof Error && e.message.trim() === STOP_TASK_MESSAGE;
      const errMsg =
        e instanceof Error && e.message.trim()
          ? e.message.trim()
          : `${deptLabel(kindToDepartment(kind))} 任务执行失败，请稍后重试。`;
      get().patchNodeData(
        nodeId,
        {
          status: stoppedByUser && fromReviewed ? 'REVIEWED' : 'NOT_STARTED',
          streaming_preview: undefined,
          generation_phase: undefined,
          generation_error: errMsg,
        },
        true,
      );
      const workflowSession = get().workflowAgentSession;
      if (
        workflowSession &&
        (workflowSession.writingNodeId === nodeId ||
          workflowSession.storyboardNodeId === nodeId ||
          workflowSession.promptNodeId === nodeId)
      ) {
        set((state) =>
          state.workflowAgentSession?.id === workflowSession.id
            ? {
                workflowAgentSession: {
                    ...state.workflowAgentSession,
                    state: stoppedByUser ? state.workflowAgentSession.state : 'FAILED',
                    lastAssistantMessage: stoppedByUser
                      ? '当前流程任务已停止。'
                      : `${stageLabel(state.workflowAgentSession.state)} 执行失败，请调整后重试。`,
                    updatedAt: Date.now(),
                  },
              }
            : state,
        );
      }
      get().pushMessage({
        role: 'system',
        text: errMsg,
        nodeId,
      });
    } finally {
      if (activeTaskAbortControllers.get(nodeId) === controller) {
        activeTaskAbortControllers.delete(nodeId);
      }
    }
  },

  stopNodeTask: (nodeId) => {
    const id = nodeId ?? get().activeNodeId ?? get().selectedNodeId;
    if (!id) {
      get().pushMessage({ role: 'system', text: '婵炲备鍓濆﹢渚€宕ｉ娆掑幀婵縿鍨诲▓鎴炴交閹邦垼鏀藉☉鎿冨幒閹广垽宕濇幊閳?' });
      return;
    }
    const controller = activeTaskAbortControllers.get(id);
    if (!controller) {
      get().pushMessage({
        role: 'system',
        text: '鐟滅増鎸告晶鐘绘嚍閸屾粌浠繛灞稿墲濠€浣割潰閿濆懏韬弶鈺傚姌椤㈡垿鎯冮崟顏呭床闁告枀鎵冲亾?',
        nodeId: id,
      });
      return;
    }
    controller.abort();
    get().pushMessage({
      role: 'system',
      text: STOP_TASK_MESSAGE,
      nodeId: id,
    });
  },

  runReviewedOptimization: (nodeId) => {
    const id = nodeId ?? get().activeNodeId ?? get().selectedNodeId;
    if (!id) {
      get().pushMessage({ role: 'system', text: '濞屸剝婀侀柅澶夎厬閻ㄥ嫰鍎撮梻銊ㄥΝ閻愬箍鈧?' });
      return;
    }
    const node = get().nodes.find((n) => n.id === id);
    if (!node || node.type !== 'department') return;
    if (node.data.status !== 'REVIEWED') {
      get().pushMessage({
        role: 'system',
        text: `当前节点状态是 ${node.data.status}，只有已审核节点才能进入优化。`,
        nodeId: id,
      });
      return;
    }
    const prev = node.data.pipeline_resolution_history ?? [];
    const flashUntil = Date.now() + PIPELINE_DECISION_FLASH_MS;
    get().patchNodeData(
      id,
      {
        pipeline_resolution_history: [
          ...prev,
          { at: Date.now(), kind: 'ai_optimize', summary: '闁插洨鎾煎楦款唴楠炲爼鍣哥粻?' },
        ],
        pipeline_decision_flash: { kind: 'optimize', until: flashUntil },
      },
      true,
    );
    schedulePipelineFlashClear(get, id, flashUntil);
    void get().executeNodeTask(id, { optimizeFromReviewed: true });
  },

  approveReviewedAsIs: (nodeId) => {
    const id = nodeId ?? get().activeNodeId ?? get().selectedNodeId;
    if (!id) {
      get().pushMessage({ role: 'system', text: '濞屸剝婀侀柅澶夎厬閻ㄥ嫰鍎撮梻銊ㄥΝ閻愬箍鈧?' });
      return undefined;
    }
    const node = get().nodes.find((n) => n.id === id);
    if (!node || node.type !== 'department') return undefined;
    if (node.data.status !== 'REVIEWED') {
      get().pushMessage({
        role: 'system',
        text: `当前节点状态是 ${node.data.status}，只有已审核节点才能直接通过。`,
        nodeId: id,
      });
      return id;
    }
    const prev = node.data.pipeline_resolution_history ?? [];
    const hist = [
      ...prev,
      { at: Date.now(), kind: 'human_approve_as_is' as const, summary: '人工确认本轮结果可直接通过' },
    ];
    const flashUntil = Date.now() + PIPELINE_DECISION_FLASH_MS;
    if (node.data.type === 'writing') {
      const out = node.data.output as WritingOutput | null;
      if (!out) {
        get().pushMessage({ role: 'system', text: '鐏忔碍妫ょ紓鏍у⒔娴溠冨毉閿涘本妫ゅ▔鏇⑩偓姘崇箖閵?', nodeId: id });
        return id;
      }
      get().patchNodeData(
        id,
        {
          status: 'APPROVED',
          review_result: REVIEW_RESULT_APPROVE_AS_IS,
          pipeline_resolution_history: hist,
          ai_review_feedback: null,
          leader_review_suggested_pass: undefined,
          pipeline_decision_flash: { kind: 'approve', until: flashUntil },
        },
        true,
      );
      schedulePipelineFlashClear(get, id, flashUntil);
      const v = get().nodes.find((x) => x.id === id)?.data.version ?? node.data.version;
      get().registerAsset({
        nodeId: id,
        department: 'WRITING',
        version: v,
        payload: out,
        createdAt: Date.now(),
      });
      get().pushMessage({
        role: 'broadcast',
        text: '缂傛牕澧介柈顭掔窗瀹歌尙娣幐浣哄箛閻樿泛鑻熼柅姘崇箖閿涘矁绁禍褍鍑￠惂鏄忣唶閿涘奔绗呭〒绋垮讲瀵洜鏁ら妴?',
        nodeId: id,
      });
      return id;
    }
    if (node.data.type === 'storyboard') {
      const out = node.data.output as StoryboardOutput | null;
      if (!out) {
        get().pushMessage({ role: 'system', text: '鐏忔碍妫ら崚鍡涙殔娴溠冨毉閿涘本妫ゅ▔鏇⑩偓姘崇箖閵?', nodeId: id });
        return id;
      }
      get().patchNodeData(
        id,
        {
          status: 'APPROVED',
          review_result: REVIEW_RESULT_APPROVE_AS_IS,
          pipeline_resolution_history: hist,
          ai_review_feedback: null,
          leader_review_suggested_pass: undefined,
          pipeline_decision_flash: { kind: 'approve', until: flashUntil },
        },
        true,
      );
      schedulePipelineFlashClear(get, id, flashUntil);
      const v = get().nodes.find((x) => x.id === id)?.data.version ?? node.data.version;
      get().registerAsset({
        nodeId: id,
        department: 'STORYBOARD',
        version: v,
        payload: out,
        createdAt: Date.now(),
      });
      get().pushMessage({
        role: 'broadcast',
        text: '閸掑棝鏆呴柈顭掔窗瀹歌尙娣幐浣哄箛閻樿泛鑻熼柅姘崇箖閿涘苯鍨庨梹婊嗙カ娴溠冨嚒閻ф槒顔囬妴?',
        nodeId: id,
      });
      return id;
    }
    if (node.data.type === 'prompt') {
      const out = node.data.output as PromptOutput | null;
      if (!out) {
        get().pushMessage({ role: 'system', text: '鐏忔碍妫?Prompt 娴溠冨毉閿涘本妫ゅ▔鏇⑩偓姘崇箖閵?', nodeId: id });
        return id;
      }
      get().patchNodeData(
        id,
        {
          status: 'APPROVED',
          review_result: REVIEW_RESULT_APPROVE_AS_IS,
          pipeline_resolution_history: hist,
          ai_review_feedback: null,
          leader_review_suggested_pass: undefined,
          pipeline_decision_flash: { kind: 'approve', until: flashUntil },
        },
        true,
      );
      schedulePipelineFlashClear(get, id, flashUntil);
      const v = get().nodes.find((x) => x.id === id)?.data.version ?? node.data.version;
      get().registerAsset({
        nodeId: id,
        department: 'PROMPT',
        version: v,
        payload: out,
        createdAt: Date.now(),
      });
      get().pushMessage({
        role: 'broadcast',
        text: 'Prompt 闁煉绱板鑼樊閹镐胶骞囬悩璺鸿嫙闁俺绻冮敍宀冪カ娴溠冨嚒閻ф槒顔囬妴?',
        nodeId: id,
      });
      return id;
    }
    return id;
  },

  runWritingFromInput: (id) => {
    const node = get().nodes.find((n) => n.id === id);
    if (!node || node.data.type !== 'writing') return;
    void get().executeNodeTask(id);
  },

  startStoryboardPipeline: (position) => {
    const id = get().addDepartmentNode('storyboard', position);
    get().patchNodeData(
      id,
      {
        input: '',
        status: 'NOT_STARTED',
        output: null,
        review_result: null,
        sourceSceneCount: undefined,
      },
      true,
    );
    get().setActiveNodeId(id);
    get().pushMessage({
      role: 'broadcast',
      text:
        '瀹告彃鍨卞鍝勫瀻闂€婊嗗Ν閻愮櫢绱欓悪顒傜彌濡€崇础閿涘绱扮拠铚傜矤 Input 閹峰鍤庨崚娑樼紦閺傚洦婀伴崡锛勫楠炲墎鐭樼拹鏉戝⒔閺堫剨绱濋幋鏍ф躬鐠囷附鍎忔稉顓犳纯閹恒儴绶崗銉︻劀閺傚浄绱濋悞璺烘倵閻愮懓鍤妴灞界磻婵濯剁憴锝夋殔婢舵番鈧秲鈧?',
      nodeId: id,
    });
    return id;
  },

  runStoryboardFromInput: (id) => {
    const node = get().nodes.find((n) => n.id === id);
    if (!node || node.data.type !== 'storyboard') return;
    void get().executeNodeTask(id);
  },

  startPromptPipeline: (brief, position) => {
    const id = get().addDepartmentNode('prompt', position);
    get().patchNodeData(id, { input: brief }, false);
    get().setActiveNodeId(id);
    get().pushMessage({
      role: 'broadcast',
      text: 'Prompt 闁劍顒滈崷銊嚢閸?Input 楠炲墎鏁撻幋鎰扳偓鎰版殔閹绘劗銇氱拠宥呭瘶閳?',
      nodeId: id,
    });
    void get().executeNodeTask(id);
    return id;
  },

  runPromptFromInput: (id) => {
    const node = get().nodes.find((n) => n.id === id);
    if (!node || node.data.type !== 'prompt') return;
    void get().executeNodeTask(id);
  },

  triggerLeaderReview: async (nodeId) => {
    const id = nodeId ?? get().activeNodeId ?? get().selectedNodeId;
    if (!id) {
      get().pushMessage({ role: 'system', text: '濞屸剝婀侀崣顖氼吀閺嶅摜娈戝ú鏄忕┈閼哄倻鍋ｉ敍姘愁嚞閸忓牓鈧鑵戦悽璇茬閼哄倻鍋ｉ敍灞惧灗閻劏浜版径鈺佸灡瀵ょ儤绁﹀瀵稿殠閸氬簼绻氶幐浣筋嚉閼哄倻鍋ｆ稉鐑樻た鐠哄啨鈧?' });
      return undefined;
    }
    const node = get().nodes.find((n) => n.id === id);
    if (!node) return undefined;
    if (node.data.status === 'REVIEWED') {
      get().pushMessage({
        role: 'system',
        text:
          '閼哄倻鍋ｅ韫礋閵嗗苯鍑￠梼鍛偓宥忕窗閼奉亜濮╅幀鑽ゆ磧閹板繗顫嗗鎻掓躬鐠囷附鍎忕仦鏇犮仛閵嗗倽顕担璺ㄦ暏閵嗗本澧界悰灞肩喘閸栨牞鍑禒锝冣偓宥嗗灗閵嗗瞼娣幐浣哄箛閻樺爼鈧俺绻冮妴宥忕礉閺冪娀娓堕崘宥嗩偧 @Leader閵?',
        nodeId: id,
      });
      return id;
    }
    if (node.data.status !== 'WAITING_REVIEW') {
      get().pushMessage({
        role: 'system',
        text: `当前节点状态是 ${node.data.status}，只有等待审核的节点才能执行审核。`,
        nodeId: id,
      });
      return id;
    }

    get().pushMessage({
      role: 'broadcast',
      text: `开始审核节点：${node.data.label}`,
      nodeId: id,
    });

    if (node.data.type === 'writing') {
      const out = node.data.output as WritingOutput | null;
      if (!out) return id;
      const decision = await runWritingLeaderReview(out);
      if (decision.approved) {
        get().patchNodeData(id, { status: 'APPROVED', review_result: REVIEW_RESULT_MANUAL_PASS }, true);
        const v = get().nodes.find((x) => x.id === id)?.data.version ?? node.data.version;
        get().registerAsset({
          nodeId: id,
          department: 'WRITING',
          version: v,
          payload: out,
          createdAt: Date.now(),
        });
        get().pushMessage({ role: 'broadcast', text: '编剧节点审核通过，已归档可用资产。', nodeId: id });
      } else {
        get().patchNodeData(
          id,
          { status: 'REJECTED', review_result: decision.feedback },
          true,
        );
        get().pushMessage({
          role: 'broadcast',
          text: `编剧节点审核未通过：${decision.feedback}`,
          nodeId: id,
        });
      }
      return id;
    }

    if (node.data.type === 'storyboard') {
      const out = node.data.output as StoryboardOutput | null;
      if (!out) return id;
      const sceneCount =
        typeof node.data.sourceSceneCount === 'number'
          ? node.data.sourceSceneCount
          : (out.narrativeBeats?.length ?? 0);
      const decision = await runStoryboardLeaderReview(out, sceneCount);
      if (decision.approved) {
        get().patchNodeData(id, { status: 'APPROVED', review_result: REVIEW_RESULT_MANUAL_PASS }, true);
        const v = get().nodes.find((x) => x.id === id)?.data.version ?? node.data.version;
        get().registerAsset({
          nodeId: id,
          department: 'STORYBOARD',
          version: v,
          payload: out,
          createdAt: Date.now(),
        });
        get().pushMessage({
          role: 'broadcast',
          text: '分镜节点审核通过，已归档可用资产。',
          nodeId: id,
        });
      } else {
        get().patchNodeData(
          id,
          { status: 'REJECTED', review_result: decision.feedback },
          true,
        );
        get().pushMessage({
          role: 'broadcast',
          text: `分镜节点审核未通过：${decision.feedback}`,
          nodeId: id,
        });
      }
      return id;
    }

    if (node.data.type === 'prompt') {
      const out = node.data.output as PromptOutput | null;
      if (!out) return id;
      const decision = await runPromptLeaderReview(
        out,
        Array.isArray(node.data.mounted_skills) ? node.data.mounted_skills : [],
      );
      if (decision.approved) {
        get().patchNodeData(id, { status: 'APPROVED', review_result: REVIEW_RESULT_MANUAL_PASS }, true);
        const v = get().nodes.find((x) => x.id === id)?.data.version ?? node.data.version;
        get().registerAsset({
          nodeId: id,
          department: 'PROMPT',
          version: v,
          payload: out,
          createdAt: Date.now(),
        });
        get().pushMessage({ role: 'broadcast', text: 'Prompt 节点审核通过，已归档可用资产。', nodeId: id });
      } else {
        get().patchNodeData(
          id,
          { status: 'REJECTED', review_result: decision.feedback },
          true,
        );
        get().pushMessage({
          role: 'broadcast',
          text: `Prompt 节点审核未通过：${decision.feedback}`,
          nodeId: id,
        });
      }
      return id;
    }

    get().pushMessage({
      role: 'system',
      text: '鐠囥儴濡悙鍦閸ㄥ绗夐弨顖涘瘮閹崵娲冨ù浣规寜缁惧灝顓搁弽鎼炩偓?',
      nodeId: id,
    });
    return id;
  },

  manualPassLeaderReview: (nodeId) => {
    const id = nodeId ?? get().activeNodeId ?? get().selectedNodeId;
    if (!id) {
      get().pushMessage({ role: 'system', text: '濞屸剝婀侀崣顖涙惙娴ｆ粎娈戝ú鏄忕┈閼哄倻鍋ｉ敍姘愁嚞閸忓牓鈧鑵戦悽璇茬娑撳﹦娈戦柈銊╂，閼哄倻鍋ｉ妴?' });
      return undefined;
    }
    const node = get().nodes.find((n) => n.id === id);
    if (!node) return undefined;
    if (node.data.status === 'REVIEWED') {
      return get().approveReviewedAsIs(id);
    }
    if (node.data.status !== 'WAITING_REVIEW') {
      get().pushMessage({
        role: 'system',
        text: `当前节点状态是 ${node.data.status}，只有等待审核或已审核节点才能继续处理。`,
        nodeId: id,
      });
      return id;
    }

    if (node.data.type === 'writing') {
      const out = node.data.output as WritingOutput | null;
      if (!out) {
        get().pushMessage({ role: 'system', text: '鐏忔碍妫ょ紓鏍у⒔娴溠冨毉閿涘本妫ゅ▔鏇熷閸斻劑鈧俺绻冮妴?', nodeId: id });
        return id;
      }
      get().patchNodeData(id, { status: 'APPROVED', review_result: REVIEW_RESULT_MANUAL_PASS }, true);
      const v = get().nodes.find((x) => x.id === id)?.data.version ?? node.data.version;
      get().registerAsset({
        nodeId: id,
        department: 'WRITING',
        version: v,
        payload: out,
        createdAt: Date.now(),
      });
      get().pushMessage({
        role: 'broadcast',
        text: '缂傛牕澧介柈顭掔窗瀹稿弶澧滈崝銊┾偓姘崇箖閿涘牊婀拫鍐暏 AI 閹崵娲冮敍澶涚礉鐠у嫪楠囧鑼鐠佸府绱濇稉瀣埗閸欘垰绱╅悽銊ｂ偓?',
        nodeId: id,
      });
      return id;
    }

    if (node.data.type === 'storyboard') {
      const out = node.data.output as StoryboardOutput | null;
      if (!out) {
        get().pushMessage({ role: 'system', text: '鐏忔碍妫ら崚鍡涙殔娴溠冨毉閿涘本妫ゅ▔鏇熷閸斻劑鈧俺绻冮妴?', nodeId: id });
        return id;
      }
      get().patchNodeData(id, { status: 'APPROVED', review_result: REVIEW_RESULT_MANUAL_PASS }, true);
      const v = get().nodes.find((x) => x.id === id)?.data.version ?? node.data.version;
      get().registerAsset({
        nodeId: id,
        department: 'STORYBOARD',
        version: v,
        payload: out,
        createdAt: Date.now(),
      });
      get().pushMessage({
        role: 'broadcast',
        text: '閸掑棝鏆呴柈顭掔窗瀹稿弶澧滈崝銊┾偓姘崇箖閿涘牊婀拫鍐暏 AI 閹崵娲冮敍澶涚礉閸掑棝鏆呯挧鍕獓瀹歌尙娅ョ拋鑸偓?',
        nodeId: id,
      });
      return id;
    }

    if (node.data.type === 'prompt') {
      const out = node.data.output as PromptOutput | null;
      if (!out) {
        get().pushMessage({ role: 'system', text: '鐏忔碍妫?Prompt 娴溠冨毉閿涘本妫ゅ▔鏇熷閸斻劑鈧俺绻冮妴?', nodeId: id });
        return id;
      }
      get().patchNodeData(id, { status: 'APPROVED', review_result: REVIEW_RESULT_MANUAL_PASS }, true);
      const v = get().nodes.find((x) => x.id === id)?.data.version ?? node.data.version;
      get().registerAsset({
        nodeId: id,
        department: 'PROMPT',
        version: v,
        payload: out,
        createdAt: Date.now(),
      });
      get().pushMessage({
        role: 'broadcast',
        text: 'Prompt 闁煉绱板鍙夊閸斻劑鈧俺绻冮敍鍫熸弓鐠嬪啰鏁?AI 閹崵娲冮敍澶涚礉鐠у嫪楠囧鑼鐠佽埇鈧?',
        nodeId: id,
      });
      return id;
    }

    get().pushMessage({
      role: 'system',
      text: '鐠囥儴濡悙鍦閸ㄥ绗夐弨顖涘瘮閹靛濮╅柅姘崇箖閵?',
      nodeId: id,
    });
    return id;
  },

  focusNode: (id, opts) => {
    const openDetail = opts?.openDetail !== false;
    set((s) => ({
      selectedNodeId: id,
      detailOpen: openDetail,
      activeNodeId: id,
      nodes: s.nodes.map((n) => ({ ...n, selected: n.id === id })),
    }));
  },

  retryPipeline: (id) => {
    const node = get().nodes.find((n) => n.id === id);
    if (!node || node.data.status !== 'REJECTED') return;
    if (
      node.data.type !== 'writing' &&
      node.data.type !== 'storyboard' &&
      node.data.type !== 'prompt'
    ) {
      return;
    }
    get().pushMessage({
      role: 'broadcast',
      text: `${deptLabel(kindToDepartment(node.data.type))} 已开始执行。`,
      nodeId: id,
    });
    void get().executeNodeTask(id);
  },

  syncDepartmentInputFromGraph: (deptId) => {
    const { nodes, edges } = get();
    const merged = mergedTextInputForDepartment(deptId, nodes, edges);
    get().patchNodeData(deptId, { inputSource: 'graph' }, false);
    if (merged !== null) {
      get().patchNodeData(deptId, { input: merged, inputSource: 'graph' }, false);
    }
  },

  removeNodesByIds: (ids) => {
    if (ids.length === 0) return;
    const changes = ids.map((id) => ({ type: 'remove' as const, id }));
    get().onNodesChange(changes);
    get().pushMessage({
      role: 'system',
      text: `已删除 ${ids.length} 个节点。`,
    });
  },

  layoutCanvasWithDagre: () => {
    const { nodes, edges } = get();
    const next = layoutStudioNodesWithDagre(nodes, edges);
    set({ nodes: next });
    get().pushMessage({ role: 'broadcast', text: '瀹稿弶瀵滅仦鍌滈獓閺佸鎮婇悽璇茬閿涘湒agre閿?' });
  },

  undo: () => {
    const snapshot = get().undoStack[get().undoStack.length - 1];
    if (!snapshot) {
      get().pushMessage({ role: 'system', text: '鐟滅増鎸告晶鐘测柦閳╁啯绠掗柛娆樺灡閹告瑩鏌ㄩ埀顒勬儍閸曨厽鏆伴悽顖氬暙瑜板寮村ǎ顑藉亾?' });
      return;
    }
    for (const controller of activeTaskAbortControllers.values()) {
      controller.abort();
    }
    activeTaskAbortControllers.clear();
    set((state) => {
      const restored = restoreUndoSnapshot(snapshot, get);
      return {
        ...restored,
        undoStack: state.undoStack.slice(0, -1),
      };
    });
    get().reconcileShotListGraphBindings();
    get().pushMessage({
      role: 'system',
      text: '鐎圭寮堕幐娆撴煥閳ь剚绋夐埀顒€鈻庨敍鍕毎閻㈩垰鍟ぐ澶愬即濞ｎ兘鍋?',
    });
  },

  hydrateProject: (nodes, edges, opts) => {
    const normalized = nodes.map(normalizeRestoredStudioNode);
    const api = {
      executeNodeTask: (id: string) => get().executeNodeTask(id),
      focusNode: (id: string, o?: { openDetail?: boolean }) => get().focusNode(id, o),
      removeNodesByIds: (ids: string[]) => get().removeNodesByIds(ids),
    };
    const bound = rebindStudioNodeRuntimeHandlers(normalized, api);
    const cleaned: StudioRFNode[] = bound.map((n) => ({
      ...n,
      selected: false,
      dragging: false,
    }));
    set({
      nodes: cleaned,
      edges,
      assets: [],
      selectedNodeId: null,
      activeNodeId: null,
      detailOpen: false,
      requestFitNodeId: null,
      shotListSelectedWiresByNodeId: {},
    });
    get().reconcileShotListGraphBindings();
    get().pushMessage({
      role: 'broadcast',
      text:
        opts?.broadcastText ??
        `已恢复项目，包含 ${nodes.length} 个节点、${edges.length} 条连线。`,
    });
  },

  reconcileShotListGraphBindings: () => {
    const { nodes, edges } = get();
    const parentByShotList = buildStoryboardParentByShotListId(nodes, edges);

    let nextNodes = nodes;
    for (const n of nodes) {
      if (n.type !== 'shotList' || n.data.type !== 'shot_list_node') continue;
      const wiredParent = parentByShotList.get(n.id);
      const wiredParentNode = wiredParent ? nodes.find((x) => x.id === wiredParent) : undefined;
      const nextStoryboardParentId =
        wiredParentNode?.type === 'department' && wiredParentNode.data.type === 'storyboard'
          ? wiredParent
          : undefined;
      const nextStoryboardFileParentId = wiredParentNode?.type === 'storyboardFile' ? wiredParent : undefined;
      if (
        nextStoryboardParentId === n.data.sourceStoryboardNodeId &&
        nextStoryboardFileParentId === n.data.sourceStoryboardFileNodeId
      ) {
        continue;
      }
      nextNodes = nextNodes.map((x) =>
        x.id === n.id
          ? {
              ...x,
              data: {
                ...x.data,
                sourceStoryboardNodeId: nextStoryboardParentId,
                sourceStoryboardFileNodeId: nextStoryboardFileParentId,
              },
            }
          : x,
      );
    }
    if (nextNodes !== nodes) {
      set({ nodes: nextNodes });
    }

    const snap = get();
    const parentMap = buildStoryboardParentByShotListId(snap.nodes, snap.edges);
    const syncParents = new Set<string>();
    const pushShotListIds: string[] = [];

    for (const n of snap.nodes) {
      if (n.type !== 'shotList' || n.data.type !== 'shot_list_node') continue;
      const parentId = n.data.sourceStoryboardNodeId;
      if (!parentId || parentMap.get(n.id) !== parentId) continue;
      const parent = snap.nodes.find(
        (x) => x.id === parentId && x.type === 'department' && x.data.type === 'storyboard',
      );
      if (!parent) continue;
      // 閻栬泛鍨庨梹婊勵劀閸︺劎鏁撻幋鎰閸曞灝顕?output閿涘苯鎯侀崚?onConnect 缁涘袝閸欐垹娈?reconcile 娴兼俺顩惄鏍ㄧウ瀵繋鑵戦惃?output閿涘本妲楃€佃壈鍤ч悩鑸碘偓渚€鏁婃稊杈╂晪閼疯櫕瑕嗛弻鎾崇磽鐢?
      if (parent.data.status === 'IN_PROGRESS') continue;

      const slParsed = n.data.output ? tryParseStoryboardOutput(n.data.output) : null;
      const paParsed = parent.data.output ? tryParseStoryboardOutput(parent.data.output) : null;
      const slKey = storyboardOutputFingerprint(slParsed);
      const paKey = storyboardOutputFingerprint(paParsed);
      if (slKey === paKey) continue;

      if (!slParsed?.shots?.length && paParsed?.shots?.length) {
        syncParents.add(parentId);
      } else if (slParsed?.shots?.length) {
        pushShotListIds.push(n.id);
      }
    }

    for (const sb of syncParents) {
      get().syncShotListNodesFromStoryboard(sb);
    }

    for (const n of snap.nodes) {
      if (n.type !== 'shotList' || n.data.type !== 'shot_list_node') continue;
      const parentId = n.data.sourceStoryboardFileNodeId;
      if (!parentId || parentMap.get(n.id) !== parentId) continue;
      const parent = snap.nodes.find((x) => x.id === parentId && x.type === 'storyboardFile');
      if (!parent) continue;

      const slParsed = n.data.output ? tryParseStoryboardOutput(n.data.output) : null;
      const paParsed = parent.data.output ? tryParseStoryboardOutput(parent.data.output) : null;
      const slKey = storyboardOutputFingerprint(slParsed);
      const paKey = storyboardOutputFingerprint(paParsed);
      if (slKey === paKey) continue;

      if (!slParsed?.shots?.length && paParsed?.shots?.length) {
        get().syncShotListNodesFromStoryboardFile(parentId);
      }
    }

    const afterSync = get();
    const parentMap2 = buildStoryboardParentByShotListId(afterSync.nodes, afterSync.edges);
    for (const slId of pushShotListIds) {
      const n = afterSync.nodes.find((x) => x.id === slId);
      if (!n || n.type !== 'shotList' || n.data.type !== 'shot_list_node') continue;
      const parentId = n.data.sourceStoryboardNodeId;
      if (!parentId || parentMap2.get(slId) !== parentId) continue;
      const parent = afterSync.nodes.find(
        (x) => x.id === parentId && x.type === 'department' && x.data.type === 'storyboard',
      );
      if (!parent) continue;
      if (parent.data.status === 'IN_PROGRESS') continue;
      const slParsed = n.data.output ? tryParseStoryboardOutput(n.data.output) : null;
      const paParsed = parent.data.output ? tryParseStoryboardOutput(parent.data.output) : null;
      if (storyboardOutputFingerprint(slParsed) === storyboardOutputFingerprint(paParsed)) continue;
      if (!slParsed?.shots?.length) continue;
      get().patchShotListNodeOutput(slId, slParsed, false);
    }

    resyncConsumersAfterEdgeMutation(get);
  },

  ensureRuntimeBindingsOnNodes: () => {
    const { nodes } = get();
    if (nodes.length === 0) return;
    // 瀹告彃鐢?onDelete 閸掓瑨顕╅弰?hydrate/rebind 鏉╁浄绱遍柆鍨帳濮ｅ繑顐?set 閺傛澘鍤遍弫鏉跨穿閻劏袝閸?React Flow 閸欐甯堕懞鍌滃仯閸欏秴顦查崥灞绢劄 閳?閺冪娀妾洪弴瀛樻煀
    if (nodes.every((n) => typeof n.data.onDelete === 'function')) return;
    const api = {
      executeNodeTask: (id: string) => get().executeNodeTask(id),
      focusNode: (id: string, o?: { openDetail?: boolean }) => get().focusNode(id, o),
      removeNodesByIds: (ids: string[]) => get().removeNodesByIds(ids),
    };
    set({ nodes: rebindStudioNodeRuntimeHandlers(nodes, api) });
  },
}));

export { getLatestApprovedWritingAsset, getLatestApprovedWritingBundle } from './workflow';
export { canTransitionPipelineStatus, PIPELINE_INITIAL_STATUS } from './workflow';
