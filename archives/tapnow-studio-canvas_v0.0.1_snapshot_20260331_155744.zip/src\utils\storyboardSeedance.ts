import type { PromptShotPack, StoryboardOutput, StoryboardShot } from '@/types/studio';

const DYNAMIC_MOVEMENT_RE =
  /(跟移|推进|拉远|升降|手持|环绕|追逐|tracking|handheld|push|pull|pan|tilt)/i;
const WIDE_TYPE_RE = /(大全景|全景|远景|establish)/i;
const CLOSE_TYPE_RE = /(近景|特写|大特写|close)/i;
const EMOTIONAL_DIALOGUE_RE = /(！|!|？|\?|不要|住手|真相|秘密|对不起|救命|快)/;
const SCENE_SPLIT_RE = /[，,、]/;
const CHARACTER_MARKER_RE =
  /(他|她|他们|她们|人物|角色|男子|女人|少年|少女|老人|侍卫|宫女|主角|对手|人影|身影|背影|脸|面容|眼|眼神|目光|表情|嘴角|双手|手指|转头|回头|凝视)/;
const EMPTY_SHOT_RE = /(空镜|空景|环境镜|建筑外景|建筑内景|道具特写|场景空镜|无人)/;
const MAX_PROMPT_CHARS = 2000;

function uniq(values: string[]): string[] {
  return [...new Set(values.map((item) => item.trim()).filter(Boolean))];
}

function clampInt(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, Math.round(value)));
}

export function clampPromptText(text: string, maxChars = MAX_PROMPT_CHARS): string {
  const normalized = text.trim();
  const chars = Array.from(normalized);
  if (chars.length <= maxChars) return normalized;
  return chars.slice(0, maxChars).join('').trim();
}

export function expandMergedMembers(shot: StoryboardShot): StoryboardShot[] {
  if (Array.isArray(shot.mergedMembers) && shot.mergedMembers.length > 0) {
    return shot.mergedMembers.flatMap((member) => expandMergedMembers(member));
  }
  return [{ ...shot, mergedMembers: undefined }];
}

export function estimateShotDurationSec(
  shot: Pick<StoryboardShot, 'durationSec' | 'content' | 'type' | 'movement'>,
): number {
  if (typeof shot.durationSec === 'number' && Number.isFinite(shot.durationSec) && shot.durationSec > 0) {
    return clampInt(shot.durationSec, 1, 30);
  }
  const dialogue = shot.content?.trim() ?? '';
  const type = shot.type?.trim() ?? '';
  const movement = shot.movement?.trim() ?? '';
  if (dialogue) {
    return EMOTIONAL_DIALOGUE_RE.test(dialogue) || dialogue.length > 20 ? 4 : 3;
  }
  if (DYNAMIC_MOVEMENT_RE.test(movement)) return 5;
  if (WIDE_TYPE_RE.test(type)) return 5;
  if (CLOSE_TYPE_RE.test(type)) return 4;
  return 4;
}

function buildMergedNote(parts: StoryboardShot[]): string {
  const shotTypes = uniq(parts.map((item) => item.type));
  return `同场合并 ${parts.length} 个镜头；景别：${shotTypes.join('、') || '中景'}；适配 Seedance 多镜头连续叙事。`;
}

export function mergeStoryboardShotSlice(slice: StoryboardShot[]): StoryboardShot {
  const base = slice[0];
  const members = slice.flatMap((item) => expandMergedMembers(item));
  const descriptions = members
    .map((item, idx) => {
      const description = item.description.trim();
      if (!description) return '';
      return `段落${idx + 1}(${item.type}/${item.movement})：${description}`;
    })
    .filter(Boolean);
  const dialogues = members.map((item) => item.content.trim()).filter(Boolean);
  const actions = members.map((item) => item.action?.trim() ?? '').filter(Boolean);
  const notes = members.map((item) => item.note?.trim() ?? '').filter(Boolean);
  const types = uniq(members.map((item) => item.type));
  const movements = uniq(members.map((item) => item.movement));
  const scenes = uniq(members.map((item) => item.sceneRef ?? base.sceneRef ?? ''));
  const totalDuration = members.reduce((sum, item) => sum + estimateShotDurationSec(item), 0);

  return {
    ...base,
    id: base.id,
    type: types.length > 1 ? '多景别切换' : (types[0] ?? base.type),
    movement:
      movements.length > 1
        ? `智能切换(${movements.slice(0, 3).join(' / ')})`
        : (movements[0] ?? base.movement),
    description: descriptions.join('；') || base.description,
    content: dialogues.join(' / '),
    action: actions.length ? actions.join(' / ') : undefined,
    sceneRef: scenes[0] || base.sceneRef,
    durationSec: totalDuration,
    note: [buildMergedNote(members), ...notes.slice(0, 1)].filter(Boolean).join('；'),
    mergedMembers: members,
  };
}

export function mergeSameSceneShots(shots: StoryboardShot[], maxDurationSec = 15): StoryboardShot[] {
  if (maxDurationSec <= 0 || shots.length <= 1) {
    return shots.map((shot, idx) => ({ ...shot, id: idx + 1 }));
  }

  const merged: StoryboardShot[] = [];
  let bucket: StoryboardShot[] = [];

  const flushBucket = () => {
    if (!bucket.length) return;
    if (bucket.length === 1) {
      const [single] = bucket;
      merged.push({
        ...single,
        durationSec: estimateShotDurationSec(single),
      });
    } else {
      merged.push(mergeStoryboardShotSlice(bucket));
    }
    bucket = [];
  };

  for (const shot of shots) {
    if (!bucket.length) {
      bucket.push(shot);
      continue;
    }
    const bucketScene = (bucket[0].sceneRef ?? '').trim();
    const currentScene = (shot.sceneRef ?? '').trim();
    const sameScene =
      bucketScene !== '' &&
      currentScene !== '' &&
      bucketScene.split(SCENE_SPLIT_RE)[0] === currentScene.split(SCENE_SPLIT_RE)[0];
    const nextDuration =
      bucket.reduce((sum, item) => sum + estimateShotDurationSec(item), 0) +
      estimateShotDurationSec(shot);
    if (sameScene && nextDuration <= maxDurationSec) {
      bucket.push(shot);
      continue;
    }
    flushBucket();
    bucket.push(shot);
  }

  flushBucket();

  return merged.map((shot, idx) => ({
    ...shot,
    id: idx + 1,
  }));
}

function normalizeMountEntityToken(value: string): string {
  return value.replace(/[\s,，。、《》【】：“”"'()（）]/g, '').trim();
}

function extractNamedEntities(text: string): string[] {
  const matches = text.match(/[\u4e00-\u9fa5A-Za-z0-9_-]{2,12}/g) ?? [];
  return uniq(
    matches
      .map((item) => normalizeMountEntityToken(item))
      .filter((item) => item.length >= 2),
  );
}

function hasCharacterPresence(shot: StoryboardShot, pack?: PromptShotPack): boolean {
  const text = [
    shot.description,
    shot.content,
    shot.action ?? '',
    shot.note ?? '',
    pack?.dimensions?.角色 ?? '',
  ]
    .join(' ')
    .trim();
  if (!text) return false;
  if (EMPTY_SHOT_RE.test(text) && !CHARACTER_MARKER_RE.test(text) && !shot.content.trim()) return false;
  if (shot.content.trim()) return true;
  const roleText = pack?.dimensions?.角色?.trim() ?? '';
  if (roleText && !/(空间|场景|环境|建筑|道具|主体对象)/.test(roleText)) return true;
  return CHARACTER_MARKER_RE.test(text);
}

function pickMustShow(shot: StoryboardShot, pack?: PromptShotPack): string[] {
  const hasCharacter = hasCharacterPresence(shot, pack);
  const scene = pack?.dimensions?.场景?.trim() || shot.sceneRef?.trim() || '当前场景空间关系';
  const actor = hasCharacter
    ? pack?.dimensions?.角色?.trim() || '主体角色'
    : '空间主体';
  const action = pack?.dimensions?.动作?.trim() || shot.action?.trim() || '核心动作/氛围变化';
  const result = shot.content.trim() || shot.description.trim().split(/[，。；]/)[0] || '情绪落点';
  return [scene, actor, action, result].filter(Boolean).slice(0, 4);
}

function collectMountEntities(shot: StoryboardShot, pack?: PromptShotPack): string[] {
  const hasCharacter = hasCharacterPresence(shot, pack);
  const sourceTexts = [
    hasCharacter ? pack?.dimensions?.角色 ?? '' : '',
    pack?.dimensions?.场景 ?? '',
    pack?.dimensions?.动作 ?? '',
    shot.sceneRef ?? '',
    shot.description ?? '',
    shot.content ?? '',
    shot.action ?? '',
    shot.note ?? '',
  ];
  const entities = uniq(sourceTexts.flatMap((text) => extractNamedEntities(text)));
  return uniq([
    ...entities,
    ...pickMustShow(shot, pack).map((item) => normalizeMountEntityToken(item)),
  ])
    .filter(Boolean)
    .slice(0, 8);
}

function buildMountBlock(shot: StoryboardShot, pack?: PromptShotPack): string {
  const entities = collectMountEntities(shot, pack);
  if (entities.length === 0) return '|@=主体角色| |@=当前场景|';
  if (entities.length === 1) return `|@=${entities[0]}| |@=当前场景|`;
  return entities.map((entity) => `|@=${entity}|`).join(' ');
}

function buildRhythmLabel(shot: StoryboardShot): string {
  if (shot.mergedMembers?.length) return '多镜头顺切、动作递进、结果落点';
  if (shot.content.trim()) return '对白推进、情绪显形';
  if (DYNAMIC_MOVEMENT_RE.test(shot.movement)) return '动作推进、节奏上扬';
  if (WIDE_TYPE_RE.test(shot.type)) return '空间建立、信息铺陈';
  return '建立关系、收束信息';
}

function buildCardType(shot: StoryboardShot): string {
  const text = `${shot.description} ${shot.content} ${shot.note ?? ''}`;
  if (/(追击|被击|爆发|扑向|翻窗)/.test(text)) return 'F';
  if (/(真相|揭示|发现|识别|暴露)/.test(text)) return 'E';
  if (/(对视|质问|确认|回答|台词|对白)/.test(text)) return 'D';
  if (/(黑场|转场|闪回|故障|停顿)/.test(text)) return 'B';
  return 'C';
}

function buildScheme(shot: StoryboardShot): string {
  if (shot.mergedMembers?.length) return '同场多镜头组合推进';
  if (shot.content.trim()) return '对白推进->情绪落点';
  if (DYNAMIC_MOVEMENT_RE.test(shot.movement)) return '锁定目标->动作推进';
  if (WIDE_TYPE_RE.test(shot.type)) return '建立空间->推进动作';
  return '建立关系->结果成立';
}

function buildDualFrameText(shot: StoryboardShot, pack?: PromptShotPack): { vertical: string; horizontal: string } {
  const subject = pickMustShow(shot, pack)[1] ?? '主体角色';
  const action = pickMustShow(shot, pack)[2] ?? '核心动作';
  const hasCharacter = hasCharacterPresence(shot, pack);
  if (!hasCharacter) {
    return {
      vertical: `${subject}位于纵向视觉重心，保留空间层次、光影走向与道具关系。`,
      horizontal: `${subject}置于横向结构关键点，保留纵深通道、前后景遮挡与氛围落点。`,
    };
  }
  return {
    vertical: `${subject}位于纵向主视觉中轴，保留${action}的上下动作空间与前后遮挡层次。`,
    horizontal: `${subject}置于横向三分构图关键点，保留场景纵深、对手位与动作方向。`,
  };
}

function buildStateProgression(shot: StoryboardShot): string {
  if (shot.mergedMembers?.length) {
    return shot.mergedMembers
      .map(
        (member, idx) =>
          `镜头${idx + 1}：${member.description.trim() || member.action?.trim() || member.content.trim() || '推进事件'}`,
      )
      .join('\n');
  }
  return [
    `起始：${shot.description.trim() || '建立空间与主体关系'}`,
    `中段：${shot.action?.trim() || shot.content.trim() || '推进关键动作或对白'}`,
    '落点：镜头停在最关键信息或情绪结果上。',
  ].join('\n');
}

function buildSoundAtmo(shot: StoryboardShot, pack?: PromptShotPack): string {
  if (shot.content.trim()) {
    return `保留原台词：${shot.content.trim()}\n无背景音乐，仅保留环境声、动作声与呼吸质感。`;
  }
  if (!hasCharacterPresence(shot, pack)) {
    return '无对白、无人声，以风声、雨声、灯鸣、布料轻响、门窗回声或空间底噪维持氛围。';
  }
  return '无背景音乐，以环境声、脚步声、衣料声或空间底噪维持紧张氛围。';
}

function buildMicroExpression(shot: StoryboardShot, pack?: PromptShotPack): string {
  if (!hasCharacterPresence(shot, pack)) {
    return '本镜为空镜/无人物镜头，不设置微表情；用光影、气流、道具轻微位移或景深变化承担情绪。';
  }
  if (shot.mergedMembers?.length) {
    let elapsed = 0;
    return shot.mergedMembers
      .map((member, idx) => {
        elapsed += estimateShotDurationSec(member);
        return `${elapsed}s 附近：镜头${idx + 1}完成表情、视线或状态落点。`;
      })
      .join('\n');
  }
  return '在镜头收束前补一个可读的眼神、停顿或细小动作变化。';
}

function buildRoleFacing(shot: StoryboardShot, pack?: PromptShotPack, mustShow?: string[]): string {
  if (!hasCharacterPresence(shot, pack)) {
    return '本镜无可见人物，不设置角色朝向；以光源方向、空间透视线和道具指向组织画面。';
  }
  return `${(mustShow ?? pickMustShow(shot, pack))[1] ?? '主体角色'}始终朝向事件中心，表演重点跟随动作或对白落点。`;
}

function buildReferenceDivision(shot: StoryboardShot, mustShow: string[], pack?: PromptShotPack): string {
  if (!hasCharacterPresence(shot, pack)) {
    return `@场景负责：${mustShow[0] ?? '场景关系'}\n@道具负责：${mustShow[2] ?? '关键道具/氛围元素'}\n@摄影负责：${shot.type} / ${shot.movement}`;
  }
  return `@角色负责：${mustShow[1] ?? '主体角色'}\n@场景负责：${mustShow[0] ?? '场景关系'}\n@摄影负责：${shot.type} / ${shot.movement}`;
}

function buildWenXiAdditional(shot: StoryboardShot, pack?: PromptShotPack): string {
  if (!hasCharacterPresence(shot, pack)) {
    return '空镜不写表情或对白调度，以光影、气流、道具轻微位移和空间张力承担叙事。';
  }
  return shot.content.trim()
    ? '对白镜头不做机械正反打，要让动作、视线与停顿承担信息传递。'
    : '非对白镜头通过动作与空间调度完成叙事，不补多余解释。';
}

export function buildSeedanceCard(shot: StoryboardShot, pack?: PromptShotPack): string {
  const mustShow = pickMustShow(shot, pack);
  const { vertical, horizontal } = buildDualFrameText(shot, pack);
  const prompt = clampPromptText(pack?.prompt?.trim() || shot.description.trim());
  const durationSec = estimateShotDurationSec(shot);

  return [
    `【分镜${String(shot.id).padStart(2, '0')} | ${durationSec}秒 | 类型:${buildCardType(shot)} | 方案:${buildScheme(shot)} | 档位:LTE | 节奏:${buildRhythmLabel(shot)}】`,
    '',
    '挂载:',
    buildMountBlock(shot, pack),
    '',
    '相机位置:',
    `${shot.sceneRef?.trim() || '当前场景'}内保持${shot.type}主导，围绕主体动作或空间变化建立观察关系。`,
    '',
    '相机朝向:',
    `${shot.movement.trim() || '固定'}，镜头始终沿同一动作方向线推进，不跳轴。`,
    '',
    '角色朝向:',
    buildRoleFacing(shot, pack, mustShow),
    '',
    '构图锚点:',
    `前景：${mustShow[0] ?? '场景元素'}\n中景：${mustShow[1] ?? '主体对象'}\n背景：${mustShow[2] ?? '关键动作/道具'} 与 ${mustShow[3] ?? '结果信息'}`,
    '',
    '镜头规格:',
    `景别：${shot.type}\n运镜：${shot.movement}\n时长：${durationSec}秒\n焦点始终服务核心动作与结果落点。`,
    '',
    '起端:',
    shot.description.trim() || '先建立空间、主体与事件中心的关系。',
    '',
    '变化:',
    shot.action?.trim() || shot.content.trim() || '中段推进关键动作或信息变化。',
    '',
    '落幅:',
    mustShow[3] ?? '镜头落在最关键的情绪或信息结果上。',
    '',
    '稳幅:',
    '在结果成立后短暂停稳，再把势能交给下一镜头。',
    '',
    '承接:',
    '承接上一镜头的动作方向与情绪惯性，不做解释性停顿。',
    '',
    '接力物:',
    `${mustShow[2] ?? '关键动作'} 与 ${mustShow[3] ?? '结果信息'} 共同承担节奏接力。`,
    '',
    '过门:',
    shot.mergedMembers?.length ? '使用同场自然顺切完成景别变化，保持叙事连续。' : '使用自然切换或动作匹配进入下一镜。',
    '',
    '【双版本构图】',
    '',
    `9:16 = ${vertical}`,
    `16:9 = ${horizontal}`,
    '（不换轴线）',
    '',
    '【使用状态递进】',
    '',
    buildStateProgression(shot),
    '',
    '【运动协议】',
    '',
    `镜头按“${shot.type} / ${shot.movement}”执行，严守主体动作方向与空间连续性。`,
    '',
    '提示词(复制到即梦):',
    '',
    prompt,
    '',
    '【目标物 Must-Show】',
    '',
    mustShow.join('\n'),
    '',
    '【参考分工】',
    '',
    buildReferenceDivision(shot, mustShow, pack),
    '',
    '【声音/氛围】',
    '',
    buildSoundAtmo(shot, pack),
    '',
    '【微表情】',
    '',
    buildMicroExpression(shot, pack),
    '',
    '【文戏附加】',
    '',
    buildWenXiAdditional(shot, pack),
    '',
    '【钉子4行】',
    '',
    `硬钉子：必须看清 ${mustShow[0] ?? '场景'} 与 ${mustShow[1] ?? '主体对象'}`,
    `硬钉子：动作落点必须指向 ${mustShow[2] ?? '核心动作/道具'}`,
    `情绪钉子：${pack?.dimensions?.情感?.trim() || '紧张、悬疑、逐步逼近'}`,
    `叙事钉子：镜头最终落在 ${mustShow[3] ?? '结果信息'} 上`,
  ].join('\n');
}

export function buildSeedanceCardsText(
  output: PromptShotPack[],
  storyboard: StoryboardOutput | null,
): string {
  return output
    .map((pack, idx) => {
      const shotId = Number(pack.shot_id.replace(/[^\d]/g, ''));
      const source =
        storyboard?.shots.find((item) => item.id === shotId) ??
        storyboard?.shots[idx] ?? {
          id: idx + 1,
          type: pack.dimensions?.镜头 || '中景',
          movement: pack.dimensions?.运镜 || '固定',
          description: pack.prompt,
          content: '',
        };
      return buildSeedanceCard(source, { ...pack, prompt: clampPromptText(pack.prompt) });
    })
    .join('\n\n');
}
