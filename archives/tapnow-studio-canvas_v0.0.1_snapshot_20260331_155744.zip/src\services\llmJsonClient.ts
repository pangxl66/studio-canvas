import { getResolvedLlmGatewayConfig } from '@/config/llmSettings';
import { requestLLM, requestLLMStream } from '@/services/ModelGateway';
import { safeJsonParse } from '@/services/safeJsonParse';

function buildJsonRepairUserPrompt(originalUserPrompt: string, rawResponse: string): string {
  const snippet = rawResponse.trim().slice(0, 4000);
  return [
    '你上一次返回的内容未能被系统解析成合法 JSON。',
    '请不要解释，不要 markdown，不要代码块，只输出一个合法 JSON 对象。',
    '',
    '【原始任务】',
    originalUserPrompt,
    '',
    '【上一次返回内容】',
    snippet || '（空）',
    '',
    '【本次要求】',
    '严格返回一个可被 JSON.parse 解析的 JSON 对象，不要附加任何前后缀。',
  ].join('\n');
}

export function parseModelJson(raw: string, fallbackHint?: string): unknown {
  const result = safeJsonParse(raw);
  if (!result.ok) {
    throw new Error(fallbackHint ? `${result.error} ${fallbackHint}` : result.error);
  }
  return result.value;
}

const MISSING_CFG =
  '未配置大模型 API：请在应用内“设置”填写 Base URL 与 API Key，或在项目根目录 `.env` 中配置 `VITE_LLM_BASE_URL`、`VITE_LLM_API_KEY`（可选再配 `VITE_LLM_MODE`、`VITE_LLM_FAST_MODEL`、`VITE_LLM_DEEP_MODEL`）。';

/**
 * 非流式 JSON 模式调用。
 * 未配置网关时直接抛错，不再使用本地模板冒充 API。
 */
export async function invokeLlmJsonObject(params: {
  systemPrompt: string;
  userPrompt: string;
  temperature?: number;
  model?: string;
  signal?: AbortSignal;
}): Promise<unknown> {
  const config = getResolvedLlmGatewayConfig();
  if (!config) {
    throw new Error(MISSING_CFG);
  }

  const res = await requestLLM(config, {
    systemPrompt: params.systemPrompt,
    userPrompt: params.userPrompt,
    temperature: params.temperature ?? 0.35,
    jsonMode: true,
    model: params.model,
    signal: params.signal,
  });

  if (!res.ok) {
    throw new Error(res.error.message);
  }

  try {
    return parseModelJson(res.content);
  } catch {
    const repairRes = await requestLLM(config, {
      systemPrompt: params.systemPrompt,
      userPrompt: buildJsonRepairUserPrompt(params.userPrompt, res.content),
      temperature: 0.1,
      jsonMode: true,
      model: params.model,
      signal: params.signal,
    });

    if (!repairRes.ok) {
      throw new Error(repairRes.error.message);
    }

    return parseModelJson(
      repairRes.content,
      '模型已自动进行一次 JSON 修复重试，但返回内容仍无法解析。',
    );
  }
}

/**
 * 流式 JSON 模式调用。
 * 优先使用 `stream=true`，让长耗时任务持续产出增量，降低中途被网关空闲超时切断的概率。
 * 若网关明确不支持流式，再自动回退到普通 JSON 请求。
 */
export async function invokeLlmJsonObjectStream(params: {
  systemPrompt: string;
  userPrompt: string;
  temperature?: number;
  model?: string;
  onDelta?: (delta: string, accumulated: string) => void;
  onComplete?: (fullText: string) => void;
  signal?: AbortSignal;
}): Promise<unknown> {
  const config = getResolvedLlmGatewayConfig();
  if (!config) {
    throw new Error(MISSING_CFG);
  }

  const streamRes = await requestLLMStream(config, {
    systemPrompt: params.systemPrompt,
    userPrompt: params.userPrompt,
    temperature: params.temperature ?? 0.35,
    jsonMode: true,
    model: params.model,
    signal: params.signal,
    onDelta: (delta, accumulated) => {
      params.onDelta?.(delta, accumulated);
    },
    onComplete: (fullText) => {
      params.onComplete?.(fullText);
    },
  });

  if (streamRes.ok) {
    try {
      return parseModelJson(streamRes.content);
    } catch {
      const repairRes = await requestLLM(config, {
        systemPrompt: params.systemPrompt,
        userPrompt: buildJsonRepairUserPrompt(params.userPrompt, streamRes.content),
        temperature: 0.1,
        jsonMode: true,
        model: params.model,
        signal: params.signal,
      });

      if (!repairRes.ok) {
        throw new Error(repairRes.error.message);
      }

      return parseModelJson(
        repairRes.content,
        '模型已自动进行一次 JSON 修复重试，但返回内容仍无法解析。',
      );
    }
  }

  const shouldFallback =
    streamRes.error.code !== 'USER_ABORT' &&
    (streamRes.error.code === 'HTTP_400' ||
    streamRes.error.code === 'HTTP_404' ||
    streamRes.error.code === 'NO_BODY' ||
    streamRes.error.code === 'EMPTY_STREAM');

  if (!shouldFallback) {
    throw new Error(streamRes.error.message);
  }

  const res = await requestLLM(config, {
    systemPrompt: params.systemPrompt,
    userPrompt: params.userPrompt,
    temperature: params.temperature ?? 0.35,
    jsonMode: true,
    model: params.model,
    signal: params.signal,
  });

  if (!res.ok) {
    throw new Error(res.error.message);
  }

  params.onComplete?.(res.content);
  try {
    return parseModelJson(res.content);
  } catch {
    const repairRes = await requestLLM(config, {
      systemPrompt: params.systemPrompt,
      userPrompt: buildJsonRepairUserPrompt(params.userPrompt, res.content),
      temperature: 0.1,
      jsonMode: true,
      model: params.model,
      signal: params.signal,
    });

    if (!repairRes.ok) {
      throw new Error(repairRes.error.message);
    }

    return parseModelJson(
      repairRes.content,
      '模型已自动进行一次 JSON 修复重试，但返回内容仍无法解析。',
    );
  }
}

export type LeaderReviewDecision = { approved: boolean; feedback: string | null };

const LEADER_OUTPUT_INSTRUCTION = `【输出格式】仅输出一个 JSON 对象，不要其他文字：

- 通过：{"approved": true}

- 打回：{"approved": false, "feedback": "具体修改建议（中文，指出问题与改进方向）"}`;

/**
 * 总监审核：调用 LLM 按规范审查产出，返回通过/打回及反馈。
 */
export async function invokeLlmLeaderReview(params: {
  systemPrompt: string;
  userPrompt: string;
  temperature?: number;
  signal?: AbortSignal;
}): Promise<LeaderReviewDecision> {
  const config = getResolvedLlmGatewayConfig();
  if (!config) {
    throw new Error(MISSING_CFG);
  }

  const system = `${params.systemPrompt.trim()}\n\n${LEADER_OUTPUT_INSTRUCTION}`;

  const res = await requestLLM(config, {
    systemPrompt: system,
    userPrompt: params.userPrompt,
    temperature: params.temperature ?? 0.2,
    jsonMode: true,
    signal: params.signal,
  });

  if (!res.ok) {
    throw new Error(res.error.message);
  }

  const parsed = parseModelJson(res.content) as unknown;
  if (!parsed || typeof parsed !== 'object') {
    throw new Error('总监模型返回异常：必须是 JSON 对象。');
  }

  const o = parsed as Record<string, unknown>;
  const approved = o.approved === true;
  const feedback = approved
    ? null
    : typeof o.feedback === 'string' && o.feedback.trim()
      ? o.feedback.trim()
      : '请根据审核维度给出具体修改建议。';

  return { approved, feedback };
}
