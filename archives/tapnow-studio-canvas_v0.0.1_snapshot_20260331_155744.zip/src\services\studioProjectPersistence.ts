import type { Edge } from '@xyflow/react';
import type { StudioRFNode } from '@/types/reactFlow';
import {
  normalizeRestoredStudioNode,
  toPersistableNodesAndEdges,
} from '@/utils/studioNodePersistence';

export const STUDIO_PROJECT_JSON_VERSION = 1;

export const STUDIO_IDB_NAME = 'studio-ai-drama-idb';
export const STUDIO_IDB_STORE = 'project_snapshots';
export const STUDIO_IDB_AUTOSAVE_KEY = 'canvas_autosave';

function isRecord(x: unknown): x is Record<string, unknown> {
  return typeof x === 'object' && x !== null && !Array.isArray(x);
}

/** 与「保存项目」下载文件、IndexedDB 自动存档共用同一结构 */
export type StudioProjectFilePayload = {
  version: number;
  savedAt: number;
  nodes: StudioRFNode[];
  edges: Edge[];
};

export function stringifyStudioProjectPayload(nodes: StudioRFNode[], edges: Edge[]): string {
  const { nodes: persistableNodes, edges: persistableEdges } = toPersistableNodesAndEdges(nodes, edges);
  const payload: StudioProjectFilePayload = {
    version: STUDIO_PROJECT_JSON_VERSION,
    savedAt: Date.now(),
    nodes: persistableNodes,
    edges: persistableEdges,
  };
  return JSON.stringify(payload, null, 2);
}

/** 解析用户选择的 .json 或 IndexedDB 读出的对象 */
export function parseStudioProjectPayload(raw: unknown): StudioProjectFilePayload | null {
  if (!isRecord(raw)) return null;
  const nodes = raw.nodes;
  const edges = raw.edges;
  if (!Array.isArray(nodes) || !Array.isArray(edges)) return null;
  for (const n of nodes) {
    if (!isRecord(n)) return null;
    if (typeof n.id !== 'string') return null;
    if (n.type !== 'department' && n.type !== 'textNode' && n.type !== 'shotList') return null;
    if (!isRecord(n.position) || typeof n.position.x !== 'number' || typeof n.position.y !== 'number') {
      return null;
    }
    if (!isRecord(n.data)) return null;
  }
  for (const e of edges) {
    if (!isRecord(e)) return null;
    if (typeof e.id !== 'string' || typeof e.source !== 'string' || typeof e.target !== 'string') {
      return null;
    }
  }
  const normalizedNodes = (nodes as StudioRFNode[]).map(normalizeRestoredStudioNode);
  return {
    version: typeof raw.version === 'number' ? raw.version : STUDIO_PROJECT_JSON_VERSION,
    savedAt: typeof raw.savedAt === 'number' ? raw.savedAt : Date.now(),
    nodes: normalizedNodes,
    edges: edges as Edge[],
  };
}

export function parseStudioProjectJsonFile(text: string): StudioProjectFilePayload | null {
  let parsed: unknown;
  try {
    parsed = JSON.parse(text) as unknown;
  } catch {
    return null;
  }
  return parseStudioProjectPayload(parsed);
}

function openStudioIdb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(STUDIO_IDB_NAME, 1);
    req.onerror = () => reject(req.error ?? new Error('IndexedDB open failed'));
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STUDIO_IDB_STORE)) {
        db.createObjectStore(STUDIO_IDB_STORE);
      }
    };
  });
}

export async function putStudioAutosave(payload: StudioProjectFilePayload): Promise<void> {
  const db = await openStudioIdb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STUDIO_IDB_STORE, 'readwrite');
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error('IndexedDB write failed'));
    tx.objectStore(STUDIO_IDB_STORE).put(payload, STUDIO_IDB_AUTOSAVE_KEY);
  });
  db.close();
}

export async function getStudioAutosave(): Promise<StudioProjectFilePayload | null> {
  const db = await openStudioIdb();
  const raw = await new Promise<unknown>((resolve, reject) => {
    const tx = db.transaction(STUDIO_IDB_STORE, 'readonly');
    const q = tx.objectStore(STUDIO_IDB_STORE).get(STUDIO_IDB_AUTOSAVE_KEY);
    q.onsuccess = () => resolve(q.result);
    q.onerror = () => reject(q.error ?? new Error('IndexedDB read failed'));
  });
  db.close();
  return parseStudioProjectPayload(raw);
}
