import { useCallback, useState } from 'react';
import {
  getLlmSettingsFormDefaults,
  getResolvedLlmGatewayConfig,
  pipelineModeForLlmMode,
  pipelineModeNeedsGateway,
} from '@/config/llmSettings';
import { STUDIO_OPEN_SETTINGS_EVENT } from '@/components/StudioSettings';
import { useStudioStore } from '@/store/useStudioStore';

export function StudioWelcomePanel() {
  const nodeCount = useStudioStore((s) => s.nodes.length);
  const addDepartmentNode = useStudioStore((s) => s.addDepartmentNode);
  const addTextNode = useStudioStore((s) => s.addTextNode);
  const focusNode = useStudioStore((s) => s.focusNode);
  const [dismissed, setDismissed] = useState(false);

  const llmMode = getLlmSettingsFormDefaults().mode;
  const pipelineMode = pipelineModeForLlmMode(llmMode);
  const configReady = getResolvedLlmGatewayConfig() != null;
  const gatewayRequired = pipelineModeNeedsGateway(pipelineMode);
  const modeReady = !gatewayRequired || configReady;

  const createWritingNode = useCallback(() => {
    const id = addDepartmentNode('writing', { x: 320, y: 220 });
    focusNode(id);
  }, [addDepartmentNode, focusNode]);

  const createTextCard = useCallback(() => {
    const id = addTextNode('', { x: 120, y: 250 });
    focusNode(id, { openDetail: true });
  }, [addTextNode, focusNode]);

  const openSettings = useCallback(() => {
    window.dispatchEvent(new Event(STUDIO_OPEN_SETTINGS_EVENT));
  }, []);

  if (nodeCount > 0 || dismissed) return null;

  return (
    <div className="studio-welcome-panel" role="region" aria-label="新手引导">
      <div className={`studio-welcome-panel__badge ${modeReady ? 'studio-welcome-panel__badge--ok' : ''}`}>
        {modeReady ? `已就绪 · ${llmMode === 'deep' ? 'Deep' : 'Fast'}` : `请先配置 ${llmMode === 'deep' ? 'Deep' : 'Fast'} 模式`}
      </div>
      <h2 className="studio-welcome-panel__title">第一次使用？从这 3 步开始</h2>
      <p className="studio-welcome-panel__desc">
        现在只保留 <code>Fast / Deep</code> 两种方式。<code>Fast</code> 走本地，<code>Deep</code> 走 API。
      </p>

      <div className="studio-welcome-panel__steps">
        <div className="studio-welcome-panel__step">
          <span className="studio-welcome-panel__step-no">1</span>
          <div>
            <strong>选择 Fast 或 Deep</strong>
            <p>右上角直接切换。Fast 走本地；Deep 走 API，需要先在设置里填 Base URL 和 API Key。</p>
          </div>
        </div>
        <div className="studio-welcome-panel__step">
          <span className="studio-welcome-panel__step-no">2</span>
          <div>
            <strong>输入故事素材</strong>
            <p>可以直接粘贴小说正文、剧本段落、人物设定，或者先创建文本卡片。</p>
          </div>
        </div>
        <div className="studio-welcome-panel__step">
          <span className="studio-welcome-panel__step-no">3</span>
          <div>
            <strong>让节点接力工作</strong>
            <p>先过编剧，再到分镜和 Prompt；Fast 模式下分镜与提示词可以本地跑，Deep 模式则走 API。</p>
          </div>
        </div>
      </div>

      <div className="studio-welcome-panel__actions">
        <button type="button" className="studio-welcome-panel__primary" onClick={openSettings}>
          {gatewayRequired ? '查看设置 / API' : '查看设置 / Fast/Deep'}
        </button>
        <button type="button" className="studio-welcome-panel__secondary" onClick={createTextCard}>
          创建文本卡片
        </button>
        <button type="button" className="studio-welcome-panel__secondary" onClick={createWritingNode}>
          创建编剧节点
        </button>
      </div>

      <button type="button" className="studio-welcome-panel__dismiss" onClick={() => setDismissed(true)}>
        先收起
      </button>
    </div>
  );
}
