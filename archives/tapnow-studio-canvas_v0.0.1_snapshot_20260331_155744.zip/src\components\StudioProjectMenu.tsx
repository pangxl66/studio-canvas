import { Panel } from '@xyflow/react';
import { saveAs } from 'file-saver';
import { useCallback, useEffect, useRef, type ChangeEvent } from 'react';
import {
  getStudioAutosave,
  parseStudioProjectJsonFile,
  putStudioAutosave,
  stringifyStudioProjectPayload,
  STUDIO_PROJECT_JSON_VERSION,
  type StudioProjectFilePayload,
} from '@/services/studioProjectPersistence';
import { toPersistableNodesAndEdges } from '@/utils/studioNodePersistence';
import { useStudioStore } from '@/store/useStudioStore';

const AUTOSAVE_INTERVAL_MS = 5 * 60 * 1000;

export function StudioProjectMenu() {
  const fileRef = useRef<HTMLInputElement>(null);
  const hydrateProject = useStudioStore((s) => s.hydrateProject);
  const pushMessage = useStudioStore((s) => s.pushMessage);

  const saveProjectToFile = useCallback(() => {
    const { nodes, edges } = useStudioStore.getState();
    const body = stringifyStudioProjectPayload(nodes, edges);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const blob = new Blob([body], { type: 'application/json;charset=utf-8' });
    saveAs(blob, `studio-project-${stamp}.json`);
    pushMessage({
      role: 'broadcast',
      text: `已导出项目文件（${nodes.length} 节点 / ${edges.length} 连线）`,
    });
  }, [pushMessage]);

  const onFileChange = useCallback(
    (e: ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      e.target.value = '';
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        const text = typeof reader.result === 'string' ? reader.result : '';
        const payload = parseStudioProjectJsonFile(text);
        if (!payload) {
          pushMessage({ role: 'system', text: '打开项目：文件格式无效或已损坏，未载入。' });
          return;
        }
        hydrateProject(payload.nodes, payload.edges);
      };
      reader.onerror = () => {
        pushMessage({ role: 'system', text: '打开项目：无法读取所选文件。' });
      };
      reader.readAsText(file, 'UTF-8');
    },
    [hydrateProject, pushMessage],
  );

  const openFilePicker = useCallback(() => {
    const { nodes } = useStudioStore.getState();
    if (nodes.length > 0) {
      const ok = window.confirm(
        '当前画布上已有节点与连线。载入项目将替换为文件中的内容（已登记资产会清空）。是否继续？',
      );
      if (!ok) return;
    }
    fileRef.current?.click();
  }, []);

  const restoreFromAutosave = useCallback(async () => {
    try {
      const payload = await getStudioAutosave();
      if (!payload) {
        pushMessage({ role: 'system', text: '没有可用的自动存档。' });
        return;
      }
      const { nodes } = useStudioStore.getState();
      if (nodes.length > 0) {
        const ok = window.confirm(
          '从自动存档恢复将覆盖当前画布（已登记资产会清空）。是否继续？',
        );
        if (!ok) return;
      }
      const t = new Date(payload.savedAt).toLocaleString();
      hydrateProject(payload.nodes, payload.edges, {
        broadcastText: `已从 IndexedDB 恢复自动存档（保存于 ${t}，${payload.nodes.length} 节点 / ${payload.edges.length} 连线）`,
      });
    } catch (err) {
      console.warn(err);
      pushMessage({ role: 'system', text: '读取自动存档失败（IndexedDB 不可用或被阻止）。' });
    }
  }, [hydrateProject, pushMessage]);

  useEffect(() => {
    const tick = async () => {
      const { nodes, edges } = useStudioStore.getState();
      const { nodes: n2, edges: e2 } = toPersistableNodesAndEdges(nodes, edges);
      const payload: StudioProjectFilePayload = {
        version: STUDIO_PROJECT_JSON_VERSION,
        savedAt: Date.now(),
        nodes: n2,
        edges: e2,
      };
      try {
        await putStudioAutosave(payload);
      } catch (err) {
        console.warn('IndexedDB autosave failed', err);
      }
    };

    const id = window.setInterval(() => {
      void tick();
    }, AUTOSAVE_INTERVAL_MS);
    return () => window.clearInterval(id);
  }, []);

  return (
    <Panel position="top-left" className="studio-project-panel">
      <div className="studio-project-bar nodrag nopan" role="toolbar" aria-label="项目管理">
        <span className="studio-project-bar__title">项目管理</span>
        <button type="button" className="studio-project-bar__btn" onClick={saveProjectToFile}>
          保存项目
        </button>
        <button type="button" className="studio-project-bar__btn" onClick={openFilePicker}>
          打开项目
        </button>
        <button type="button" className="studio-project-bar__btn" onClick={() => void restoreFromAutosave()}>
          从自动存档恢复
        </button>
      </div>
      <input
        ref={fileRef}
        type="file"
        accept=".json,application/json"
        className="studio-project-file-input"
        aria-hidden
        tabIndex={-1}
        onChange={onFileChange}
      />
    </Panel>
  );
}
