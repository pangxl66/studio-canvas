import type { StoryboardOutput, StoryboardShot } from '@/types/studio';
import { createStoryboardShotWireId } from '@/utils/shotListWire';

type WorkbookImportResult = {
  storyboard: StoryboardOutput;
  sheetName: string;
  rowCount: number;
};

type HeaderField =
  | 'sequence'
  | 'shotNo'
  | 'description'
  | 'dialogue'
  | 'sound'
  | 'movement'
  | 'shotType'
  | 'scene'
  | 'role'
  | 'prop'
  | 'note';

type HeaderMap = Record<HeaderField, number>;

const HEADER_ALIASES: Record<HeaderField, string[]> = {
  sequence: ['序号', '编号', '序列', '镜序', '镜次'],
  shotNo: ['镜头号', '镜头编号', '镜号', 'shotno', 'shot', '镜头'],
  description: [
    '制作内容文字描述',
    '制作内容描述',
    '画面内容动作视觉环境',
    '画面内容动作视觉',
    '画面内容',
    '镜头内容',
    '内容描述',
    '文字描述',
    '画面描述',
    '分镜描述',
    '分镜内容',
  ],
  dialogue: ['台词', '对白', '人物对白', '台词对白', '台词音效备注'],
  sound: ['音效bgm', '音效', 'bgm', '音乐', '声音'],
  movement: ['镜头运动', '运镜', '摄影机运动', '机位运动'],
  shotType: ['景别', '景型'],
  scene: ['场景', '场次', '场号', '场别'],
  role: ['角色', '人物', '出场人物', '角色人物'],
  prop: ['道具', '关键道具', '道具服化'],
  note: ['备注', '镜头反馈', '反馈', '补充说明', '说明', '制作备注'],
};

const REQUIRED_HEADER_FIELDS: HeaderField[] = ['description'];

function asText(value: unknown): string {
  return String(value ?? '')
    .replace(/\r/g, '')
    .replace(/\u00a0/g, ' ')
    .trim();
}

function normalizeHeaderText(value: string): string {
  return asText(value)
    .toLowerCase()
    .replace(/[\s|/\\()[\]{}（）【】<>《》:：;；,.，。!！?？'"“”‘’·—_-]+/g, '');
}

function countNonEmptyCells(row: string[]): number {
  return row.filter((cell) => asText(cell)).length;
}

function matchesAlias(normalizedCell: string, alias: string): boolean {
  const normalizedAlias = normalizeHeaderText(alias);
  return Boolean(normalizedCell) && Boolean(normalizedAlias) && normalizedCell.includes(normalizedAlias);
}

function findColumnIndex(row: string[], aliases: string[]): number {
  for (let index = 0; index < row.length; index += 1) {
    const cell = normalizeHeaderText(row[index] ?? '');
    if (aliases.some((alias) => matchesAlias(cell, alias))) {
      return index;
    }
  }
  return -1;
}

function scoreHeaderRow(row: string[]): number {
  const hitFields = new Set<HeaderField>();
  row.forEach((cell) => {
    const normalizedCell = normalizeHeaderText(cell);
    (Object.keys(HEADER_ALIASES) as HeaderField[]).forEach((field) => {
      if (HEADER_ALIASES[field].some((alias) => matchesAlias(normalizedCell, alias))) {
        hitFields.add(field);
      }
    });
  });

  if (!REQUIRED_HEADER_FIELDS.every((field) => hitFields.has(field))) {
    return -1;
  }
  if (!hitFields.has('shotNo') && !hitFields.has('sequence')) {
    return -1;
  }

  let score = hitFields.size * 10;
  if (hitFields.has('description')) score += 30;
  if (hitFields.has('shotNo')) score += 24;
  if (hitFields.has('sequence')) score += 12;
  if (hitFields.has('movement')) score += 8;
  if (hitFields.has('shotType')) score += 8;
  if (countNonEmptyCells(row) >= 4) score += 6;
  return score;
}

function findHeaderIndex(rows: string[][]): number {
  let bestIndex = -1;
  let bestScore = -1;

  rows.forEach((row, index) => {
    const score = scoreHeaderRow(row);
    if (score > bestScore) {
      bestIndex = index;
      bestScore = score;
    }
  });

  return bestIndex;
}

function buildHeaderMap(headerRow: string[]): HeaderMap {
  const sequence = findColumnIndex(headerRow, HEADER_ALIASES.sequence);
  const shotNo = findColumnIndex(headerRow, HEADER_ALIASES.shotNo);

  return {
    sequence,
    shotNo: shotNo >= 0 ? shotNo : sequence,
    description: findColumnIndex(headerRow, HEADER_ALIASES.description),
    dialogue: findColumnIndex(headerRow, HEADER_ALIASES.dialogue),
    sound: findColumnIndex(headerRow, HEADER_ALIASES.sound),
    movement: findColumnIndex(headerRow, HEADER_ALIASES.movement),
    shotType: findColumnIndex(headerRow, HEADER_ALIASES.shotType),
    scene: findColumnIndex(headerRow, HEADER_ALIASES.scene),
    role: findColumnIndex(headerRow, HEADER_ALIASES.role),
    prop: findColumnIndex(headerRow, HEADER_ALIASES.prop),
    note: findColumnIndex(headerRow, HEADER_ALIASES.note),
  };
}

function cell(row: string[], index: number): string {
  if (index < 0 || index >= row.length) return '';
  return asText(row[index]);
}

function extractPositiveInteger(value: string): number | null {
  const direct = Number.parseInt(value, 10);
  if (Number.isFinite(direct) && direct > 0) {
    return direct;
  }

  const matches = value.match(/\d+/g);
  if (!matches?.length) {
    return null;
  }

  const last = Number.parseInt(matches[matches.length - 1], 10);
  return Number.isFinite(last) && last > 0 ? last : null;
}

function normalizeShotId(sequenceText: string, shotNoText: string, fallback: number): number {
  return extractPositiveInteger(sequenceText) ?? extractPositiveInteger(shotNoText) ?? fallback;
}

function isSceneMarkerRow(row: string[]): boolean {
  const nonEmpty = row.filter((item) => asText(item));
  if (nonEmpty.length !== 1) {
    return false;
  }

  const text = nonEmpty[0];
  return /^(第[一二三四五六七八九十百零\d]+场|S\d+|场次\s*\d+)/i.test(text);
}

function buildNarrativeBeats(shots: StoryboardShot[], sheetName: string): string[] {
  const sceneNames = [...new Set(shots.map((shot) => shot.sceneRef?.trim()).filter(Boolean))];
  if (sceneNames.length > 0) {
    return sceneNames.map((sceneName, index) => `场次 ${index + 1}：${sceneName}`);
  }
  return [`已从《${sheetName}》导入 ${shots.length} 条镜头，可继续编辑或直接连接 Prompt 节点。`];
}

function normalizeShot(
  row: string[],
  headerMap: HeaderMap,
  fallbackId: number,
  currentSceneRef: string | null,
): StoryboardShot | null {
  const sequenceText = cell(row, headerMap.sequence);
  const shotNo = cell(row, headerMap.shotNo);
  const description = cell(row, headerMap.description);
  const dialogue = cell(row, headerMap.dialogue);
  const sound = cell(row, headerMap.sound);
  const movement = cell(row, headerMap.movement);
  const shotType = cell(row, headerMap.shotType);
  const scene = cell(row, headerMap.scene) || currentSceneRef || '';
  const role = cell(row, headerMap.role);
  const prop = cell(row, headerMap.prop);
  const noteText = cell(row, headerMap.note);

  if (!sequenceText && !shotNo && !description && !dialogue && !sound) {
    return null;
  }

  const id = normalizeShotId(sequenceText, shotNo, fallbackId);
  const content = [dialogue, sound].filter(Boolean).join('\n');
  const noteParts = [
    shotNo ? `镜号：${shotNo}` : '',
    role ? `角色：${role}` : '',
    prop ? `道具：${prop}` : '',
    noteText ? `备注：${noteText}` : '',
  ].filter(Boolean);

  return {
    id,
    wireId: createStoryboardShotWireId(id),
    type: shotType || '中景',
    movement: movement || '固定',
    description: description || shotNo || `镜头 ${id}`,
    content,
    sceneRef: scene || undefined,
    action: description || undefined,
    note: noteParts.length > 0 ? noteParts.join('\n') : undefined,
  };
}

function rowsToStoryboard(rows: string[][], sheetName: string): WorkbookImportResult {
  const headerIndex = findHeaderIndex(rows);
  if (headerIndex < 0) {
    throw new Error('未识别到可用分镜表头。请确认文件中至少包含镜号/镜头号与画面描述类列。');
  }

  const headerRow = rows[headerIndex].map(asText);
  const headerMap = buildHeaderMap(headerRow);
  if (headerMap.description < 0 || (headerMap.shotNo < 0 && headerMap.sequence < 0)) {
    throw new Error('分镜表缺少关键列，至少需要镜号/镜头号与画面描述类列。');
  }

  let currentSceneRef: string | null = null;
  const shots: StoryboardShot[] = [];

  for (const rawRow of rows.slice(headerIndex + 1)) {
    const row = rawRow.map(asText);
    if (countNonEmptyCells(row) === 0) {
      continue;
    }

    if (isSceneMarkerRow(row)) {
      currentSceneRef = row.find((cellText) => cellText.trim()) ?? currentSceneRef;
      continue;
    }

    const shot = normalizeShot(row, headerMap, shots.length + 1, currentSceneRef);
    if (shot) {
      shots.push(shot);
    }
  }

  if (shots.length === 0) {
    throw new Error('分镜表中没有解析到有效镜头行。');
  }

  return {
    storyboard: {
      shots,
      narrativeBeats: buildNarrativeBeats(shots, sheetName),
    },
    sheetName,
    rowCount: shots.length,
  };
}

export async function parseStoryboardWorkbookFile(file: File): Promise<WorkbookImportResult> {
  const XLSX = await import('xlsx');
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: 'array' });
  const sheetNames = workbook.SheetNames.filter(Boolean);
  if (sheetNames.length === 0) {
    throw new Error('Excel 文件里没有可读取的工作表。');
  }

  let lastError: Error | null = null;
  for (const sheetName of sheetNames) {
    const worksheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<string[]>(worksheet, { header: 1, defval: '' });
    try {
      return rowsToStoryboard(rows.map((row) => row.map(asText)), sheetName);
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
    }
  }

  throw lastError ?? new Error('分镜表文件解析失败，请检查工作表内容。');
}
