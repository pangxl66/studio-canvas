import {
  PROMPT_CARD_HEADER_RULE,
  PROMPT_CARD_SECTION_HEADINGS,
  PROMPT_COPY_CHAR_LIMIT_RULE,
  PROMPT_DEPT_AGENT_SYSTEM,
  PROMPT_DEPT_OUTPUT_SHAPE,
  PROMPT_LEADER_SPEC,
  PROMPT_MOUNT_TOKEN_RULE,
} from '@/agents/promptDeptSpec';
import { tryParseStoryboardOutput } from '@/agents/storyboardAgents';
import { invokeLlmJsonObjectStream, invokeLlmLeaderReview } from '@/services/llmJsonClient';
import { resolveAndComposeMountedSkills } from '@/services/skillLoader';
import type {
  ApprovedAsset,
  PromptOutput,
  PromptShotDimensions,
  PromptShotPack,
  StoryboardOutput,
  StoryboardShot,
} from '@/types/studio';
import { promptAssetRefsFromApproved } from '@/utils/promptAssetRefs';
import { buildSeedanceCard, clampPromptText } from '@/utils/storyboardSeedance';

export {
  PROMPT_DEPT_AGENT_SYSTEM,
  PROMPT_DEPT_OUTPUT_SHAPE,
  PROMPT_LEADER_SPEC,
} from '@/agents/promptDeptSpec';

const DEFAULT_NEG =
  'low quality, blurry, watermark, subtitle, text overlay, logo, deformed hands, extra limbs, flicker, temporal inconsistency, oversaturated';
const MAX_PROMPT_CHARS = 2000;
const MOUNT_TOKEN_RE = /\|@=([^|\n]+)\|/g;

const PROMPT_DIMENSION_KEYS = [
  '场景',
  '角色',
  '动作',
  '情感',
  '镜头',
  '运镜',
  '灯光',
  '风格',
  '构图',
  '连贯性',
] as const;

function normalizePromptDimensions(value: unknown, idx: number): PromptShotDimensions {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`Prompt 模型返回：shotPrompts[${idx}] 缺少完整 dimensions 对象。`);
  }
  const raw = value as Record<string, unknown>;
  const out: PromptShotDimensions = {};
  for (const key of PROMPT_DIMENSION_KEYS) {
    out[key] = typeof raw[key] === 'string' ? String(raw[key]).trim() : '';
  }
  return out;
}

function assertSeedanceCard(shotId: string, seedanceCard: string): string {
  const card = seedanceCard.trim();
  if (!card) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 缺少 seedanceCard。`);
  }
  const firstLine = card
    .split(/\r?\n/)
    .map((line) => line.trim())
    .find(Boolean);
  if (!firstLine?.startsWith('【分镜')) {
    throw new Error(
      `Prompt 模型返回：镜头 ${shotId} 的 seedanceCard 首行不是结构化标题。${PROMPT_CARD_HEADER_RULE}`,
    );
  }
  const missing = PROMPT_CARD_SECTION_HEADINGS.filter((heading) => !card.includes(heading));
  if (missing.length) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 seedanceCard 缺少固定栏位：${missing.join('、')}。`);
  }
  if (!card.includes('9:16') || !card.includes('16:9')) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的 seedanceCard 缺少 9:16 或 16:9 双版本构图。`);
  }
  const mountSection = card.match(/挂载[\s\S]*?(?:\n\s*\n|相机位置|相机朝向|角色朝向|构图锚点)/)?.[0] ?? '';
  const mountTokens = Array.from(mountSection.matchAll(MOUNT_TOKEN_RE))
    .map((match) => String(match[1] ?? '').trim())
    .filter(Boolean);
  if (mountTokens.length < 2) {
    throw new Error(`Prompt 模型返回：镜头 ${shotId} 的挂载区不合格。${PROMPT_MOUNT_TOKEN_RULE}`);
  }
  return card;
}

function parsePromptShotPackList(raw: unknown): PromptShotPack[] {
  if (!Array.isArray(raw) || raw.length === 0) {
    throw new Error('Prompt 模型返回：必须包含非空 `shotPrompts` 数组。');
  }
  return raw.map((item, idx) => {
    if (!item || typeof item !== 'object') {
      throw new Error(`Prompt 模型返回：shotPrompts[${idx}] 必须是对象。`);
    }
    const row = item as Record<string, unknown>;
    const shot_id = String(row.shot_id ?? row.shotId ?? '').trim();
    const prompt = clampPromptText(String(row.prompt ?? '').trim(), MAX_PROMPT_CHARS);
    const negative_prompt =
      String(row.negative_prompt ?? row.negativePrompt ?? DEFAULT_NEG).trim() || DEFAULT_NEG;
    if (!shot_id) {
      throw new Error(`Prompt 模型返回：shotPrompts[${idx}] 缺少 shot_id。`);
    }
    if (!prompt) {
      throw new Error(`Prompt 模型返回：shotPrompts[${idx}] 缺少 prompt。`);
    }
    const dimensions = normalizePromptDimensions(row.dimensions, idx);
    const character_asset_ids = Array.isArray(row.character_asset_ids)
      ? row.character_asset_ids.map((value) => String(value))
      : [];
    const scene_asset_ids = Array.isArray(row.scene_asset_ids)
      ? row.scene_asset_ids.map((value) => String(value))
      : [];
    return {
      shot_id,
      prompt,
      negative_prompt,
      dimensions,
      character_asset_ids,
      scene_asset_ids,
      seedanceCard: typeof row.seedanceCard === 'string' ? row.seedanceCard : '',
    };
  });
}

export function assertPromptOutput(value: unknown): PromptOutput {
  if (!value || typeof value !== 'object') {
    throw new Error('Prompt 模型返回：顶层必须是 JSON 对象。');
  }
  const raw = value as Record<string, unknown>;
  if (typeof raw.system !== 'string' || !raw.system.trim()) {
    throw new Error('Prompt 模型返回：缺少非空 `system`。');
  }
  if (typeof raw.userTemplate !== 'string') {
    throw new Error('Prompt 模型返回：缺少 `userTemplate`。');
  }
  if (!raw.parameters || typeof raw.parameters !== 'object' || Array.isArray(raw.parameters)) {
    throw new Error('Prompt 模型返回：缺少 `parameters` 对象。');
  }
  const parameters: Record<string, string> = {};
  for (const [key, item] of Object.entries(raw.parameters as Record<string, unknown>)) {
    parameters[key] = item == null ? '' : String(item);
  }
  const negative =
    typeof raw.negative === 'string' && raw.negative.trim() ? raw.negative.trim() : DEFAULT_NEG;
  return {
    system: raw.system.trim(),
    userTemplate: raw.userTemplate,
    negative,
    parameters,
    shotPrompts: parsePromptShotPackList(raw.shotPrompts),
  };
}

function normalizeShotIdToken(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return '';
  const digits = trimmed.match(/\d+/g)?.join('-') ?? '';
  return digits || trimmed.toLowerCase();
}

function tryParseStoryboardFromInputText(raw: string): StoryboardOutput | null {
  const trimmed = raw.trim();
  const direct = tryParseStoryboardOutput(trimmed);
  if (direct) return direct;
  try {
    return tryParseStoryboardOutput(JSON.parse(trimmed));
  } catch {
    const objectStart = trimmed.indexOf('{');
    const objectEnd = trimmed.lastIndexOf('}');
    if (objectStart !== -1 && objectEnd > objectStart) {
      try {
        return tryParseStoryboardOutput(JSON.parse(trimmed.slice(objectStart, objectEnd + 1)));
      } catch {
        return null;
      }
    }
    return null;
  }
}

function findSourceShot(sourceStoryboard: StoryboardOutput | null, pack: PromptShotPack, index: number): StoryboardShot | null {
  if (!sourceStoryboard?.shots?.length) return null;
  const targetToken = normalizeShotIdToken(pack.shot_id);
  return (
    sourceStoryboard.shots.find((shot) => normalizeShotIdToken(String(shot.id)) === targetToken) ??
    sourceStoryboard.shots[index] ??
    null
  );
}

function normalizePromptOutput(output: PromptOutput, sourceStoryboard: StoryboardOutput | null): PromptOutput {
  const shotPrompts = (output.shotPrompts ?? []).map((pack, index) => {
    const prompt = clampPromptText(pack.prompt, MAX_PROMPT_CHARS);
    const sourceShot = findSourceShot(sourceStoryboard, pack, index);
    const normalizedPack: PromptShotPack = {
      ...pack,
      shot_id: sourceShot ? String(sourceShot.id) : pack.shot_id,
      prompt,
    };
    if (sourceShot) {
      normalizedPack.seedanceCard = buildSeedanceCard(sourceShot, normalizedPack);
    } else {
      normalizedPack.seedanceCard = assertSeedanceCard(pack.shot_id, pack.seedanceCard ?? '');
    }
    return normalizedPack;
  });
  return {
    ...output,
    shotPrompts,
  };
}

function validatePromptCoverage(output: PromptOutput, sourceStoryboard: StoryboardOutput | null): void {
  if (!sourceStoryboard?.shots?.length) return;
  const expected = sourceStoryboard.shots.map((shot) => String(shot.id));
  const actual = output.shotPrompts?.map((shot) => shot.shot_id) ?? [];
  if (actual.length !== expected.length) {
    throw new Error(
      `Prompt 输出镜头数量不完整：镜头表共 ${expected.length} 条镜头，但当前仅生成了 ${actual.length} 条。`,
    );
  }
  const expectedSet = new Set(expected.map(normalizeShotIdToken));
  const actualSet = new Set(actual.map(normalizeShotIdToken));
  for (const id of expectedSet) {
    if (!actualSet.has(id)) {
      throw new Error('Prompt 输出镜头编号不完整：未覆盖镜头表中的全部镜头。');
    }
  }
  for (const pack of output.shotPrompts ?? []) {
    if (Array.from(pack.prompt).length > MAX_PROMPT_CHARS) {
      throw new Error(`Prompt 输出超出字数限制：镜头 ${pack.shot_id} 的提示词超过 2000 字。`);
    }
    assertSeedanceCard(pack.shot_id, pack.seedanceCard ?? '');
  }
}

function buildPromptUserMessage(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput | null,
): string {
  const sourceShotHints =
    sourceStoryboard?.shots?.length
      ? [
          `【源镜头总数】${sourceStoryboard.shots.length}`,
          `【源镜头编号】${sourceStoryboard.shots.map((shot) => shot.id).join(', ')}`,
          '【硬性要求】你必须为每一条源镜头各生成一条 shotPrompts 项，数量必须与源镜头完全一致，不得只输出第一条镜头。',
        ].join('\n')
      : '';
  return [
    '以下是部门 Input 正文，可能是镜头表 JSON，也可能是自然语言补充。请输出完整 PromptOutput JSON。',
    '',
    '【模板硬约束】',
    PROMPT_CARD_HEADER_RULE,
    PROMPT_MOUNT_TOKEN_RULE,
    PROMPT_COPY_CHAR_LIMIT_RULE,
    '空镜、环境镜、道具镜、无人物镜头里，不要写眼神、微表情、角色朝向等人物描述。',
    `seedanceCard 必须按以下顺序完整包含栏位：${PROMPT_CARD_SECTION_HEADINGS.join('、')}。`,
    '“【双版本构图】”内必须同时出现 9:16 与 16:9。',
    '“提示词(复制到即梦)”必须是可直接复制执行的中文主导版本。',
    '“【目标物 Must-Show】”“【声音/氛围】”“【微表情】”“【文戏附加】”“【钉子4行】”不得缺失。',
    '',
    '【定稿依据】若 Input 含 JSON 字段 `shots`，其中每条镜头的 `description`、`content` 均视为最终定稿，生成时必须逐镜落实。',
    '【同场合并】若某条镜头含 `mergedMembers`，对应项中的 `prompt` 与 `seedanceCard` 都要明确写出镜头1 / 镜头2 / 镜头3 的连续推进。',
    sourceShotHints,
    '',
    '【资产占位 ID】请为各 shot 写入 `character_asset_ids` / `scene_asset_ids`；没有真实 ID 时可留空数组，但键不可缺失。',
    JSON.stringify(assetRefs, null, 2),
    '',
    '--- Input ---',
    brief.trim() || '（空）',
  ]
    .filter(Boolean)
    .join('\n');
}

function buildCoverageRepairUserMessage(
  brief: string,
  assetRefs: unknown,
  sourceStoryboard: StoryboardOutput,
  invalidOutput: PromptOutput,
): string {
  const invalidShotPrompts = invalidOutput.shotPrompts ?? [];
  return [
    '你上一次返回的 PromptOutput 不完整，请重新输出完整 JSON。',
    `【必须覆盖的镜头总数】${sourceStoryboard.shots.length}`,
    `【必须覆盖的镜头编号】${sourceStoryboard.shots.map((shot) => shot.id).join(', ')}`,
    `【上一次返回的镜头编号】${invalidShotPrompts.map((shot) => shot.shot_id).join(', ')}`,
    '硬性要求：',
    '1. shotPrompts.length 必须等于源镜头数。',
    '2. 每一条源镜头都必须有对应 shot_id。',
    '3. 每个 shot 都必须带完整 seedanceCard，不得缺少固定栏位。',
    `4. “挂载”必须符合这条规则：${PROMPT_MOUNT_TOKEN_RULE}`,
    `5. “提示词(复制到即梦)”必须符合这条规则：${PROMPT_COPY_CHAR_LIMIT_RULE}`,
    '6. 空镜/无人物镜头不得出现眼神、微表情、角色朝向等人物描述。',
    '7. 不得返回解释文本、markdown 或半截 JSON。',
    '',
    '【固定栏位】',
    PROMPT_CARD_SECTION_HEADINGS.join('、'),
    '',
    '【资产占位 ID】',
    JSON.stringify(assetRefs, null, 2),
    '',
    '【源镜头表】',
    JSON.stringify(sourceStoryboard, null, 2),
    '',
    '【上一次不完整的输出】',
    JSON.stringify(invalidOutput, null, 2),
    '',
    '【原始 Input】',
    brief.trim() || '（空）',
  ].join('\n');
}

export async function runPromptEmployee(
  brief: string,
  approvedAssets: ApprovedAsset[] = [],
  executionSystemPrompt?: string,
  onDelta?: (delta: string, accumulated: string) => void,
  signal?: AbortSignal,
): Promise<PromptOutput> {
  const assetRefs = promptAssetRefsFromApproved(approvedAssets);
  const sourceStoryboard = tryParseStoryboardFromInputText(brief);
  const systemBase = executionSystemPrompt?.trim() || PROMPT_DEPT_AGENT_SYSTEM;
  const systemPrompt = `${systemBase}\n\n【输出 JSON 形状参考】\n${PROMPT_DEPT_OUTPUT_SHAPE}`;

  const firstParsed = await invokeLlmJsonObjectStream({
    systemPrompt,
    userPrompt: buildPromptUserMessage(brief, assetRefs, sourceStoryboard),
    temperature: 0.35,
    onDelta,
    signal,
  });

  let output = normalizePromptOutput(assertPromptOutput(firstParsed), sourceStoryboard);

  try {
    validatePromptCoverage(output, sourceStoryboard);
    return output;
  } catch (error) {
    if (!sourceStoryboard?.shots?.length) throw error;
    const repairedParsed = await invokeLlmJsonObjectStream({
      systemPrompt,
      userPrompt: buildCoverageRepairUserMessage(brief, assetRefs, sourceStoryboard, output),
      temperature: 0.2,
      onDelta,
      signal,
    });
    output = normalizePromptOutput(assertPromptOutput(repairedParsed), sourceStoryboard);
    validatePromptCoverage(output, sourceStoryboard);
    return output;
  }
}

export type LeaderDecision = { approved: true } | { approved: false; feedback: string };

export async function runPromptLeaderReview(
  output: PromptOutput,
  orderedSkillIds: string[] = [],
  signal?: AbortSignal,
): Promise<LeaderDecision> {
  const { systemPrompt } = resolveAndComposeMountedSkills('prompt', PROMPT_LEADER_SPEC, orderedSkillIds);
  const result = await invokeLlmLeaderReview({
    systemPrompt,
    userPrompt: `以下为员工产出的 PromptOutput JSON，请按 Prompt 总监规范审核，重点检查挂载实体标记、自适应合理性、字数限制与即梦执行性：\n\n${JSON.stringify(output, null, 2)}`,
    temperature: 0.2,
    signal,
  });
  return result.approved
    ? { approved: true }
    : { approved: false, feedback: result.feedback ?? '请按审核意见补齐缺失栏位并提高制作可执行性。' };
}
