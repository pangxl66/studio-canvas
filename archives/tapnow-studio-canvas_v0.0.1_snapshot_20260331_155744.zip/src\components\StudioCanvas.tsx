import {
  Background,
  BackgroundVariant,
  ConnectionMode,
  Controls,
  MiniMap,
  Panel,
  ReactFlow,
  SelectionMode,
  useReactFlow,
  type CoordinateExtent,
  type Edge,
  type NodeTypes,
  type OnConnectEnd,
  type OnConnectStart,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type MouseEvent as ReactMouseEvent,
} from 'react';
import {
  ConnectEndBinder,
  type ConnectionDragStart,
  type NodePickerState,
} from '@/components/ConnectEndBinder';
import { ChatDock } from '@/components/ChatDock';
import {
  DepartmentNode,
  DEPT_INPUT_HANDLE_ID,
  DEPT_INPUT_PULL_HANDLE_ID,
  DEPT_OUTPUT_HANDLE_ID,
} from '@/components/DepartmentNode';
import { StoryboardFileNode } from '@/components/StoryboardFileNode';
import { ShotListNode } from '@/components/ShotListNode';
import { TextNode, TEXT_NODE_OUTPUT_HANDLE_ID } from '@/components/TextNode';
import { CanvasLayoutButton } from '@/components/CanvasLayoutButton';
import { DetailPanel } from '@/components/DetailPanel';
import { NodeContextMenu, type ContextMenuState } from '@/components/NodeContextMenu';
import { ScissorCutLayer } from '@/components/ScissorCutLayer';
import { StudioErrorBoundary } from '@/components/StudioErrorBoundary';
import { StudioProjectMenu } from '@/components/StudioProjectMenu';
import { StudioSettings } from '@/components/StudioSettings';
import { StudioWelcomePanel } from '@/components/StudioWelcomePanel';
import { useStudioStore } from '@/store/useStudioStore';
import type { StudioRFNode } from '@/types/reactFlow';
import {
  SHOT_LIST_LINK_HANDLE_ID,
  SHOT_LIST_PARENT_HANDLE_ID,
  isShotListItemOutputHandleId,
} from '@/utils/shotListWire';

const nodeTypes: NodeTypes = {
  department: DepartmentNode,
  textNode: TextNode,
  shotList: ShotListNode,
  storyboardFile: StoryboardFileNode,
};

type CreateNodeKind = 'text_node' | 'storyboard_file_node' | 'writing' | 'storyboard' | 'prompt';

type NodeGalleryItem = {
  id: string;
  kind?: CreateNodeKind;
  title: string;
  subtitle: string;
  badge: string;
  accentClass: string;
  icon: string;
  disabled?: boolean;
};

const PANE_GALLERY_ITEMS: NodeGalleryItem[] = [
  {
    id: 'text_node',
    kind: 'text_node',
    title: '文本卡片',
    subtitle: '粘贴原文、台词、批注或任何临时素材。',
    badge: '基础输入',
    accentClass: 'node-picker__card--text',
    icon: 'T',
  },
  {
    id: 'writing',
    kind: 'writing',
    title: '编剧部',
    subtitle: '把文本整理成结构化场次和剧情节拍。',
    badge: '剧情拆解',
    accentClass: 'node-picker__card--writing',
    icon: '剧',
  },
  {
    id: 'storyboard',
    kind: 'storyboard',
    title: '分镜部',
    subtitle: '把剧本拆成镜头，并自动生成镜头表。',
    badge: '镜头设计',
    accentClass: 'node-picker__card--storyboard',
    icon: '镜',
  },
  {
    id: 'prompt',
    kind: 'prompt',
    title: '提示词部',
    subtitle: '把分镜或文本转成视频生成提示词包。',
    badge: '生成提示',
    accentClass: 'node-picker__card--prompt',
    icon: 'P',
  },
  {
    id: 'storyboard_file_node',
    kind: 'storyboard_file_node',
    title: '分镜表文件',
    subtitle: '导入 Excel 分镜表，直接作为 Prompt 的上游输入。',
    badge: '文件导入',
    accentClass: 'node-picker__card--storyboard',
    icon: 'X',
  },
  {
    id: 'shot_list',
    title: '镜头表',
    subtitle: '由分镜执行后自动生成，也可作为 Prompt 的上游资产。',
    badge: '自动生成',
    accentClass: 'node-picker__card--shot-list',
    icon: '表',
    disabled: true,
  },
];

/** 与 Miro / Tapnow 一致：平移与放置节点均无边界限制 */
const INFINITE_EXTENT: CoordinateExtent = [
  [Number.NEGATIVE_INFINITY, Number.NEGATIVE_INFINITY],
  [Number.POSITIVE_INFINITY, Number.POSITIVE_INFINITY],
];

export function StudioCanvas() {
  const nodes = useStudioStore((s) => s.nodes);
  const nodeCount = nodes.length;

  // 仅在新节点进入画布时补绑 onExecute/onDelete；不在此跑 reconcile（全图 resync 会级联 patch，易触发 Maximum update depth）
  useEffect(() => {
    useStudioStore.getState().ensureRuntimeBindingsOnNodes();
  }, [nodeCount]);
  const edges = useStudioStore((s) => s.edges);
  const onNodesChange = useStudioStore((s) => s.onNodesChange);
  const onConnect = useStudioStore((s) => s.onConnect);
  const onEdgesChange = useStudioStore((s) => s.onEdgesChange);
  const completeConnectionMenuPick = useStudioStore((s) => s.completeConnectionMenuPick);
  const removeEdges = useStudioStore((s) => s.removeEdges);
  const setSelected = useStudioStore((s) => s.setSelected);
  const addDepartmentNode = useStudioStore((s) => s.addDepartmentNode);
  const addTextNode = useStudioStore((s) => s.addTextNode);
  const addStoryboardFileNode = useStudioStore((s) => s.addStoryboardFileNode);
  const startStoryboardPipeline = useStudioStore((s) => s.startStoryboardPipeline);
  const focusNode = useStudioStore((s) => s.focusNode);

  const [nodePicker, setNodePicker] = useState<NodePickerState | null>(null);
  const [paneMenuSeed, setPaneMenuSeed] = useState<{ screenX: number; screenY: number } | null>(null);
  const [paneCreateMenu, setPaneCreateMenu] = useState<{
    screenX: number;
    screenY: number;
    flowX: number;
    flowY: number;
  } | null>(null);
  const [contextMenu, setContextMenu] = useState<ContextMenuState>(null);
  const [selectedEdgeIds, setSelectedEdgeIds] = useState<string[]>([]);
  const connectEndImplRef = useRef<OnConnectEnd>(() => {});
  const connectionDragRef = useRef<ConnectionDragStart | null>(null);
  const lastPaneClickRef = useRef<{ ts: number; x: number; y: number } | null>(null);

  const shotListOutputPanePicker =
    Boolean(nodePicker) &&
    nodes.find((n) => n.id === nodePicker!.fromNodeId)?.type === 'shotList' &&
    (nodePicker!.fromHandleId === DEPT_OUTPUT_HANDLE_ID ||
      isShotListItemOutputHandleId(nodePicker!.fromHandleId)) &&
    nodePicker!.fromHandleType === 'source';
  const onConnectStart = useCallback<OnConnectStart>((_e, p) => {
    connectionDragRef.current = {
      nodeId: p.nodeId,
      handleId: p.handleId,
      handleType: p.handleType,
    };
  }, []);

  const onConnectEndOuter = useCallback<OnConnectEnd>((event, cs) => {
    connectEndImplRef.current(event, cs);
  }, []);

  const onNodeClick = useCallback(
    (_: ReactMouseEvent, n: StudioRFNode) => {
      lastPaneClickRef.current = null;
      setContextMenu(null);
      setPaneCreateMenu(null);
      focusNode(n.id, { openDetail: n.type === 'department' || n.type === 'shotList' });
    },
    [focusNode],
  );

  const onNodeContextMenu = useCallback((e: ReactMouseEvent, n: StudioRFNode) => {
    lastPaneClickRef.current = null;
    e.preventDefault();
    setPaneCreateMenu(null);
    setContextMenu({ x: e.clientX, y: e.clientY, node: n });
  }, []);

  const onNodeDoubleClick = useCallback(
    (_: ReactMouseEvent, n: StudioRFNode) => {
      if (n.type === 'textNode') {
        useStudioStore.getState().focusNode(n.id, { openDetail: true });
      }
    },
    [],
  );

  const onPaneClick = useCallback((e: ReactMouseEvent) => {
    const now = Date.now();
    const prev = lastPaneClickRef.current;
    const distance =
      prev == null ? Number.POSITIVE_INFINITY : Math.hypot(e.clientX - prev.x, e.clientY - prev.y);
    const isSyntheticDoubleClick = prev != null && now - prev.ts <= 280 && distance <= 18;

    setSelected(null);
    setNodePicker(null);
    setContextMenu(null);
    setSelectedEdgeIds([]);
    if (!isSyntheticDoubleClick) {
      lastPaneClickRef.current = { ts: now, x: e.clientX, y: e.clientY };
      setPaneCreateMenu(null);
      return;
    }
    lastPaneClickRef.current = null;
    setPaneMenuSeed({ screenX: e.clientX, screenY: e.clientY });
    setPaneCreateMenu(null);
  }, [setSelected]);

  const onSelectionChange = useCallback(({ edges }: { nodes: StudioRFNode[]; edges: Edge[] }) => {
    setSelectedEdgeIds(edges.map((e) => e.id));
  }, []);

  const onEdgesDelete = useCallback((deleted: Edge[]) => {
    const gone = new Set(deleted.map((e) => e.id));
    setSelectedEdgeIds((prev) => prev.filter((id) => !gone.has(id)));
  }, []);

  useEffect(() => {
    if (!nodePicker) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setNodePicker(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [nodePicker]);

  useEffect(() => {
    if (!paneCreateMenu) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setPaneCreateMenu(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [paneCreateMenu]);

  const createNodeFromPaneMenu = useCallback(
    (kind: CreateNodeKind) => {
      if (!paneCreateMenu) return;
      const pos = { x: paneCreateMenu.flowX, y: paneCreateMenu.flowY };
      let id: string;
      if (kind === 'text_node') {
        id = addTextNode('', pos);
        setPaneCreateMenu(null);
        focusNode(id, { openDetail: true });
        return;
      }
      if (kind === 'storyboard_file_node') {
        id = addStoryboardFileNode(pos);
        setPaneCreateMenu(null);
        focusNode(id, { openDetail: false });
        return;
      }
      if (kind === 'storyboard') {
        id = startStoryboardPipeline(pos);
        setPaneCreateMenu(null);
        focusNode(id);
        return;
      }
      id = addDepartmentNode(kind, pos);
      setPaneCreateMenu(null);
      focusNode(id);
    },
    [addDepartmentNode, addStoryboardFileNode, addTextNode, focusNode, paneCreateMenu, startStoryboardPipeline],
  );

  return (
    <div className="studio-canvas">
      <StudioErrorBoundary>
      <ReactFlow
        colorMode="dark"
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onEdgesDelete={onEdgesDelete}
        onConnect={onConnect}
        onConnectStart={onConnectStart}
        onConnectEnd={onConnectEndOuter}
        connectionMode={ConnectionMode.Loose}
        connectionDragThreshold={0}
        isValidConnection={(edge) => {
          const src = edge.source;
          const tgt = edge.target;
          if (!src || !tgt || src === tgt) return false;
          const state = useStudioStore.getState();
          const a = state.nodes.find((x) => x.id === src);
          const b = state.nodes.find((x) => x.id === tgt);
          if (!a || !b) return false;

          if (a.type === 'department' && edge.sourceHandle === DEPT_INPUT_PULL_HANDLE_ID) {
            return false;
          }

          if (a.type === 'textNode' && b.type === 'department') {
            if (edge.targetHandle != null && edge.targetHandle !== DEPT_INPUT_HANDLE_ID) return false;
            if (edge.sourceHandle != null && edge.sourceHandle !== TEXT_NODE_OUTPUT_HANDLE_ID) return false;
            return true;
          }

          if (a.type === 'textNode' && b.type === 'textNode') {
            if (edge.targetHandle != null && edge.targetHandle !== DEPT_INPUT_HANDLE_ID) return false;
            if (edge.sourceHandle != null && edge.sourceHandle !== TEXT_NODE_OUTPUT_HANDLE_ID) return false;
            return true;
          }

          if (a.type === 'department' && b.type === 'textNode') {
            if (edge.sourceHandle != null && edge.sourceHandle !== DEPT_OUTPUT_HANDLE_ID) return false;
            if (edge.targetHandle != null && edge.targetHandle !== DEPT_INPUT_HANDLE_ID) return false;
            return true;
          }

          if (a.type === 'department' && b.type === 'department') {
            if (edge.sourceHandle != null && edge.sourceHandle !== DEPT_OUTPUT_HANDLE_ID) return false;
            if (edge.targetHandle != null && edge.targetHandle !== DEPT_INPUT_HANDLE_ID) return false;
            const ak = a.data.type;
            const bk = b.data.type;
            if (ak === 'writing' && bk === 'storyboard') return true;
            if (ak === 'writing' && bk === 'prompt') return true;
            return false;
          }

          if (a.type === 'shotList' && b.type === 'department') {
            if (b.data.type !== 'prompt') return false;
            if (
              edge.sourceHandle != null &&
              edge.sourceHandle !== DEPT_OUTPUT_HANDLE_ID &&
              !isShotListItemOutputHandleId(edge.sourceHandle)
            ) {
              return false;
            }
            if (edge.targetHandle != null && edge.targetHandle !== DEPT_INPUT_HANDLE_ID) return false;
            if (a.data.type !== 'shot_list_node') return false;
            return true;
          }

          if (a.type === 'department' && b.type === 'shotList') {
            if (a.data.type !== 'storyboard') return false;
            if (edge.sourceHandle !== SHOT_LIST_LINK_HANDLE_ID) return false;
            if (edge.targetHandle != null && edge.targetHandle !== SHOT_LIST_PARENT_HANDLE_ID) {
              return false;
            }
            return true;
          }

          return false;
        }}
        nodeTypes={nodeTypes}
        onNodeClick={onNodeClick}
        onNodeContextMenu={onNodeContextMenu}
        onNodeDoubleClick={onNodeDoubleClick}
        onPaneClick={onPaneClick}
        onSelectionChange={onSelectionChange}
        defaultEdgeOptions={{ selectable: true }}
        fitView
        fitViewOptions={{ maxZoom: 1.24, padding: 0.18 }}
        translateExtent={INFINITE_EXTENT}
        nodeExtent={INFINITE_EXTENT}
        minZoom={0.04}
        maxZoom={4}
        zoomOnScroll
        zoomOnPinch
        zoomOnDoubleClick={false}
        panOnScroll={false}
        panOnDrag={[1]}
        panActivationKeyCode="Space"
        selectionOnDrag
        selectionMode={SelectionMode.Partial}
        multiSelectionKeyCode="Shift"
        deleteKeyCode={['Delete', 'Backspace']}
        elementsSelectable
        proOptions={{ hideAttribution: true }}
      >
        <ConnectEndBinder
          implRef={connectEndImplRef}
          dragStartRef={connectionDragRef}
          setPicker={setNodePicker}
        />
        <PaneCreateMenuBinder seed={paneMenuSeed} onResolve={setPaneCreateMenu} onConsume={() => setPaneMenuSeed(null)} />
        <StudioProjectMenu />
        <Panel position="top-center" className="studio-edge-panel">
          {selectedEdgeIds.length > 0 ? (
            <button
              type="button"
              className="studio-edge-panel__disconnect nodrag nopan"
              onClick={() => {
                removeEdges(selectedEdgeIds);
                setSelectedEdgeIds([]);
              }}
            >
              断开连线（{selectedEdgeIds.length}）
            </button>
          ) : null}
        </Panel>
        <Background
          id="dot-grid"
          variant={BackgroundVariant.Dots}
          gap={18}
          size={1.2}
          color="rgba(255,255,255,0.07)"
        />
        <Controls className="studio-controls" showInteractive={false} />
        <MiniMap className="studio-minimap" maskColor="rgba(0,0,0,0.55)" nodeColor={() => '#3d3d46'} />
        <CanvasLayoutButton />
        <ScissorCutLayer />
        <StudioSettings />
        <ChatDock />
      </ReactFlow>
      <StudioWelcomePanel />
      <NodeContextMenu menu={contextMenu} onClose={() => setContextMenu(null)} />
      {nodePicker ? (
        <div
          className="node-picker"
          style={{ left: nodePicker.screenX, top: nodePicker.screenY }}
          role="dialog"
          aria-label="节点选择"
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => e.stopPropagation()}
        >
          <div className="node-picker__title">
            {shotListOutputPanePicker
              ? '镜头表 Output · 创建下游 Prompt 并连线'
              : '拉线至空白 · 创建节点并连线'}
          </div>
          {!shotListOutputPanePicker ? (
            <>
              <button
                type="button"
                className="node-picker__btn"
                onClick={() => {
                  const p = nodePicker;
                  const nid = completeConnectionMenuPick({
                    fromNodeId: p.fromNodeId,
                    fromHandleId: p.fromHandleId,
                    fromHandleType: p.fromHandleType,
                    pick: 'text_node',
                    flowPosition: { x: p.flowX, y: p.flowY },
                  });
                  if (nid) {
                    setNodePicker(null);
                    focusNode(nid, { openDetail: true });
                  }
                }}
              >
                创建文本卡片
              </button>
              <button
                type="button"
                className="node-picker__btn"
                onClick={() => {
                  const p = nodePicker;
                  const nid = completeConnectionMenuPick({
                    fromNodeId: p.fromNodeId,
                    fromHandleId: p.fromHandleId,
                    fromHandleType: p.fromHandleType,
                    pick: 'writing',
                    flowPosition: { x: p.flowX, y: p.flowY },
                  });
                  if (nid) {
                    setNodePicker(null);
                    focusNode(nid, { openDetail: true });
                  }
                }}
              >
                创建编剧部
              </button>
              <button
                type="button"
                className="node-picker__btn"
                onClick={() => {
                  const p = nodePicker;
                  const nid = completeConnectionMenuPick({
                    fromNodeId: p.fromNodeId,
                    fromHandleId: p.fromHandleId,
                    fromHandleType: p.fromHandleType,
                    pick: 'storyboard',
                    flowPosition: { x: p.flowX, y: p.flowY },
                  });
                  if (nid) {
                    setNodePicker(null);
                    focusNode(nid, { openDetail: true });
                  }
                }}
              >
                创建分镜部
              </button>
              <button
                type="button"
                className="node-picker__btn"
                onClick={() => {
                  const p = nodePicker;
                  const nid = completeConnectionMenuPick({
                    fromNodeId: p.fromNodeId,
                    fromHandleId: p.fromHandleId,
                    fromHandleType: p.fromHandleType,
                    pick: 'storyboard_file_node',
                    flowPosition: { x: p.flowX, y: p.flowY },
                  });
                  if (nid) {
                    setNodePicker(null);
                    focusNode(nid, { openDetail: false });
                  }
                }}
              >
                鍒涘缓鍒嗛暅琛ㄦ枃浠?
              </button>
            </>
          ) : null}
          <button
            type="button"
            className="node-picker__btn"
            onClick={() => {
              const p = nodePicker;
              const nid = completeConnectionMenuPick({
                fromNodeId: p.fromNodeId,
                fromHandleId: p.fromHandleId,
                fromHandleType: p.fromHandleType,
                pick: 'prompt',
                flowPosition: { x: p.flowX, y: p.flowY },
              });
              if (nid) {
                setNodePicker(null);
                focusNode(nid, { openDetail: true });
              }
            }}
          >
            创建 Prompt 部
          </button>
          <button type="button" className="node-picker__dismiss" onClick={() => setNodePicker(null)}>
            取消
          </button>
        </div>
      ) : null}
      {paneCreateMenu ? (
        <NodeGalleryMenu
          x={paneCreateMenu.screenX}
          y={paneCreateMenu.screenY}
          items={PANE_GALLERY_ITEMS}
          onPick={(kind) => createNodeFromPaneMenu(kind)}
        />
      ) : null}
      {false && paneCreateMenu ? (
        <div
          className="node-picker"
          style={{ left: paneCreateMenu?.screenX ?? 0, top: paneCreateMenu?.screenY ?? 0 }}
          role="dialog"
          aria-label="快速创建节点"
          onClick={(e) => e.stopPropagation()}
          onPointerDown={(e) => e.stopPropagation()}
        >
          <div className="node-picker__title">双击空白处 · 快速创建</div>
          <button type="button" className="node-picker__btn" onClick={() => createNodeFromPaneMenu('text_node')}>
            创建文本卡片
          </button>
          <button type="button" className="node-picker__btn" onClick={() => createNodeFromPaneMenu('writing')}>
            创建编剧部
          </button>
          <button type="button" className="node-picker__btn" onClick={() => createNodeFromPaneMenu('storyboard')}>
            创建分镜部
          </button>
          <button type="button" className="node-picker__btn" onClick={() => createNodeFromPaneMenu('prompt')}>
            创建 Prompt 部
          </button>
          <button type="button" className="node-picker__dismiss" onClick={() => setPaneCreateMenu(null)}>
            取消
          </button>
        </div>
      ) : null}
      <DetailPanel />
      </StudioErrorBoundary>
    </div>
  );
}

function NodeGalleryMenu({
  x,
  y,
  items,
  onPick,
}: {
  x: number;
  y: number;
  items: NodeGalleryItem[];
  onPick: (kind: CreateNodeKind) => void;
}) {
  const orbitItems = items.filter((item): item is NodeGalleryItem & { kind: CreateNodeKind } => Boolean(item.kind));
  const radius = 84;
  const angleStep = 360 / Math.max(orbitItems.length, 1);

  return (
    <div
      className="node-picker node-picker--radial"
      style={{ left: x, top: y }}
      role="dialog"
      aria-label="节点快捷菜单"
      onClick={(e) => e.stopPropagation()}
      onPointerDown={(e) => e.stopPropagation()}
    >
      <div className="node-picker__radial-core" aria-hidden />
      {orbitItems.map((item, index) => {
        const angleDeg = -90 + index * angleStep;
        const radians = (angleDeg * Math.PI) / 180;
        const tx = Math.cos(radians) * radius;
        const ty = Math.sin(radians) * radius;

        return (
          <button
            key={item.id}
            type="button"
            className={`node-picker__orbit-btn ${item.accentClass}`}
            style={
              {
                '--orbit-x': `${tx.toFixed(1)}px`,
                '--orbit-y': `${ty.toFixed(1)}px`,
                '--orbit-delay': `${index * 45}ms`,
              } as CSSProperties
            }
            title={item.title}
            aria-label={item.title}
            onClick={() => onPick(item.kind)}
          >
            <span className="node-picker__orbit-icon" aria-hidden>
              {item.icon}
            </span>
          </button>
        );
      })}
    </div>
  );
}

function PaneCreateMenuBinder({
  seed,
  onResolve,
  onConsume,
}: {
  seed: { screenX: number; screenY: number } | null;
  onResolve: (menu: { screenX: number; screenY: number; flowX: number; flowY: number } | null) => void;
  onConsume: () => void;
}) {
  const { screenToFlowPosition } = useReactFlow();

  useEffect(() => {
    if (!seed) return;
    const flow = screenToFlowPosition({ x: seed.screenX, y: seed.screenY });
    onResolve({
      screenX: seed.screenX,
      screenY: seed.screenY,
      flowX: flow.x,
      flowY: flow.y,
    });
    onConsume();
  }, [onConsume, onResolve, screenToFlowPosition, seed]);

  return null;
}
