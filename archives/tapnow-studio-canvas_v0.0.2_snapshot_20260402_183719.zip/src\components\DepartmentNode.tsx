import { Handle, Position, type Node, type NodeProps } from '@xyflow/react';
import { memo, useCallback, type MouseEvent } from 'react';
import { useStudioStore } from '@/store/useStudioStore';
import type { StudioNodeData } from '@/types/studio';
import {
  DEPT_INPUT_HANDLE_ID,
  DEPT_INPUT_PULL_HANDLE_ID,
  DEPT_OUTPUT_HANDLE_ID,
  departmentNodeHasInputWire,
} from '@/utils/departmentInputWire';
import {
  parseShotListItemOutputHandleId,
  SHOT_LIST_LINK_HANDLE_ID,
} from '@/utils/shotListWire';

const PlayIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
    <path d="M8 5v14l11-7z" />
  </svg>
);

type DeptRF = Node<StudioNodeData, 'department'>;

function displayDepartmentLabel(label: string | undefined, fallback: string): string {
  if (!label) return fallback;
  let normalized = label;
  if (normalized.startsWith('缂傛牕澧介柈')) normalized = normalized.replace(/^缂傛牕澧介柈\?*/, '编剧部');
  if (normalized.startsWith('閸掑棝鏆呴柈')) normalized = normalized.replace(/^閸掑棝鏆呴柈\?*/, '分镜部');
  if (normalized.startsWith('Prompt闁')) normalized = normalized.replace(/^Prompt闁\?*/, 'Prompt部');
  if (label === '闂€婊冦仈鐞?') return '镜头表';

  const suffix = normalized.match(/([a-z0-9]{4})$/i)?.[1];
  if (suffix) {
    const deptName = normalized.startsWith('编剧部')
      ? '编剧部'
      : normalized.startsWith('分镜部')
        ? '分镜部'
        : normalized.startsWith('Prompt部')
          ? 'Prompt部'
          : null;
    if (deptName) {
      const compact = normalized.replace(/\s+/g, ' ').trim();
      const middle = compact.slice(deptName.length, compact.length - suffix.length).trim();
      if (!middle || middle === '·' || /[?？]/.test(middle) || middle.length <= 3) {
        return `${deptName} · ${suffix}`;
      }
    }
  }

  return normalized.replace(/\s*璺\?\s*/g, ' · ');
}

function previewText(data: StudioNodeData): string {
  if (data.status === 'IN_PROGRESS' && data.streaming_preview?.trim()) {
    const sp = data.streaming_preview.trim();
    return sp.length > 140 ? `${sp.slice(0, 140)}…` : sp;
  }
  if (data.type === 'writing' && data.output && typeof data.output === 'object') {
    const o = data.output as { scenes?: { title?: string; coreConflict?: string }[] };
    if (Array.isArray(o.scenes)) {
      return (
        o.scenes
          .slice(0, 2)
          .map((s) => s?.title ?? s?.coreConflict ?? '')
          .filter(Boolean)
          .join(' · ') || '（场次预览）'
      );
    }
  }
  if (data.type === 'storyboard' && data.output && typeof data.output === 'object') {
    const o = data.output as {
      shots?: { id?: number; description?: string; visual_description?: string; 画面描述?: string }[];
    };
    if (Array.isArray(o.shots)) {
      return (
        o.shots
          .slice(0, 2)
          .map((s) => s?.description ?? s?.visual_description ?? s?.画面描述 ?? '')
          .filter(Boolean)
          .join(' / ') || '（镜头预览）'
      );
    }
  }
  if (data.type === 'prompt' && data.output && typeof data.output === 'object') {
    const o = data.output as {
      userTemplate?: string;
      shotPrompts?: { shot_id?: string; prompt?: string }[];
    };
    const first = o.shotPrompts?.[0];
    if (first?.prompt) {
      const head = `${first.shot_id ?? 'shot'}: ${first.prompt}`;
      return head.slice(0, 100) + (head.length > 100 ? '…' : '');
    }
    if (typeof o.userTemplate === 'string') {
      return o.userTemplate.slice(0, 100) + (o.userTemplate.length > 100 ? '…' : '');
    }
  }
  if (data.input) return data.input.slice(0, 80) + (data.input.length > 80 ? '…' : '');
  return '等待输入或执行…';
}

export {
  DEPT_INPUT_HANDLE_ID,
  DEPT_INPUT_PULL_HANDLE_ID,
  DEPT_OUTPUT_HANDLE_ID,
} from '@/utils/departmentInputWire';

function DepartmentNodeInner({ id, data, selected }: NodeProps<DeptRF>) {
  const dept =
    data.department === 'WRITING'
      ? '编剧部'
      : data.department === 'STORYBOARD'
        ? '分镜部'
        : 'Prompt部';
  const displayLabel = displayDepartmentLabel(data.label, dept);

  const showPullHandle =
    data.type === 'writing' || data.type === 'storyboard' || data.type === 'prompt';

  const hasInputFeed = useStudioStore(
    useCallback((s) => departmentNodeHasInputWire(id, s.edges, s.nodes), [id]),
  );

  const statusDisplay =
    data.status === 'NOT_STARTED' && hasInputFeed ? '输入已挂载' : data.status;

  const canExecute =
    (data.type === 'writing' || data.type === 'storyboard' || data.type === 'prompt') &&
    (data.status === 'NOT_STARTED' || data.status === 'REJECTED');

  const canLegacyReviewOnCanvas = showPullHandle && data.status === 'WAITING_REVIEW';
  const canReviewedDecisionOnCanvas = showPullHandle && data.status === 'REVIEWED';

  const promptSourceBadge = useStudioStore(
    useCallback((s) => {
      if (data.type !== 'prompt') return null;
      const incoming = s.edges.filter(
        (edge) => edge.target === id && (edge.targetHandle == null || edge.targetHandle === DEPT_INPUT_HANDLE_ID),
      );
      const shotItemHandles = incoming
        .map((edge) => parseShotListItemOutputHandleId(edge.sourceHandle))
        .filter((wireId): wireId is string => Boolean(wireId));
      if (shotItemHandles.length >= 2) return '多镜头组合';
      if (shotItemHandles.length === 1) return '单镜头';
      const hasShotListWhole = incoming.some(
        (edge) =>
          edge.sourceHandle === DEPT_OUTPUT_HANDLE_ID &&
          s.nodes.find((n) => n.id === edge.source)?.type === 'shotList',
      );
      return hasShotListWhole ? '整表提示词' : null;
    }, [data.type, id]),
  );

  const handlePlay = useCallback(
    (e: React.MouseEvent) => {
      e.stopPropagation();
      if (data.onExecute) {
        void data.onExecute();
        return;
      }
      const st = useStudioStore.getState();
      st.focusNode(id, { openDetail: true });
      void st.executeNodeTask(id);
    },
    [id, data.onExecute],
  );

  const triggerLeaderReview = useStudioStore((s) => s.triggerLeaderReview);
  const manualPassLeaderReview = useStudioStore((s) => s.manualPassLeaderReview);
  const runReviewedOptimization = useStudioStore((s) => s.runReviewedOptimization);
  const approveReviewedAsIs = useStudioStore((s) => s.approveReviewedAsIs);

  const handleAiReview = useCallback(
    (e: MouseEvent) => {
      e.stopPropagation();
      void triggerLeaderReview(id);
    },
    [id, triggerLeaderReview],
  );

  const handleManualPass = useCallback(
    (e: MouseEvent) => {
      e.stopPropagation();
      manualPassLeaderReview(id);
    },
    [id, manualPassLeaderReview],
  );

  const handleOptimizeFromReviewed = useCallback(
    (e: MouseEvent) => {
      e.stopPropagation();
      runReviewedOptimization(id);
    },
    [id, runReviewedOptimization],
  );

  const handleApproveReviewedAsIs = useCallback(
    (e: MouseEvent) => {
      e.stopPropagation();
      approveReviewedAsIs(id);
    },
    [id, approveReviewedAsIs],
  );

  const flash = data.pipeline_decision_flash;
  const flashClass = (() => {
    if (!flash || flash.until <= Date.now()) return '';
    if (flash.kind === 'approve') return ' dept-node--flash-approve';
    return ' dept-node--flash-optimize';
  })();

  return (
    <div
      className={`dept-node ${selected ? 'dept-node--selected' : ''} dept-node--border-${data.status}${
        data.status === 'IN_PROGRESS' ? ' dept-node--streaming' : ''
      }${flashClass}`}
    >
      {showPullHandle ? (
        <Handle
          type="source"
          position={Position.Left}
          id={DEPT_INPUT_PULL_HANDLE_ID}
          className="dept-handle dept-handle--pull"
          title="Input 侧：拖向空白呼出菜单，可创建文本、编剧、分镜或 Prompt 并自动连线"
        />
      ) : null}
      <Handle
        type="target"
        position={Position.Left}
        id={DEPT_INPUT_HANDLE_ID}
        className={showPullHandle ? 'dept-handle dept-handle--in' : 'dept-handle'}
        title="Input：接入文本卡片或上游部门输出"
      />
      <header className="dept-node__head">
        <span className="dept-node__dept">{dept}</span>
        <div className="dept-node__head-actions">
          {canExecute ? (
            <button
              type="button"
              className="dept-node__play nodrag nopan"
              disabled={!hasInputFeed}
              onClick={handlePlay}
              title={hasInputFeed ? '执行任务' : '请先连接输入源'}
              aria-label={hasInputFeed ? '执行任务' : '请先连接输入源'}
            >
              <PlayIcon />
            </button>
          ) : null}
          <span
            className={`dept-node__status dept-node__status--${data.status}${
              data.status === 'NOT_STARTED' && hasInputFeed ? ' dept-node__status--feed' : ''
            }`}
          >
            {statusDisplay}
          </span>
        </div>
      </header>
      <div className="dept-node__body">
        <div className="dept-node__label">{displayLabel}</div>
        {promptSourceBadge ? <div className="dept-node__source-badge">{promptSourceBadge}</div> : null}
        <p className="dept-node__preview">{previewText(data)}</p>
        <div className="dept-node__meta">v{data.version} · Input / Output 资产</div>
      </div>
      {canLegacyReviewOnCanvas ? (
        <div className="dept-node__review-actions nodrag nopan" onPointerDown={(e) => e.stopPropagation()}>
          <button
            type="button"
            className="dept-node__review-btn"
            onClick={handleAiReview}
            title="调用 AI 总监二次审核（Leader API，旧画布待终裁）"
          >
            AI 审核
          </button>
          <button
            type="button"
            className="dept-node__review-btn dept-node__review-btn--secondary"
            onClick={handleManualPass}
            title="跳过二次 AI，直接 APPROVED（review_result 记录“用户手动通过”）"
          >
            手动通过
          </button>
        </div>
      ) : null}
      {canReviewedDecisionOnCanvas ? (
        <div className="dept-node__review-actions nodrag nopan" onPointerDown={(e) => e.stopPropagation()}>
          <button
            type="button"
            className="dept-node__review-btn"
            onClick={handleOptimizeFromReviewed}
            title="采纳建议并重算（员工 + 总监）"
          >
            重算
          </button>
          <button
            type="button"
            className="dept-node__review-btn dept-node__review-btn--secondary"
            onClick={handleApproveReviewedAsIs}
            title="忽略建议直接通过，激活 Output"
          >
            通过
          </button>
        </div>
      ) : null}
      {data.status === 'NOT_STARTED' && data.generation_error?.trim() ? (
        <div className="dept-node__generation-error">
          <div className="dept-node__generation-error-label">生成未成功</div>
          <p className="dept-node__generation-error-text">{data.generation_error.trim()}</p>
        </div>
      ) : null}
      {data.status === 'REJECTED' && data.review_result ? (
        <div className="dept-node__review-comment">
          <div className="dept-node__review-comment-label">总监修改建议</div>
          <p className="dept-node__review-comment-text">{data.review_result}</p>
        </div>
      ) : null}
      {data.type === 'storyboard' ? (
        <Handle
          type="source"
          position={Position.Bottom}
          id={SHOT_LIST_LINK_HANDLE_ID}
          className="dept-handle dept-handle--shot-list-link"
          title="镜头表子节点：执行生成后自动在下方创建并连接"
        />
      ) : null}
      {showPullHandle ? (
        <Handle
          type="source"
          position={Position.Right}
          id={DEPT_OUTPUT_HANDLE_ID}
          className="dept-handle dept-handle--out"
          title="Output：输出本节点剧本、分镜或 Prompt 资产至下游"
        />
      ) : null}
    </div>
  );
}

export const DepartmentNode = memo(DepartmentNodeInner);
