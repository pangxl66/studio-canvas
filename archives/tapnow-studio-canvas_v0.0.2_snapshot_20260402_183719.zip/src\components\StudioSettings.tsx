import { Panel } from '@xyflow/react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  clearLlmUserSettings,
  DEFAULT_DEEP_LLM_MODEL,
  DEFAULT_FAST_LLM_MODEL,
  DEFAULT_LLM_MODE,
  DEFAULT_LLM_TIMEOUT_MS,
  getLlmSettingsFormDefaults,
  getResolvedLlmGatewayConfig,
  pipelineModeForLlmMode,
  pipelineModeNeedsGateway,
  saveLlmUserSettings,
  type LlmMode,
  type LlmUserSettings,
} from '@/config/llmSettings';

export const STUDIO_OPEN_SETTINGS_EVENT = 'studio:open-settings';
export const STUDIO_SETTINGS_CHANGED_EVENT = 'studio:settings-changed';

function IconGear() {
  return (
    <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden>
      <path d="M19.14 12.94c.04-.31.06-.63.06-.94 0-.31-.02-.63-.06-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.488.488 0 0 0-.59-.22l-2.39.96c-.52-.4-1.08-.73-1.69-.98l-.36-2.54a.484.484 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.61.25-1.17.59-1.69.98l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.52.4 1.08.73 1.69.98l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.61-.25 1.17-.59 1.69-.98l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z" />
    </svg>
  );
}

function saveWithLlmMode(mode: LlmMode): LlmUserSettings {
  const current = getLlmSettingsFormDefaults();
  const next: LlmUserSettings = {
    ...current,
    mode,
    pipelineMode: pipelineModeForLlmMode(mode),
  };
  saveLlmUserSettings(next);
  window.dispatchEvent(new Event(STUDIO_SETTINGS_CHANGED_EVENT));
  return next;
}

function LlmModeButtons({
  value,
  onChange,
}: {
  value: LlmMode;
  onChange: (next: LlmMode) => void;
}) {
  const options: Array<{ value: LlmMode; label: string }> = [
    { value: 'fast', label: 'Fast' },
    { value: 'deep', label: 'Deep' },
  ];

  return (
    <div className="studio-run-mode-toggle" role="group" aria-label="模型档位切换">
      {options.map((option) => (
        <button
          key={option.value}
          type="button"
          className={`studio-run-mode-toggle__btn ${value === option.value ? 'studio-run-mode-toggle__btn--active' : ''}`}
          onClick={() => onChange(option.value)}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

export function StudioSettings() {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<LlmUserSettings>(() => getLlmSettingsFormDefaults());
  const [savedHint, setSavedHint] = useState<string | null>(null);
  const [quickLlmMode, setQuickLlmMode] = useState<LlmMode>(() => getLlmSettingsFormDefaults().mode);

  const gatewayReady = useMemo(() => getResolvedLlmGatewayConfig() != null, [open, savedHint, quickLlmMode]);
  const gatewayRequired = pipelineModeNeedsGateway(pipelineModeForLlmMode(form.mode));

  const openModal = useCallback(() => {
    const defaults = getLlmSettingsFormDefaults();
    setForm(defaults);
    setQuickLlmMode(defaults.mode);
    setSavedHint(null);
    setOpen(true);
  }, []);

  useEffect(() => {
    const onOpen = () => openModal();
    const onChanged = () => {
      setQuickLlmMode(getLlmSettingsFormDefaults().mode);
      if (!open) return;
      setForm(getLlmSettingsFormDefaults());
    };

    window.addEventListener(STUDIO_OPEN_SETTINGS_EVENT, onOpen);
    window.addEventListener(STUDIO_SETTINGS_CHANGED_EVENT, onChanged);
    return () => {
      window.removeEventListener(STUDIO_OPEN_SETTINGS_EVENT, onOpen);
      window.removeEventListener(STUDIO_SETTINGS_CHANGED_EVENT, onChanged);
    };
  }, [open, openModal]);

  const onQuickLlmModeChange = useCallback((nextMode: LlmMode) => {
    const next = saveWithLlmMode(nextMode);
    setQuickLlmMode(nextMode);
    setForm(next);
    const activeModel =
      nextMode === 'deep'
        ? (next.deepModel.trim() || DEFAULT_DEEP_LLM_MODEL)
        : (next.fastModel.trim() || DEFAULT_FAST_LLM_MODEL);
    setSavedHint(
      nextMode === 'deep'
        ? `已切到 Deep：后续分镜和提示词走 API，当前模型：${activeModel}。`
        : `已切到 Fast：后续分镜和提示词走本地，快速模型配置保留为 ${activeModel}。`,
    );
  }, []);

  const onSave = useCallback(() => {
    const next: LlmUserSettings = {
      baseUrl: form.baseUrl.trim(),
      apiKey: form.apiKey.trim(),
      mode: form.mode,
      fastModel: form.fastModel.trim(),
      deepModel: form.deepModel.trim(),
      timeoutMs: Math.max(5000, Math.min(600_000, form.timeoutMs || DEFAULT_LLM_TIMEOUT_MS)),
      pipelineMode: pipelineModeForLlmMode(form.mode),
    };
    saveLlmUserSettings(next);
    window.dispatchEvent(new Event(STUDIO_SETTINGS_CHANGED_EVENT));
    setQuickLlmMode(next.mode);
    setSavedHint('已保存到当前浏览器本地设置。');
    setForm(next);
  }, [form]);

  const onClear = useCallback(() => {
    clearLlmUserSettings();
    window.dispatchEvent(new Event(STUDIO_SETTINGS_CHANGED_EVENT));
    const defaults = getLlmSettingsFormDefaults();
    setForm(defaults);
    setQuickLlmMode(defaults.mode);
    setSavedHint('已清除本地保存的设置，仍会继续读取 .env 里的 VITE_* 配置。');
  }, []);

  const currentModel =
    form.mode === 'deep'
      ? (form.deepModel.trim() || DEFAULT_DEEP_LLM_MODEL)
      : (form.fastModel.trim() || DEFAULT_FAST_LLM_MODEL);

  return (
    <>
      <Panel position="top-right" className="studio-run-mode-panel-anchor">
        <div className="studio-run-mode-panel nodrag nopan">
          <div className="studio-settings-quick-group">
            <span className="studio-settings-quick-label">模式</span>
            <LlmModeButtons value={quickLlmMode} onChange={onQuickLlmModeChange} />
          </div>
          <button
            type="button"
            className="studio-run-mode-settings-btn nodrag nopan"
            title="打开 API 设置"
            aria-label="打开 API 设置"
            onClick={openModal}
          >
            <IconGear />
            <span>API 设置</span>
          </button>
        </div>
      </Panel>

      <Panel position="bottom-left" className="studio-settings-panel-anchor">
        <button
          type="button"
          className="studio-settings-trigger nodrag nopan"
          title="设置"
          aria-label="打开设置"
          onClick={() => (open ? setOpen(false) : openModal())}
        >
          <IconGear />
        </button>
      </Panel>

      {open
        ? createPortal(
            <div
              className="studio-settings-backdrop"
              role="presentation"
              onClick={() => setOpen(false)}
              onKeyDown={(e) => e.key === 'Escape' && setOpen(false)}
            >
              <div
                className="studio-settings-modal"
                role="dialog"
                aria-modal="true"
                aria-labelledby="studio-settings-title"
                onClick={(e) => e.stopPropagation()}
                onPointerDown={(e) => e.stopPropagation()}
              >
                <div className="studio-settings-modal__head">
                  <h2 id="studio-settings-title" className="studio-settings-modal__title">
                    设置
                  </h2>
                  <button type="button" className="studio-settings-modal__close" onClick={() => setOpen(false)}>
                    关闭
                  </button>
                </div>

                <div className="studio-settings-modal__body">
                  <section className="studio-settings-section" aria-labelledby="llm-api-heading">
                    <h3 id="llm-api-heading" className="studio-settings-section__title">
                      模式与 API
                    </h3>
                    <p className="studio-settings-section__desc">
                      现在只保留一组切换：
                      <code>Fast</code> 表示本地执行，
                      <code>Deep</code> 表示走 API。保存后会写入浏览器 <code>localStorage</code>，优先级高于{' '}
                      <code>.env</code> 里的 <code>VITE_LLM_*</code>。
                    </p>

                    <div className="studio-settings-quick-group">
                      <span className="studio-settings-quick-label">当前模式</span>
                      <LlmModeButtons
                        value={form.mode}
                        onChange={(mode) =>
                          setForm((f) => ({
                            ...f,
                            mode,
                            pipelineMode: pipelineModeForLlmMode(mode),
                          }))
                        }
                      />
                    </div>

                    <label className="studio-settings-field">
                      <span className="studio-settings-field__label">Base URL</span>
                      <input
                        type="url"
                        className="studio-settings-field__input"
                        placeholder="https://api.openai.com/v1"
                        value={form.baseUrl}
                        onChange={(e) => setForm((f) => ({ ...f, baseUrl: e.target.value }))}
                        autoComplete="off"
                      />
                    </label>

                    <label className="studio-settings-field">
                      <span className="studio-settings-field__label">API Key</span>
                      <input
                        type="password"
                        className="studio-settings-field__input"
                        placeholder="sk-..."
                        value={form.apiKey}
                        onChange={(e) => setForm((f) => ({ ...f, apiKey: e.target.value }))}
                        autoComplete="off"
                      />
                    </label>

                    <label className="studio-settings-field">
                      <span className="studio-settings-field__label">LLM 档位</span>
                      <select
                        className="studio-settings-field__input"
                        value={form.mode}
                        onChange={(e) =>
                          setForm((f) => ({
                            ...f,
                            mode: e.target.value === 'deep' ? 'deep' : DEFAULT_LLM_MODE,
                          }))
                        }
                      >
                        <option value="fast">快速模式</option>
                        <option value="deep">深度模式</option>
                      </select>
                    </label>

                    <label className="studio-settings-field">
                      <span className="studio-settings-field__label">快速模式模型</span>
                      <input
                        type="text"
                        className="studio-settings-field__input"
                        placeholder={DEFAULT_FAST_LLM_MODEL}
                        value={form.fastModel}
                        onChange={(e) => setForm((f) => ({ ...f, fastModel: e.target.value }))}
                        autoComplete="off"
                      />
                    </label>

                    <label className="studio-settings-field">
                      <span className="studio-settings-field__label">深度模式模型</span>
                      <input
                        type="text"
                        className="studio-settings-field__input"
                        placeholder={DEFAULT_DEEP_LLM_MODEL}
                        value={form.deepModel}
                        onChange={(e) => setForm((f) => ({ ...f, deepModel: e.target.value }))}
                        autoComplete="off"
                      />
                    </label>

                    <label className="studio-settings-field">
                      <span className="studio-settings-field__label">超时（毫秒）</span>
                      <input
                        type="number"
                        className="studio-settings-field__input"
                        min={5000}
                        max={600000}
                        step={1000}
                        value={form.timeoutMs}
                        onChange={(e) =>
                          setForm((f) => ({
                            ...f,
                            timeoutMs: parseInt(e.target.value, 10) || DEFAULT_LLM_TIMEOUT_MS,
                          }))
                        }
                      />
                    </label>

                    <div className={`studio-settings-status ${!gatewayRequired || gatewayReady ? 'studio-settings-status--ok' : ''}`}>
                      {!gatewayRequired
                        ? '当前 Fast 模式：分镜节点和提示词节点走本地；编剧节点仍需要 API。'
                        : gatewayReady
                          ? `当前 Deep 模式：API 配置完整；当前生效模型：${currentModel}。`
                          : '当前 Deep 模式需要 API，但缺少 Base URL 或 API Key。分镜节点和提示词节点会尽量回退到本地；编剧节点仍无法执行。'}
                    </div>

                    {savedHint ? <p className="studio-settings-hint">{savedHint}</p> : null}

                    <div className="studio-settings-actions">
                      <button
                        type="button"
                        className="studio-settings-btn studio-settings-btn--primary"
                        onClick={onSave}
                      >
                        保存设置
                      </button>
                      <button type="button" className="studio-settings-btn studio-settings-btn--ghost" onClick={onClear}>
                        清除本地设置
                      </button>
                    </div>
                  </section>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
    </>
  );
}
